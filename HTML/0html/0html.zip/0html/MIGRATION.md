# 0bind — Migration Guide

Drop-in declarative binding + safe-DOM layer for 0ui. Zero deps, shares
module scope after `combine.sh` concat. This is the "htmx feeling"
(attribute-driven wiring) **without** htmx's swap-untrusted-HTML model.

## What it buys you

| Problem today | 0bind fix |
|---|---|
| 45 scattered `innerHTML =` sites; correct escaping depends on remembering `htmlEsc()` every time | `setSafe()` / `el()` — text is text **by construction**, can't inject markup |
| 173 hand-wired `addEventListener` | `data-on-*` attributes + one delegated dispatcher; new UI needs zero listeners |
| No CSP story (inline handler risk) | `el()` **refuses** `on*` attributes; nothing eval'd from the DOM |
| `href`/`src` could carry `javascript:`/`data:` | scheme allowlist drops them automatically |

Not a rewrite. Migrate site-by-site; old and new coexist.

---

## Install into the build

Add to `combine.sh` MODULES array — **before** `00-core.js** so every
module can use `bind`:

```bash
MODULES=(
  0bind.js        # ← add first
  00-core.js
  01-state.js
  ...
)
```

Then wire the delegation root once, in `08-init.js` bootstrap:

```js
bind.init(document.body);   // delegates click/input/change/submit/keydown
```

---

## The 4 APIs

### 1. `setSafe(node, ...children)` — replaces `innerHTML =`

```js
// BEFORE (03-bubbles.js:411) — manual escape, easy to forget
bubble.innerHTML = `<div class="thinking-header">…</div><div class="thinking-body">${htmlEsc(text)}</div>`;

// AFTER — text arg is escaped structurally; no htmlEsc() call to forget
setSafe(bubble,
  el('div.thinking-header',
    el('span.thinking-chev', null, '▼'),
    el('span.thinking-label', null, 'AI Thinking…'),
    el('span.think-q-badge', { style: 'display:none' })),
  el('div.thinking-body', null, text)   // ← text, not markup. safe.
);
```

### 2. `el(spec, attrs, ...children)` — safe element builder

```js
el('button.del-btn.del-ok', { 'data-on-click': 'confirmDel' }, 'Delete')
el('a', { href: userUrl }, label)        // userUrl scheme-checked
el('span.ctx-name', { title: f.name }, f.name)   // both escaped
```

- `spec`: `'tag.class.class#id'`
- `on*` attrs → **refused** (use `data-on-*`)
- `href`/`src`/`action`/`poster` → scheme-checked, unsafe dropped
- children: strings→text (escaped), Nodes, `trust(...)`, arrays, null→skip

### 3. `trust(html)` — the ONLY door to raw HTML

Your `syntaxHighlight()` and `renderMarkdown()` already `_esc()` internally,
so their output is safe to inject — but wrap it so every raw sink is greppable:

```js
// BEFORE (02-render.js:754)
wrap.innerHTML = renderMarkdown(markdown);

// AFTER — same effect, now auditable via  grep 'trust('
setSafe(wrap, trust(renderMarkdown(markdown)));
```

```js
// BEFORE (02-render.js:676)
this.codeEl.innerHTML = syntaxHighlight(rawCode, lang);
// AFTER
setSafe(this.codeEl, trust(syntaxHighlight(rawCode, lang)));
```

**Rule:** if you're reaching for `trust()`, the wrapped value must come from
a self-escaping generator (syntaxHighlight/renderMarkdown/DocTags) — never
from raw model text or user input. Grep `trust(` in review; every hit
should show one of those generators inside.

### 4. `data-on-*` + `bind.on()` — delegated events

```html
<!-- markup (no inline JS, CSP-clean) -->
<button data-on-click="save">Save</button>
<input  data-on-input="filter" data-arg="rows">
<form   data-on-submit="send">…</form>   <!-- auto preventDefault -->
```

```js
// JS — one registration, handles all matching elements forever
bind.on('save',   (e, elm, ctx) => saveAppSettings());
bind.on('filter', (e, elm, ctx) => applyFilter(elm.value, ctx.arg)); // ctx.arg="rows"
bind.on('send',   (e, elm, ctx) => handleSend());
```

`ctx = { arg, name, type, target, root }`. Nearest binding wins (event
bubbles up to root). Missing handler → warns, never throws.

Your existing `chatBody` `data-act` delegation (08-init.js:458) is already
this pattern — 0bind generalizes it app-wide so you stop writing bespoke
delegators.

---

## Recommended migration order (by risk, highest first)

1. **`trust()`-wrap the 3 parser-output sinks** (02-render.js 676/754/800).
   Zero behavior change, makes raw-HTML writes auditable. **Do this first.**
2. **`setSafe(node, '')` → `clear(node)`** for the 16 clear-only sites.
   Trivial, removes `innerHTML` from those lines entirely.
3. **Template-literal sites** (03-bubbles, 06b-files, 08-init) → `el()` trees.
   Highest structural win; kills the "forgot htmlEsc" class of bug.
4. **New UI only:** stop adding `addEventListener`; use `data-on-*`.
   Don't rip out the 173 existing ones — migrate opportunistically.

After each batch: `node 0bind-test.cjs` and your existing `node test.cjs`.

---

## Security invariants (don't break these)

- **I1** — no API here routes a caller string into `innerHTML`/`outerHTML`/
  `insertAdjacentHTML` or a `javascript:`/`data:` sink.
- **I2** — `on*` attributes refused; events only via registry (no DOM eval).
- **I3** — `href`/`src`/`action`/`poster` scheme-checked (http/https/mailto/
  tel/ftp/relative/anchor pass; everything else dropped).
- **I4** — raw HTML enters **only** through `trust()`, so `grep 'trust('`
  enumerates every raw-HTML write in the codebase.

43 tests in `0bind-test.cjs` lock these down, incl. 5 XSS payloads proven
to stay inert, control-char scheme-obfuscation, and no-script-execution
through `trust()`.

---

## Size note (the real answer to "improve size")

htmx would **add** 16–51KB and let you delete ~0KB — net negative.
0bind is ~9KB unminified and lets you **delete** repeated escaping
boilerplate as you migrate. But the actual bloat is elsewhere:

- `Rogue_icon.png` = 361KB and `favicon.ico` = 361KB are **byte-identical**.
  Serve one, reference it twice → **~360KB saved**, ~40× more than any JS
  layer. Do that regardless of this migration.
