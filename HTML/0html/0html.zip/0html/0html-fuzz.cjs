#!/usr/bin/env node
/* ╔═══════════════════════════════════════════════════════════════╗
   ║  0html-fuzz.cjs — generative spec fuzzer / invariant oracle    ║
   ║  Zero deps. Throws adversarial JSON specs at the compiler and  ║
   ║  asserts G1–G9 hold as OBSERVABLE DOM properties.              ║
   ╚═══════════════════════════════════════════════════════════════╝

   WHY
   ---
   0html's thesis: render UNTRUSTED specs (files, URLs, LLM output) safely.
   The test suites check hand-picked cases. This fuzzer generates thousands
   of adversarial specs — seeded from an attack corpus, then mutated — and
   checks the guarantees as facts about the resulting DOM, not as unit tests.
   A single generated spec that produces a <script>, an unregistered handler,
   a javascript: URL, or a polluted prototype is a COUNTEREXAMPLE and gets
   printed for triage + saved to a corpus file.

   USAGE
     node 0html-fuzz.cjs [iterations] [seed]
     node 0html-fuzz.cjs 20000            # 20k specs
     node 0html-fuzz.cjs 5000 1337        # reproducible with a seed

   ORACLES (what "safe" means, mechanically)
     G1/G2  DOM contains no element whose tagName is script/iframe/object/
            embed/link/meta/base/style, and none outside ALLOWED_TAGS.
     G3     No element carries an on* attribute; every data-on-* names a
            handler that is NOT auto-invoked (registry is code-side).
     G4     Object.prototype gains no properties across the whole run.
     G5     No href/src/srcset/etc holds a javascript:/data:/vbscript: URL.
     G6     compile() either returns or throws RangeError — never hangs or
            RangeErrors from native stack overflow (we cap our own depth).
     G8     No rendered CSS (style/fill/stroke/filter/clip-path) carries an
            active construct or an off-origin url(), AFTER resolving CSS
            escapes and comments the way the parser does.
     G9     Under an active idPolicy every rendered id is prefixed, and in
            strict mode no clobber-prone id/name survives. Under urlPolicy
            same-origin no off-origin URL survives (G5b).
     G7     Any rendered raw HTML came through the trust() path (we assert
            the compiler never created an active element from `html`).
*/

'use strict';

// ── deterministic PRNG (mulberry32) so runs are reproducible ────
function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ── DOM shim that RECORDS enough to run the oracles ─────────────
const DANGER_TAGS = new Set(['script','iframe','object','embed','link','meta','base','style','frame','frameset','applet']);
class N {
  constructor(){ this.c=[]; this.nodeType=1; }
  appendChild(x){ if(x instanceof DF){ for(const k of x.c.slice()) this.appendChild(k); return x; } x.p=this; this.c.push(x); return x; }
  get textContent(){ return this.c.map(k=>k.textContent??'').join(''); }
  set textContent(v){ this.c=[]; if(v!=='') this.appendChild(new T(String(v))); }
}
class T { constructor(d){ this.data=String(d); this.nodeType=3; } get textContent(){ return this.data; } }
class E extends N {
  constructor(t,ns){ super(); this.tagName=String(t).toLowerCase(); this.ns=ns||null; this.a={}; this.dataset={}; }
  setAttribute(k,v){ this.a[k]=String(v); if(k.startsWith('data-')) this.dataset[k.slice(5).replace(/-([a-z])/g,(_,c)=>c.toUpperCase())]=String(v); }
  setAttributeNS(ns,k,v){ this.a[k]=String(v); }
  getAttribute(k){ return this.a[k]; }
  hasAttribute(k){ return Object.prototype.hasOwnProperty.call(this.a,k); }
  set id(v){ this.a.id=v; } set className(v){ this.a.class=v; } get className(){ return this.a.class||''; }
  addEventListener(){}
  // walk: collect every element for the oracles; propagate _inTemplate so
  // an entire trusted-HTML subtree is treated as inert (browser-accurate).
  walk(fn, inTpl){ const t = inTpl || this._inTemplate; if(t) this._inTemplate=true; fn(this); for(const k of this.c) if(k.walk) k.walk(fn, t); }
}
class Tpl extends E {
  constructor(){ super('template'); this.content=new DF(); }
  set innerHTML(h){
    const raw=(h&&h.__isTrustedHTML)?h.toString():String(h);
    // Model the browser <template>: parses but does NOT execute. Nodes created
    // here are flagged _inTemplate so the oracle treats them as inert (correct).
    const re=/<([a-zA-Z][a-zA-Z0-9]*)/g; let m;
    while((m=re.exec(raw))){ const e=new E(m[1]); e._inTemplate=true; this.content.appendChild(e); }
    const s=new E('span'); s._inTemplate=true; s.appendChild(new T(raw)); this.content.appendChild(s);
  }
}
class DF extends N { constructor(){ super(); this.nodeType=11; } }

global.document = { createElement:t=>t==='template'?new Tpl():new E(t), createElementNS:(ns,t)=>new E(t,ns), createTextNode:d=>new T(d), createDocumentFragment:()=>new DF() };
global.window = { addEventListener(){} };
global.Node = N;   // 0bind uses `c instanceof Node`; a real browser has this global

// load the built bundle
const fs=require('fs'), os=require('os'), path=require('path');
const cjs=path.join(os.tmpdir(),`fuzz-${process.pid}.cjs`);
fs.writeFileSync(cjs, fs.readFileSync(path.join(__dirname,'dist','0html.bundle.js'),'utf8'));
const H = require(cjs);
const ALLOWED = H.ALLOWED_TAGS;

// ── attack corpus: strings & shapes known to break naive renderers ─
const PAYLOAD_STRINGS = [
  '<script>alert(1)</script>',
  '"><svg/onload=alert(1)>',
  'javascript:alert(1)',
  'java\tscript:alert(1)',
  'java\u0000script:alert(1)',
  'data:text/html,<script>alert(1)</script>',
  'data:image/svg+xml,<svg onload=alert(1)>',
  'vbscript:msgbox(1)',
  '<img src=x onerror=alert(1)>',
  '<iframe src=javascript:alert(1)>',
  "'-alert(1)-'",
  '</script><script>alert(1)</script>',
  '\u003cscript\u003ealert(1)\u003c/script\u003e',
  'expression(alert(1))',
  'x 1x, javascript:alert(1) 2x',        // srcset
  '#\'"><svg onload=alert(1)>',
  '\uFEFF<script>alert(1)</script>',     // BOM prefix
  'https://evil.example/x.svg#a',        // use external
];
// CSS payloads. The old corpus set `style` ~1250 times per 10k specs and never
// once produced a `url(` — so I5, the control this whole attribute exists for,
// was exercised only with values it does not gate. The escaped forms are the
// v1.8.1 I5a/I5b bypasses: CSS unescapes \\2f to "/" and \\75 rl( to url(.
const CSS_STRINGS = [
  'background-image:url(//evil.example/beacon)',
  'background-image:url(\\2f\\2f evil.example/beacon)',
  'background-image:url("\\2f\\2f evil.example/b")',
  'background-image:\\75 rl(//evil.example/b)',
  'background-image:UR\\4C (//evil.example/b)',
  'background:url(\\6a avascript:alert(1))',
  'background:url(javascript:alert(1))',
  'background:url(/\\evil.example/b)',
  'width:expr\\65 ssion(alert(1))',
  'background:url(data:image/svg+xml;base64,PHN2Zz48L3N2Zz4=)',
  '@import url(//evil.example/x.css)',
  'position:fixed;inset:0;z-index:99999',
  'color:red;font-weight:bold',                      // benign control
  'background-image:url(/local/ok.png)',             // benign control
  'content:"\\201C"',                                // benign control
];
// Off-origin / obfuscated-host URLs. The old corpus had no protocol-relative
// URL and no backslash at all, so same-origin mode (v1.5.0) and the I3e
// backslash fold (v1.2.0) were both unreachable.
const URL_STRINGS = [
  '//evil.example/beacon',
  '/\\evil.example/beacon',
  '\\\\evil.example/beacon',
  'https://evil.example/track.gif',
  'https://app.example/ok.png',
  'https://cdn.example/logo.png',
  '#frag',
  '/relative/ok.png',
  'mailto:a@b.example',
  'https://app.example:8443/other-port',
  'https://ev\u0131l.example/homograph',
];
// Names that shadow DOM built-ins on a <form> ([LegacyOverrideBuiltIns]) or a
// host global. The old corpus never emitted a `name` attribute at all.
const CLOBBER_NAMES = [
  'hasAttribute','getAttribute','parentNode','nodeType','dataset','attributes',
  'children','elements','submit','action','location','cookie','constructor',
  'length','id','name','body','ownerDocument','email','q',
];
const DANGER_TAG_NAMES = ['script','iframe','object','embed','link','meta','base','style','SCRIPT','IfRaMe','svg','use','form','a','img','input','source','video','template','marquee','xss-el','ellipse','tspan','defs','symbol','foreignObject','animate'];
const ATTR_NAMES = ['href','src','srcset','imagesrcset','xlink:href','action','formaction','poster','cite','ping','background','data','style','onclick','onerror','on\nclick','onmouseover','class','id','name','for','list','headers','aria-labelledby','fill','stroke','filter','clip-path','title','rel','target','value','__proto__','constructor'];
const EVENT_NAMES = ['click','input','submit','onclick','__proto__','constructor','click"','x y'];
const POLLUTION_KEYS = ['__proto__','constructor','prototype'];
const pick = (r,arr)=>arr[Math.floor(r()*arr.length)];

// ── generator: build a random adversarial node (bounded) ────────
function genNode(r, depth){
  // sometimes a raw scalar (tests text coercion)
  if (depth>6 || r()<0.15) {
    const t=r();
    if (t<0.5) return pick(r,PAYLOAD_STRINGS);
    if (t<0.7) return r()*1e9;
    if (t<0.8) return null;
    if (t<0.9) return true;
    return { unknown:'field', arg: pick(r,PAYLOAD_STRINGS) };
  }
  const node={};
  // tag: bias toward dangerous/edge tags
  if (r()<0.85) node.tag = pick(r, DANGER_TAG_NAMES);
  // attrs: pile on URL + event + pollution attrs
  if (r()<0.8){
    node.attrs={};
    const n=1+Math.floor(r()*4);
    for(let i=0;i<n;i++){
      const k = pick(r,ATTR_NAMES);
      // Draw the value from the corpus that MATCHES the attribute, otherwise
      // a `style` never sees CSS and an `href` never sees an off-origin host.
      let v;
      if (k==='style') v = pick(r, CSS_STRINGS);
      else if (k==='name'||k==='id'||k==='for'||k==='headers'||k==='list') v = pick(r, CLOBBER_NAMES);
      else if (/^(href|src|srcset|imagesrcset|xlink:href|action|formaction|poster|cite|ping|background|data)$/.test(k))
        v = r()<0.5 ? pick(r,URL_STRINGS) : pick(r,PAYLOAD_STRINGS);
      else if (/^(fill|stroke|filter|clip-path)$/.test(k)) v = pick(r, CSS_STRINGS);
      else v = pick(r, PAYLOAD_STRINGS);
      node.attrs[k] = v;
    }
    if (r()<0.3) node.attrs[pick(r,POLLUTION_KEYS)] = { polluted:'yes' };
    // rare over-long value: exercises the I6 512 KB cap the old generator
    // could never reach (its longest payload was ~40 chars)
    if (r()<0.004) node.attrs[pick(r,['title','class','value','alt'])] = 'A'.repeat(600*1024);
  }
  // A <form> whose named child shadows a DOM accessor — the I10 shape.
  if (r()<0.10){
    node.tag='form';
    node.children=(node.children||[]).concat([
      { tag:'input', attrs:{ name: pick(r,CLOBBER_NAMES) } },
      { tag:'button', on:{ click:'save' } },
    ]);
  }
  // on: handler bindings incl. pollution + non-string
  if (r()<0.5){
    node.on={};
    node.on[pick(r,EVENT_NAMES)] = r()<0.5 ? pick(r,PAYLOAD_STRINGS) : { $fn:'alert(1)' };
  }
  // arg
  if (r()<0.3) node.arg = pick(r,PAYLOAD_STRINGS);
  // content: children | text | html
  const c=r();
  if (c<0.4){
    const k=Math.floor(r()*4);
    node.children=[]; for(let i=0;i<k;i++) node.children.push(genNode(r,depth+1));
  } else if (c<0.7){
    node.text = pick(r,PAYLOAD_STRINGS);
  } else {
    // html: try to smuggle raw markup through every gate combo
    const shape=r();
    if (shape<0.4) node.html = pick(r,PAYLOAD_STRINGS);            // bare string (should refuse)
    else if (shape<0.7) node.html = { $trust: pick(r,PAYLOAD_STRINGS), from:'markdown' };
    else node.html = { $trust: pick(r,PAYLOAD_STRINGS), from: pick(r,['evilgen','markdown','scanRow','']) };
  }
  // sometimes inject a pollution key at node level
  if (r()<0.2) node[pick(r,POLLUTION_KEYS)] = { polluted:'yes' };
  return node;
}

// ── ORACLES: assert guarantees as DOM facts ─────────────────────
function checkInvariants(root, opts){
  const violations=[];
  const isDoc = root && root.nodeType===1 && root.walk;
  if (!isDoc) return violations; // text node result — trivially safe

  root.walk((el)=>{
    // Template CONTENT is inert in a real browser (parsed, never executed).
    // 0html's trust() sink parses raw HTML inside a <template>, so script/etc
    // nodes there are non-executing by construction. Skip template subtrees —
    // counting them as "active" is a shim artifact, not a real vuln.
    if (el._inTemplate) return;
    // G2: no dangerous / non-allowlisted tags as ACTIVE elements.
    if (el.tagName && el.tagName!=='template' && el.tagName!=='span' && el.tagName!=='df'){
      if (DANGER_TAGS.has(el.tagName)) violations.push(['G2 danger-tag', el.tagName]);
    }
    // G3: no on* attribute survived
    for (const k of Object.keys(el.a||{})){
      if (/^on/i.test(k)) violations.push(['G3 on-attr', `${el.tagName}[${k}]`]);
    }
    // G5: URL attrs must not carry dangerous schemes.
    //   Single-URL attrs are dangerous ONLY if the value, after stripping
    //   control chars + leading whitespace, STARTS with a bad scheme — that's
    //   how a browser resolves them. A bad scheme mid-string (e.g.
    //   "x 1x, javascript:..") parses as a relative URL and is inert.
    //   srcset-style attrs carry multiple URLs, so ANY candidate matters.
    const SINGLE_URLK=['href','src','xlink:href','action','formaction','poster','cite','ping','background','data'];
    const SRCSET_URLK=['srcset','imagesrcset'];
    const badScheme = (s)=>/^\s*(?:javascript|data|vbscript)\s*:/i.test(String(s).replace(/[\u0000-\u001F\u007F-\u009F]/g,''));
    for (const k of SINGLE_URLK){
      const v=el.a && el.a[k];
      if (v && badScheme(v)) violations.push(['G5 bad-url', `${el.tagName}[${k}]=${v.slice(0,40)}`]);
    }
    for (const k of SRCSET_URLK){
      const v=el.a && el.a[k];
      if (v){
        for (const cand of String(v).split(',')){
          if (badScheme(cand.trim().split(/\s+/)[0])) { violations.push(['G5 bad-srcset', `${el.tagName}[${k}]`]); break; }
        }
      }
    }
    // ── G5b: under urlPolicy same-origin, nothing off-origin may survive.
    if (opts && opts.urlPolicy && opts.urlPolicy.mode==='same-origin'){
      const allow=new Set(opts.urlPolicy.allowedOrigins||[]);
      let baseOrigin; try { baseOrigin=new URL(opts._base).origin; } catch { baseOrigin=null; }
      for (const k of SINGLE_URLK.concat(SRCSET_URLK)){
        const v=el.a && el.a[k]; if(!v) continue;
        for (const cand of (SRCSET_URLK.includes(k)? String(v).split(',') : [String(v)])){
          const u0=cand.trim().split(/\s+/)[0]; if(!u0) continue;
          let u; try { u=new URL(u0, opts._base); } catch { continue; }
          if (u.protocol==='mailto:'||u.protocol==='tel:') continue;
          if (u.origin!==baseOrigin && !allow.has(u.origin))
            violations.push(['G5b off-origin', `${el.tagName}[${k}]=${u0.slice(0,40)}`]);
        }
      }
    }
    // ── G8: CSS. Resolve escapes and comments the way the CSS parser does,
    // then no url() may carry a scheme or be protocol-relative, and no
    // script-ish construct may survive. This oracle did not exist; nothing
    // inspected `style` at all, so an accepted exfil url() was invisible.
    // `style` is CSS on any element. fill/stroke/filter/clip-path are CSS only
    // on a real SVG element — as a stray attribute on a <video> or <form> they
    // are inert, and flagging those would be oracle noise, which is exactly how
    // a real finding gets buried.
    const SVG_NS='http://www.w3.org/2000/svg';
    const styleVals=[el.a&&el.a.style];
    if (el.ns===SVG_NS) styleVals.push(el.a&&el.a.fill, el.a&&el.a.stroke, el.a&&el.a.filter, el.a&&el.a['clip-path'], el.a&&el.a.marker);
    const cssVals=styleVals.filter(Boolean);
    for (const raw of cssVals){
      const decoded = String(raw)
        .replace(/\/\*[\s\S]*?\*\//g,'')
        .replace(/\\(?:\r\n|[\n\r\f])/g,'')
        .replace(/\\([0-9a-fA-F]{1,6})[ \t\r\n\f]?/g,(_,h)=>{const cp=parseInt(h,16);return (!cp||cp>0x10FFFF)?'\uFFFD':String.fromCodePoint(cp);})
        .replace(/\\([\s\S])/g,'$1');
      if (/(?:expression\s*\(|javascript\s*:|vbscript\s*:|-moz-binding|behaviou?r\s*:|@import)/i.test(decoded))
        violations.push(['G8 active-css', String(raw).slice(0,50)]);
      const ure=/url\(\s*(['"]?)([^'")]*)\1\s*\)/gi; let um;
      while((um=ure.exec(decoded))!==null){
        const u=um[2].trim();
        if (/^data:image\/(?:png|jpe?g|gif|webp);base64,/i.test(u)) continue;
        if (/^\/\//.test(u) || /^[a-z][a-z0-9+.-]*:/i.test(u))
          violations.push(['G8 css-url', `${u.slice(0,40)}`]);
      }
    }
    // ── G9: id/name under an active idPolicy. Namespace/strict must prefix
    // every rendered id; strict must additionally refuse clobber-prone
    // id/name values outright. Nothing checked this either.
    if (opts && opts.idPolicy && opts.idPolicy.mode!=='off'){
      const px = opts.idPolicy.prefix || '0h-';
      const id = el.a && el.a.id;
      if (id!=null && String(id)!=='' && !String(id).startsWith(px))
        violations.push(['G9 unprefixed-id', `${el.tagName}#${String(id).slice(0,30)}`]);
      if (opts.idPolicy.mode==='strict'){
        const DENY=new Set(['location','cookie','constructor','length','name','id','hasattribute','getattribute','parentnode','nodetype','dataset','attributes','children','elements','submit','action','body','ownerdocument']);
        const nm = el.a && el.a.name;
        if (nm!=null && DENY.has(String(nm).toLowerCase()))
          violations.push(['G9 clobber-name', `${el.tagName}[name=${String(nm).slice(0,30)}]`]);
        if (id!=null && DENY.has(String(id).replace(px,'').toLowerCase()))
          violations.push(['G9 clobber-id', `${el.tagName}#${String(id).slice(0,30)}`]);
      }
    }
  });
  return violations;
}

// ── run ─────────────────────────────────────────────────────────
const ITER = parseInt(process.argv[2]||'20000',10);
const SEED = parseInt(process.argv[3]|| String(Date.now()&0xffffffff),10);
const r = rng(SEED);

// snapshot Object.prototype for G4
const protoBefore = Object.getOwnPropertyNames(Object.prototype).sort().join(',');

let ran=0, refused=0, threw=0, rangeErr=0;
const findings=[];

console.log(`\n0html-fuzz — ${ITER} specs, seed ${SEED}\n`);
const t0=Date.now();

for (let i=0;i<ITER;i++){
  const spec = genNode(r, 0);
  // randomize compile options (incl. opening the trusted-HTML gate)
  // Every opt-in policy from v1.5.0 onward used to have ZERO fuzz coverage:
  // the loop only ever toggled allowTrustedHTML/trustedGenerators, so
  // urlPolicy, idPolicy, svg and preset were never set and the SVG namespace
  // path was never even constructed.
  const BASE = 'https://app.example/';
  const opts = {
    allowTrustedHTML: r()<0.5,
    trustedGenerators: r()<0.5 ? ['markdown','scanRow'] : [],
    maxDepth: 64, maxNodes: 10000,
    onWarn: ()=>{ refused++; },
  };
  if (r()<0.30) opts.svg = true;
  if (r()<0.40) opts.idPolicy = { mode: r()<0.5 ? 'namespace' : 'strict', prefix: r()<0.2 ? 'app-' : '0h-' };
  if (r()<0.40) opts.urlPolicy = { mode:'same-origin', base: BASE, allowedOrigins: r()<0.3 ? ['https://cdn.example'] : [] };
  if (r()<0.15) opts.preset = r()<0.5 ? 'strict' : 'namespace';
  opts._base = BASE;   // oracle needs it; compile ignores unknown keys
  let root=null;
  try {
    root = H.compile(spec, opts);
    ran++;
  } catch(e){
    threw++;
    if (e instanceof RangeError) rangeErr++;
    else findings.push({ kind:'NON-RANGE THROW', err:String(e), spec });
    continue;
  }
  const v = checkInvariants(root, opts);
  if (v.length) findings.push({ kind:'INVARIANT', violations:v, spec });
}

// G4: prototype unchanged
const protoAfter = Object.getOwnPropertyNames(Object.prototype).sort().join(',');
const protoOK = protoBefore===protoAfter;
if (!protoOK) findings.push({ kind:'G4 PROTOTYPE POLLUTION', before:protoBefore, after:protoAfter });

const dt=Date.now()-t0;
console.log(`ran:      ${ran}`);
console.log(`refused:  ${refused} warnings (pieces safely dropped)`);
console.log(`threw:    ${threw}  (RangeError: ${rangeErr}, other: ${threw-rangeErr})`);
console.log(`G4 proto: ${protoOK?'clean ✓':'POLLUTED ✗'}`);
console.log(`speed:    ${(ITER/(dt/1000)).toFixed(0)} specs/sec`);
console.log('');

if (findings.length===0){
  console.log(`✓ NO COUNTEREXAMPLES in ${ITER} specs (seed ${SEED})`);
  console.log('  G1–G7 held for every generated adversarial spec.\n');
  process.exit(0);
} else {
  console.log(`✗ ${findings.length} COUNTEREXAMPLE(S) — saving corpus\n`);
  const corpus = path.join(__dirname, `fuzz-findings-${SEED}.json`);
  fs.writeFileSync(corpus, JSON.stringify(findings.slice(0,50), null, 2));
  for (const f of findings.slice(0,5)){
    console.log(`  [${f.kind}]`, f.violations ? JSON.stringify(f.violations) : (f.err||''));
    console.log(`    spec: ${JSON.stringify(f.spec).slice(0,120)}`);
  }
  console.log(`\n  → ${corpus} (first 50)\n`);
  process.exit(1);
}
