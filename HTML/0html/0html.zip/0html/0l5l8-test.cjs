#!/usr/bin/env node
/*
  0l5l8-test.cjs — L5 (connect-src allowlist) and L8 (style-src hardening).

  L5: detectConnectSrc rejected only a literal '*', so `connect-src https:` —
  scheme-wide, fetch/XHR/WebSocket to ANY https host — reported "scoped to
  1 origin(s)", ✓ conformant, and `--require=L5` exited 0. connect-src is the
  one directive whose whole job is stopping that, and applyConnectSrc's own
  error text says so. Its origin validator also rejected ws:/wss:, leaving a
  WebSocket app unable to scope L5 at all.

  L8: inlineStyleAttrs is the interlock that gates dropping style-src
  'unsafe-inline'. It matched only DOUBLE-QUOTED values and its [^>]+ could not
  cross a '>' inside an earlier attribute, so live inline styles counted as
  zero. styleBlocks had a [^>]* opener, so a <style> with an attribute
  containing '>' was hashed over the wrong text.
*/
'use strict';
const { execFileSync } = require('child_process');
const fs = require('fs'), os = require('os'), path = require('path'), crypto = require('crypto');
const ENGINE = path.join(__dirname, '0html-layers.cjs');
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), '0l5l8-'));
let pass = 0, fail = 0;
const ck = (n, c) => c ? (pass++, console.log('  \u2713 ' + n)) : (fail++, console.log('  \u2717 FAIL ' + n));
function run(args) {
  try { return { out: execFileSync('node', [ENGINE, ...args], { encoding: 'utf8' }), code: 0 }; }
  catch (e) { return { out: (e.stdout || '') + (e.stderr || ''), code: e.status || 1 }; }
}
let n = 0;
const fx = (html) => { const p = path.join(TMP, 'f' + (++n) + '.html'); fs.writeFileSync(p, html); return p; };
const read = (p) => fs.readFileSync(p, 'utf8');
const page = (csp, body, marker) =>
  `<!doctype html><html><head>\n<meta http-equiv="Content-Security-Policy" content="${csp}">\n${marker || ''}\n</head><body>\n${body || '<script type="module">console.log(1)</script>'}\n</body></html>`;

console.log('\n-- L5: a scheme-wide connect-src is not "scoped" --');
for (const [label, val] of [
  ['https:', 'https:'],
  ['http: https:', 'http: https:'],
  ['host wildcard', '*.example.com'],
  ['data:', "'self' data:"],
  ['bare *', '*'],
]) {
  const f = fx(page(`default-src 'self'; script-src 'self'; connect-src ${val}`, null,
                    `<!-- 0html-layers: {"L5":{"added":["https://api.example"]}} -->`));
  const c = run(['conformance', f]);
  ck(`connect-src ${label} → DRIFT`, /DRIFT|NON-CONFORMANT/.test(c.out));
  ck(`connect-src ${label} → --require=L5 fails`, run(['conformance', f, '--require=L5']).code !== 0);
}
{
  const f = fx(page(`default-src 'self'; script-src 'self'; connect-src 'self' https://api.example`, null,
                    `<!-- 0html-layers: {"L5":{"added":["https://api.example"]}} -->`));
  ck('a genuinely scoped connect-src passes', run(['conformance', f]).code === 0);
  ck('and --require=L5 passes', run(['conformance', f, '--require=L5']).code === 0);
}

console.log('\n-- L5: apply --');
{
  const f = fx(page(`default-src 'self'; script-src 'self'; connect-src https:`));
  const r = run(['apply', f, '--layers=5', '--origins=wss://api.example,https://cdn.example']);
  ck('wss:// origin accepted', r.code === 0 && /wss:\/\/api\.example/.test(read(f)));
  ck("scoped list starts with 'self'", /connect-src 'self' wss:\/\/api\.example https:\/\/cdn\.example/.test(read(f)));
  ck('the open scheme-wide source is gone', !/connect-src[^;"]*\bhttps:(?!\/\/)/.test(read(f)));
}
{
  const f = fx(page(`default-src 'self'; script-src 'self'; connect-src https:`));
  const r = run(['apply', f, '--layers=5', '--origins=https://*.example']);
  ck('wildcard origin still rejected', r.code !== 0 && /invalid origin/.test(r.out));
}
{
  const f = fx(page(`default-src 'self'; script-src 'self'; connect-src https:`));
  const r = run(['apply', f, '--layers=5']);
  ck('missing --origins still blocks', r.code !== 0 && /needs --origins/.test(r.out));
}
{
  const f = fx(page(`default-src 'self'; script-src 'self'; connect-src https://api.example`));
  run(['apply', f, '--layers=5', '--origins=https://other.example']);
  run(['unapply', f, '--layer=5']);
  ck('unapply restores the original connect-src', /connect-src https:\/\/api\.example/.test(read(f)));
}

console.log('\n-- L8: the interlock must see every inline style attribute --');
{
  const f = fx(page(`default-src 'self'; style-src 'self' 'unsafe-inline'`,
                    `<p title="a > b" style="color:red">x</p>`));
  const r = run(['apply', f, '--layers=8']);
  ck('style hidden behind a quoted ">" blocks L8', r.code !== 0 && /inline style= attribute/.test(r.out));
  ck("'unsafe-inline' not dropped", /style-src 'self' 'unsafe-inline'/.test(read(f)));
}
{
  const f = fx(page(`default-src 'self'; style-src 'self' 'unsafe-inline'`, `<b style='font-weight:900'>x</b>`));
  const r = run(['apply', f, '--layers=8']);
  ck('single-quoted style blocks L8', r.code !== 0 && /inline style= attribute/.test(r.out));
}
{
  const f = fx(page(`default-src 'self'; style-src 'self' 'unsafe-inline'`,
                    `<p title="a > b" style="color:red">x</p>\n<b style='font-weight:900'>y</b>`));
  const r = run(['apply', f, '--layers=8']);
  ck('both are counted', /2 inline style= attribute/.test(r.out));
}
{
  const f = fx(page(`default-src 'self'; style-src 'self' 'unsafe-inline'`,
                    `<script>var t = '<p style="color:red">in a string</p>';</script>`));
  const r = run(['apply', f, '--layers=8']);
  ck('a style attr inside a JS string does not block', r.code === 0);
}
{
  const f = fx(page(`default-src 'self'; style-src 'self' 'unsafe-inline'`,
                    `<!-- <p style="color:red">commented</p> -->`));
  ck('a style attr inside a comment does not block', run(['apply', f, '--layers=8']).code === 0);
}

console.log('\n-- L8: the pinned hash must be the one the browser computes --');
{
  const body = 'body{color:#111}';
  const f = fx(page(`default-src 'self'; style-src 'self' 'unsafe-inline'`,
                    `<style data-note="a > b">${body}</style>\n<p class="x">clean</p>`));
  run(['apply', f, '--layers=8']);
  const want = "'sha256-" + crypto.createHash('sha256').update(body, 'utf8').digest('base64') + "'";
  ck('<style> with a quoted ">" attribute hashes correctly', read(f).includes(want));
  ck('conformance agrees', run(['conformance', f]).code === 0);
}
{
  const f = fx(page(`default-src 'self'; style-src 'self' 'unsafe-inline'`, `<style>a{b:c}</style>`));
  run(['apply', f, '--layers=8']);
  run(['unapply', f, '--layer=8']);
  ck("unapply restores 'unsafe-inline'", /style-src[^;"]*'unsafe-inline'/.test(read(f)));
}

console.log('\n' + '-'.repeat(40));
console.log(`  ${pass} passed, ${fail} failed  (L5 scoping + L8 hardening)`);
console.log('-'.repeat(40));
try { fs.rmSync(TMP, { recursive: true, force: true }); } catch {}
process.exit(fail ? 1 : 0);
