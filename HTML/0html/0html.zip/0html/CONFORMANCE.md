# 0html/1.1 — Conformance

An implementation may claim **"0html/1.1 conformant"** iff every box below is
checked. This is the portable contract: adopt the reference impl, or write your
own — either way, conformance means the same guarantees hold.

## A. Grammar (SPEC §2)
- [ ] Accepts string/number/boolean/null and object nodes
- [ ] Object node keys: `tag`, `class`/`className`, `id`, `attrs`, `on`, `arg`,
      `children`, `text`, `html`
- [ ] Content precedence `children` → `text` → `html` (§2.1)
- [ ] Scalars render as text nodes; markup inert

## B. Runtime invariants (SPEC §3, I1–I4)
- [ ] **I1** no caller/spec string reaches innerHTML/outerHTML/insertAdjacentHTML
      or a `javascript:`/`data:` sink
- [ ] **I2** `on*` attributes refused; events only via registry
- [ ] **I3** `href`/`src`/`action`/`poster`/`formaction`/`xlink:href` scheme-
      checked (http/https/mailto/tel/ftp/relative/anchor pass; else dropped);
      control-char obfuscation stripped first
- [ ] **I4** raw HTML only via `trust()` — greppable

## C. JSON-surface invariants (SPEC §3, J1–J7)
- [ ] **J1** `__proto__`/`constructor`/`prototype` dropped in nodes, `attrs`,
      `on`, and in the `fromJSON` reviver
- [ ] **J2** `maxDepth` (dflt 64) and `maxNodes` (dflt 10000) → `RangeError`
- [ ] **J3** only `ALLOWED_TAGS` render; others → inert `[data-0html-refused]`;
      allowlist is **not** spec-configurable
- [ ] **J4** `on` values are opaque strings, registry-looked-up, never eval'd;
      non-string handlers refused
- [ ] **J5** `html` double-gated: correct `{$trust, from}` shape **and**
      `allowTrustedHTML:true` **and** `from` in `trustedGenerators`; default OFF
- [ ] **J6** attribute-name charset enforced; `on*` refused at JSON layer
- [ ] **J7** operates under `require-trusted-types-for 'script'`; registers a
      **namespaced** TT policy (not `default`); no `createScript`/`ScriptURL`;
      `ttActive` reported; identical behavior with TT absent

## D. API (SPEC §5)
- [ ] `compile(spec, opts) → Node` — never throws on bad specs (refuses+warns);
      throws `RangeError` only on J2 bounds
- [ ] `render(spec, target, opts) → target` — safe-clears then mounts
- [ ] `fromJSON(text, opts) → Node` — pollution-safe reviver
- [ ] `validate(spec, opts) → {ok, warnings, node}` — dry run
- [ ] options honor §5.1 defaults; `version`/`spec`/`runtime` exposed

## E. Guarantees (THREAT-MODEL §5)
- [ ] G1–G9 hold for adversarial specs
- [ ] G8 verified under TT enforce mode
- [ ] G9 tamper-evidence available (lockfile + verify)

## F. Tests
- [ ] Passes runtime suite (`0bind-test.cjs`, 43)
- [ ] Passes compiler suite (`0html-test.cjs`, 63)
- [ ] Passes TT-enforce suite (`0bind-tt-test.cjs`, 9)
- [ ] Passes hostile-input integration (`0scan-test.cjs`, 8)
- [ ] `0html verify` catches bundle drift and stale CSP hash

## G. Integrity (the standard's operational spine)
- [ ] Ships `0html.lock` pinning bundle SHA-256 + versions
- [ ] `0html verify` wired into CI (non-zero exit on drift)
- [ ] Single source of version truth (runtime + compiler agree)

---

**Reference implementation:** the bundled `0bind.js` + `0html.js` (spec
`0html/1.1`) checks every box. `./build.sh --test && node 0html-cli.cjs verify`
is the full conformance run.

## Claiming conformance in a tool

Add to the tool's header:

```html
<!-- 0html/1.1 conformant — see 0html.lock for pinned bundle hash -->
```

and keep `0html.lock` alongside. `0html verify <tool>.html` proves the claim.
