'use strict';
// Prove 0scan's hostile dataset stays inert under TT enforce.
class STH{constructor(s){this.__isTrustedHTML=true;this._s=String(s)}toString(){return this._s}}
class Node{constructor(){this.childNodes=[];this.nodeType=1}appendChild(c){if(c instanceof DF){for(const k of c.childNodes.slice())this.appendChild(k);return c}c.parentNode=this;this.childNodes.push(c);return c}get textContent(){return this.childNodes.map(c=>c.textContent??'').join('')}set textContent(v){this.childNodes=[];if(v!=='')this.appendChild(new TN(String(v)))}}
class TN{constructor(d){this.data=String(d);this.nodeType=3}get textContent(){return this.data}}
class El extends Node{constructor(t){super();this.tagName=String(t).toLowerCase();this._a={};this.dataset={}}setAttribute(k,v){this._a[k]=String(v)}getAttribute(k){return this._a[k]}hasAttribute(k){return Object.prototype.hasOwnProperty.call(this._a,k)}set id(v){this._a.id=v}set className(v){this._a.class=v}get className(){return this._a.class||''}addEventListener(){}
  // collect any REAL script/img/iframe/svg ELEMENTS that got injected
  scan(bad){ if(['script','img','iframe','svg'].includes(this.tagName)) bad.push(this.tagName); for(const c of this.childNodes) if(c.scan) c.scan(bad); return bad }
  allText(){ let t=this.tagName==='template'?'':(this.textContent||''); return t }
}
class Tpl extends El{constructor(){super('template');this.content=new DF()}set innerHTML(html){
  if(global.__TT_ENFORCE && !(html&&html.__isTrustedHTML)) throw new TypeError("needs TrustedHTML");
  const raw=(html&&html.__isTrustedHTML)?html.toString():String(html);
  // REAL parse: create elements for tags so we can detect injection
  // (the actual browser <template> would parse these into inert nodes)
  const re=/<(script|img|iframe|svg)\b/gi; let m;
  while((m=re.exec(raw))){ const e=new El(m[1]); this.content.appendChild(e); }
  const span=new El('span'); span.appendChild(new TN(raw)); this.content.appendChild(span);
}}
class DF extends Node{constructor(){super();this.nodeType=11}}
global.document={createElement:t=>t==='template'?new Tpl():new El(t),createTextNode:d=>new TN(d),createDocumentFragment:()=>new DF(),body:new El('body'),addEventListener:()=>{}};
global.Node=Node;
let polName=null;
global.window={addEventListener:()=>{},trustedTypes:{createPolicy(n,r){polName=n;return{name:n,createHTML:s=>new STH(r.createHTML(s))}}}};
global.__TT_ENFORCE=true;

const fs=require('fs'),os=require('os'),p=require('path');
const cjs=p.join(os.tmpdir(),'bundle-sec.cjs');
// use the built bundle (what 0scan actually ships)
fs.writeFileSync(cjs,fs.readFileSync(p.join(__dirname,'dist','0html.bundle.js'),'utf8'));
const B=require(cjs);
const bind=global.OUI_BIND=B.runtime?B:global.window.OUI_BIND; // bundle exports OUI_HTML; grab bind from window
const html0=B;
const _bind=global.window.OUI_BIND;

let pass=0,fail=0;
const ok=(n,c)=>{const P=!!c;console.log(`${P?'✓':'✗'} ${n}`);P?pass++:fail++};

console.log('\n── 0scan hostile-input containment (TT enforce ON) ──');
ok('TT policy registered (0html)', polName==='0html');
ok('runtime ttActive true', _bind.ttActive===true);

// the esc() from 0scan (same impl)
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const jsItem=j=>`<div class="scan-item"><div class="scan-obj">obj ${esc(j.obj)}</div><pre class="scan-code">${esc(j.code)}</pre></div>`;

// hostile payloads from 0scan SAMPLES.hostile
const hostile={
  file:'<img src=x onerror=alert("filename-xss")>.pdf',
  js:[{obj:'<script>alert("obj-xss")</script>', code:'"><img src=x onerror=alert(document.domain)>//\n</script><svg onload=alert(1)>'}],
  launch:[{obj:2,target:'"><iframe src=javascript:alert(1)>'}],
};

// 1) filename as a TEXT node (0scan renders meta.file as text)
{
  const n=html0.compile({tag:'span', text:hostile.file}, {allowTrustedHTML:true,trustedGenerators:['scanRow']});
  const bad=[]; n.scan(bad);
  ok('filename payload: NO element injected', bad.length===0);
  ok('filename payload: preserved as text', n.textContent===hostile.file);
}

// 2) JS finding through the trust() gate (esc()'d body)
{
  const body=hostile.js.map(jsItem).join('');
  const n=html0.compile({tag:'div',class:'scan-body',html:{$trust:body,from:'scanRow'}},
                        {allowTrustedHTML:true,trustedGenerators:['scanRow']});
  const bad=[]; n.scan(bad);
  ok('JS-finding via trust(): NO script/img/svg element injected', bad.length===0);
  // the escaped text should contain &lt;script&gt; literally, not <script>
  ok('JS-finding: payload appears ESCAPED in text', n.textContent.includes('&lt;script&gt;') || n.textContent.includes('&lt;img'));
}

// 3) if generator NOT allowlisted, the whole body is refused
{
  const body=hostile.js.map(jsItem).join('');
  const n=html0.compile({tag:'div',html:{$trust:body,from:'scanRow'}},
                        {allowTrustedHTML:true,trustedGenerators:['SOMETHING_ELSE']});
  ok('unallowlisted generator: body refused (empty)', n.textContent==='');
}

// 4) launch target as text (0scan puts it in a code element via esc in body)
{
  const item=`<div class="scan-item"><code>${esc(hostile.launch[0].target)}</code></div>`;
  const n=html0.compile({tag:'div',html:{$trust:item,from:'scanRow'}},
                        {allowTrustedHTML:true,trustedGenerators:['scanRow']});
  const bad=[]; n.scan(bad);
  ok('launch target: NO iframe injected', bad.length===0);
}

console.log('\n────────────────────────────────────────');
console.log(`  ${pass} passed, ${fail} failed`);
console.log('────────────────────────────────────────\n');
process.exit(fail?1:0);
