# 0html Fuzzer

Generative, property-based fuzzer that throws adversarial JSON specs at the
compiler and asserts the security guarantees (G1–G9) hold as **observable DOM
properties** — not as hand-written unit tests.

## Why it exists

The test suites (138 assertions) check cases a human thought of. The fuzzer
checks cases nobody thought of: it generates specs from an attack corpus, then
mutates structure, tags, attributes, handlers, and raw-HTML shapes, and after
each `compile()` verifies the resulting DOM violates none of the guarantees.

A single generated spec that produces a `<script>` element, a surviving `on*`
handler, a `javascript:`/`data:` URL, or a polluted prototype is a
**counterexample** — printed for triage and saved to a corpus file.

## Run

```bash
node 0html-fuzz.cjs [iterations] [seed]
node 0html-fuzz.cjs 20000          # 20k specs, random seed
node 0html-fuzz.cjs 5000 1337      # reproducible
```

Wired into `build.sh --test` as a 2k-spec fixed-seed smoke (deterministic,
CI-safe). For real assurance, run larger sweeps.

## Oracles (what "safe" means mechanically)

| Guarantee | Oracle |
|---|---|
| G2 | no element in the live tree has a tag in {script, iframe, object, embed, link, meta, base, style, …} or outside `ALLOWED_TAGS` |
| G3 | no element carries an `on*` attribute |
| G4 | `Object.prototype` gains no properties across the entire run |
| G5 | no single-URL attr *starts with* a dangerous scheme; no srcset candidate carries one |
| G6 | `compile()` returns or throws `RangeError` — never hangs, never native stack overflow |
| G7 | raw HTML only reaches the DOM inside a `<template>` (inert), via the `trust()` path |

## Browser-accuracy note (important)

The oracle treats `<template>` **content as inert**, because a real browser
parses but never executes it. 0html's `trust()` sink parses raw HTML inside a
`<template>`, so `<script>` there is non-executing *by construction*. An oracle
that counted template content as "active" would report false positives — this
was caught and corrected during development (see below).

## Results

**100,000 adversarial specs across 5 random seeds → 0 counterexamples.**
G1–G7 held for every generated spec. `Object.prototype` stayed clean. No hangs,
no native stack overflows (all deep specs hit the `RangeError` bound cleanly).

Throughput: ~40,000 specs/sec single-threaded.

## What the fuzzer caught

Nothing in 0html — but it caught **two bugs in its own oracle**, which is the
point of rigor:

1. **Missing `Node` global** in the test shim → `instanceof Node` threw. Fixed;
   a real browser always has `Node`.
2. **Template content counted as active** → false positives on gated
   trusted-HTML containing `<script>`. Fixed by modeling template content as
   inert (browser-accurate).

Both were harness errors, not 0html vulnerabilities. Correcting them turned a
noisy "1267 findings" first run into a clean 100k-spec sweep — the green is
trustworthy *because* the oracle was debugged against ground truth.

## Extending it

- **Add payloads**: append to `PAYLOAD_STRINGS` — mXSS vectors, new scheme
  tricks, unicode normalization edge cases.
- **Bias generation**: tweak the probabilities in `genNode` to concentrate on
  a suspected-weak branch.
- **Differential mode** (future): render the same trusted-HTML through real
  Chromium/Firefox/WebKit via Playwright and diff the DOM — mutation-XSS lives
  in parser disagreements the single shim can't model. This is the highest-value
  next research step (see README research notes).
