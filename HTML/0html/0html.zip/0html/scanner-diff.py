#!/usr/bin/env python3
"""
scanner-diff.py — differential fuzz of 0html-layers' maskNonMarkup+scanTags
against Python's stdlib html.parser.

Everything the tooling fixes now rests on that one scanner, and it has only been
tested against cases I thought of. html.parser is an independent implementation
that gets the two properties that matter right: a '>' inside a quoted attribute
value does not close the tag, and <script>/<style> contents are CDATA, not markup.

Compares the sequence of (tagname, [(attr, value)]) for start tags.
"""
import json, random, subprocess, sys, tempfile, os
from html.parser import HTMLParser

HARNESS = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'scanner-harness.cjs')


class Ref(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.out = []

    def handle_starttag(self, tag, attrs):
        self.out.append({'tag': tag.lower(), 'attrs': [[k.lower(), v] for k, v in attrs]})

    handle_startendtag = handle_starttag


def reference(html):
    p = Ref()
    p.feed(html)
    p.close()
    return p.out


def mine(html):
    with tempfile.NamedTemporaryFile('w', suffix='.html', delete=False) as fh:
        fh.write(html)
        p = fh.name
    try:
        raw = subprocess.run(['node', HARNESS, p], capture_output=True, text=True, timeout=30)
        if raw.returncode != 0:
            return None, raw.stderr[:400]
        return json.loads(raw.stdout), None
    finally:
        os.unlink(p)


# ── fixture generator ────────────────────────────────────────────────────────
TAGS = ['div', 'p', 'span', 'button', 'b', 'img', 'a', 'input', 'section']
ANAMES = ['id', 'class', 'title', 'data-x', 'onclick', 'style', 'src', 'href',
          'integrity', 'once', 'rel', 'alt', 'data-note']
AVALS = ['x', 'a > b', "quote'inside", 'a b c', '', 'https://cdn.example/x.js',
         'color:red', 'save()', '/', 'a>b>c', 'a=b']


def attr(rng):
    n = rng.choice(ANAMES)
    style = rng.randint(0, 3)
    if style == 0:
        return ' ' + n                                        # boolean
    v = rng.choice(AVALS)
    if style == 1:
        return ' %s="%s"' % (n, v.replace('"', ''))
    if style == 2:
        return " %s='%s'" % (n, v.replace("'", ''))
    unq = v.replace(' ', '').replace('>', '').replace('"', '').replace("'", '')
    return ' %s=%s' % (n, unq or 'v')


def element(rng, depth=0):
    t = rng.choice(TAGS)
    a = ''.join(attr(rng) for _ in range(rng.randint(0, 3)))
    ws = rng.choice(['', ' ', '\n', '  '])
    if rng.random() < 0.12:
        return '<%s%s%s/>' % (t, a, ws)
    inner = ''
    if depth < 2 and rng.random() < 0.4:
        inner = ''.join(node(rng, depth + 1) for _ in range(rng.randint(1, 2)))
    return '<%s%s%s>%s</%s>' % (t, a, ws, inner, t)


def node(rng, depth=0):
    r = rng.random()
    if r < 0.10:
        return '<!-- %s -->' % rng.choice(
            ['just text', '<button onclick="x()">in a comment</button>', 'a > b', '<script src=x>'])
    if r < 0.20:
        payload = rng.choice([
            'var t = \'<button onclick="save()">Go</button>\';',
            'var s = "</scr" + "ipt>";',
            'if (a<b && c>d) { x(); }',
            'var u = "<img src=x onerror=alert(1)>";',
            'console.log(1);',
        ])
        return '<script%s>%s</script>' % (rng.choice(['', ' type="module"', ' data-n="a > b"']), payload)
    if r < 0.26:
        return '<style%s>/* <i onclick="x"> */ a{b:c}</style>' % rng.choice(['', ' data-note="a > b"'])
    if r < 0.32:
        return rng.choice(['plain text', 'a > b', 'x & y', '5 < 6'])
    return element(rng, depth)


def document(rng):
    return '<!doctype html><html><head></head><body>\n%s\n</body></html>' % (
        '\n'.join(node(rng) for _ in range(rng.randint(1, 6))))


def norm(seq):
    """Tag name, attribute names AND values. The generator emits no character
    references, so html.parser's unescaping is a no-op and raw slices compare
    directly."""
    return [(e['tag'], tuple(sorted((k, v) for k, v in e['attrs']))) for e in seq]


EDGE = [
    # a '>' inside a quoted value must not close the tag
    '<p title="a > b" onclick="x()">t</p>',
    "<p title='a > b' style='color:red'>t</p>",
    # unquoted value containing a slash
    '<a href=/x/y>t</a>',
    '<a href=x/>t</a>',
    # script CDATA
    '<script>var s = "</scr"+"ipt>"; var t = \'<b onclick="x">\';</script><b id=after>t</b>',
    '<script>if (a<b && c>d) {}</script><i id=after>t</i>',
    '<script type="module">let x = 1 < 2;</script>',
    # close tag with trailing space / slash
    '<script>x=1;</script ><b id=after>t</b>',
    # comments
    '<!-- <button onclick="x()">c</button> --><b id=after>t</b>',
    '<!--><b id=weird>t</b>',
    # style CDATA
    '<style>a{content:"<b onclick=x>"}</style><u id=after>t</u>',
    # attribute edge shapes
    '<div a b c>t</div>',
    '<div a = "x">t</div>',
    '<div a="">t</div>',
    "<div a=''>t</div>",
    '<div\nid="x"\nclass="y">t</div>',
    '<div id="x"/>',
    '<img src=x alt="a" >',
    '<h1 id=t>x</h1>',
    '<div data-v="a\'b" data-w=\'a"b\'>t</div>',
    # unterminated things
    '<script>var x = 1;',
    '<div title="unterminated>t</div>',
    '<!-- unterminated comment <b id=x>t</b>',
]


def main():
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 400
    seed = int(sys.argv[2]) if len(sys.argv) > 2 else 1
    rng = random.Random(seed)
    bad = 0
    corpus = list(EDGE) + [document(rng) for _ in range(n)]
    for i, html in enumerate(corpus):
        got, err = mine(html)
        if err:
            print('CRASH on spec %d:\n%s\n%s' % (i, html[:400], err))
            bad += 1
            continue
        want = reference(html)
        if norm(got) != norm(want):
            bad += 1
            print('=== MISMATCH spec %d ===' % i)
            print(html[:600])
            print('  reference:', norm(want))
            print('  scanner  :', norm(got))
            if bad >= 3:
                break
    print()
    if bad:
        print('\u2717 %d/%d specs diverged from html.parser' % (bad, n))
        sys.exit(1)
    print('\u2713 %d specs (%d hand-written edge cases + %d generated): scanner agrees with html.parser (seed %d)' % (len(corpus), len(EDGE), n, seed))


if __name__ == '__main__':
    main()
