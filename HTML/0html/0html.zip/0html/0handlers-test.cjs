#!/usr/bin/env node
/*
  0handlers-test.cjs — convert-handlers / restore-handlers correctness.

  convert-handlers is the one command that rewrites the user's MARKUP, and its
  output is what justifies dropping 'unsafe-inline' in L2. Three defects:

    1. the tag scan ran over <script> bodies, so a legacy template string
       `var t = '<button onclick="save()">'` was rewritten IN THE STRING to
       '<button data-0h="2">' — the handler silently dead, reported converted;
    2. /<tag([^>]*)>/ could not cross a '>' inside a quoted attribute, so
       `<p title="a > b" onclick="x()">` was invisible to the converter AND to
       the L2 interlock — convert said "nothing to convert (L2 can proceed)"
       and L2 then dropped 'unsafe-inline' with a live handler in the document;
    3. single-quoted and unquoted handler values were never matched at all.

  Runs the CLI end-to-end, same shape as 0layers-test.cjs.
*/
'use strict';
const { execFileSync } = require('child_process');
const fs = require('fs'), os = require('os'), path = require('path');
const ENGINE = path.join(__dirname, '0html-layers.cjs');
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), '0handlers-'));
let pass = 0, fail = 0;
const ck = (n, c) => c ? (pass++, console.log('  \u2713 ' + n)) : (fail++, console.log('  \u2717 FAIL ' + n));
function run(args) {
  try { return { out: execFileSync('node', [ENGINE, ...args], { encoding: 'utf8' }), code: 0 }; }
  catch (e) { return { out: (e.stdout || '') + (e.stderr || ''), code: e.status || 1 }; }
}
let n = 0;
const fx = (html) => { const p = path.join(TMP, 'f' + (++n) + '.html'); fs.writeFileSync(p, html); return p; };
const read = (p) => fs.readFileSync(p, 'utf8');
const CSP = `<meta http-equiv="Content-Security-Policy" content="script-src 'self' 'unsafe-inline'">`;
const page = (body) => `<!doctype html><html><head>${CSP}</head><body>\n${body}\n</body></html>`;

console.log('\n-- markup-in-JS must not be rewritten --');
{
  const src = `<script>\n  var tpl = '<button onclick="important()">Go</button>';\n</script>`;
  const f = fx(page(src));
  const r = run(['convert-handlers', f]);
  const h = read(f);
  ck('script string literal left verbatim', h.includes(`'<button onclick="important()">Go</button>'`));
  ck('no data-0h injected into the script body', !/var tpl = '<button data-0h/.test(h));
  ck('advisory names the markup-in-JS handler', /markup string/i.test(r.out));
}

console.log('\n-- a "> " inside an earlier attribute must not hide a handler --');
{
  const f = fx(page(`<p title="a > b" onclick="stillLive()">x</p>`));
  run(['convert-handlers', f]);
  const h = read(f);
  ck('handler converted', /data-0h="1"/.test(h) && !/onclick=/.test(h.split('<script>')[0]));
  ck('the title attribute survives intact', /title="a > b"/.test(h));
}
{
  // the fail-open case: both regexes missed it, so L2 proceeded
  const f = fx(page(`<p title="a > b" onclick="stillLive()">x</p>`));
  const c = run(['convert-handlers', f]);
  ck('convert does not claim "nothing to convert"', !/nothing to convert/.test(c.out));
  const a = run(['apply', f, '--layers=2']);
  ck('L2 proceeds only after real conversion', a.code === 0);
  ck('no live inline handler remains', !/\son[a-z]{2,}\s*=/.test(read(f).replace(/<script[\s\S]*?<\/script>/gi, '')));
}
{
  // before conversion, the interlock must actually block
  const f = fx(page(`<p title="a > b" onclick="stillLive()">x</p>`));
  const a = run(['apply', f, '--layers=2']);
  ck('L2 blocked while the hidden handler is live', a.code !== 0 && /inline on\* handler/.test(a.out));
  ck("'unsafe-inline' not dropped", /'unsafe-inline'/.test(read(f)));
}

console.log('\n-- every quoting form --');
{
  const f = fx(page(`<a onclick="d()">d</a>\n<b onclick='s()'>s</b>\n<img src=x onerror=u() alt="k">`));
  run(['convert-handlers', f]);
  const markup = read(f).split('<script>')[0];
  ck('double-quoted converted', !/onclick="d\(\)"/.test(markup));
  ck('single-quoted converted', !/onclick='s\(\)'/.test(markup));
  ck('unquoted converted', !/onerror=u\(\)/.test(markup));
  ck('three hooks placed', (read(f).match(/data-0h="\d"/g) || []).length >= 3);
  ck('unrelated unquoted attr preserved', /src=x/.test(markup));
  ck('unrelated quoted attr preserved', /alt="k"/.test(markup));
}

console.log('\n-- comments and <style> are not markup --');
{
  const f = fx(page(`<!-- <button onclick="ghost()">commented out</button> -->\n<style>/* <i onclick="css()"> */</style>\n<button onclick="real()">r</button>`));
  const r = run(['convert-handlers', f]);
  ck('exactly one handler converted', /converted 1 inline handler/.test(r.out));
  ck('comment left intact', /<!-- <button onclick="ghost\(\)">/.test(read(f)));
}

console.log('\n-- restore round-trip --');
{
  const body = `<button onclick="save()">b</button>\n<p title="a > b" onclick="alsoReal()">p</p>\n<span onclick='sq()'>s</span>`;
  const f = fx(page(body));
  run(['convert-handlers', f]);
  const rr = run(['restore-handlers', f]);
  const h = read(f);
  ck('restore reports success', rr.code === 0);
  ck('handler behind a ">" is restored (was silently dropped)', /onclick="alsoReal\(\)"/.test(h));
  ck('plain handler restored', /onclick="save\(\)"/.test(h));
  ck('single-quoted handler restored (normalised to double)', /onclick="sq\(\)"/.test(h));
  ck('all data-0h hooks removed', !/data-0h/.test(h));
  ck('wiring script removed', !/inline handlers converted/.test(h));
  ck('handler count preserved', (h.match(/\sonclick=/g) || []).length === 3);
}
{
  // a hook the record references but the document no longer has → fail loudly
  const f = fx(page(`<button onclick="save()">b</button>`));
  run(['convert-handlers', f]);
  fs.writeFileSync(f, read(f).replace(/ data-0h="1"/, ''));
  const rr = run(['restore-handlers', f]);
  ck('missing hook is an error, not a silent drop', rr.code !== 0 && /NOT restored/.test(rr.out));
}

console.log('\n-- on-prefixed attributes that are not handlers --');
{
  const f = fx(page(`<div once="true" data-x="1">x</div>\n<button onclick="save()">b</button>`));
  const r = run(['convert-handlers', f]);
  const h = read(f);
  ck('once="true" is preserved', /once="true"/.test(h));
  ck('and reported as left alone', /left alone: once/.test(r.out));
  ck('no bogus listener registered', !/addEventListener\('ce'/.test(h));
  ck('the real handler still converts', /converted 1 inline handler/.test(r.out));
}
{
  // an inert on* attribute must not block L2 either — it needs no 'unsafe-inline'
  const f = fx(page(`<div once="true">x</div>
<script type="module">console.log(1)</script>`));
  ck('inert on* attribute does not block L2', run(['apply', f, '--layers=2']).code === 0);
}
{
  // ...but every real handler name must still be recognised
  const names = ['onclick', 'onsubmit', 'onpointerdown', 'ontouchstart', 'onanimationend', 'onbeforeunload', 'onwheel'];
  const f = fx(page(names.map((nm, i) => `<b ${nm}="f${i}()">x</b>`).join('\n')));
  const r = run(['convert-handlers', f]);
  ck(`all ${names.length} real handler names recognised`, new RegExp(`converted ${names.length} inline handler`).test(r.out));
}

console.log('\n-- a second conversion must not corrupt the first --');
{
  const f = fx(page(`<button onclick="save()">b</button>`));
  run(['convert-handlers', f]);
  const afterFirst = read(f);
  const second = run(['convert-handlers', f]);
  ck('second pass is refused', second.code !== 0 && /already carry data-0h/.test(second.out));
  ck('file untouched by the refusal', read(f) === afterFirst);
  ck('restore still works afterwards', run(['restore-handlers', f]).code === 0 && /onclick="save\(\)"/.test(read(f)));
}
{
  const f = fx(page(`<div data-0h="mine">pre-existing hook attribute</div>\n<button onclick="x()">b</button>`));
  const r = run(['convert-handlers', f]);
  ck('a pre-existing data-0h blocks conversion', r.code !== 0 && /rename yours/.test(r.out));
}

console.log('\n-- a document that does not tokenise is not edited --');
{
  const f = fx(`<!doctype html><html><head>${CSP}</head><body>\n<button onclick="save()">b</button>\n<div class="unterminated\n`);
  const before = read(f);
  const r = run(['convert-handlers', f]);
  ck('unterminated tag refuses conversion', r.code !== 0 && /does not tokenise/.test(r.out));
  ck('and names the offending offset', /offset \d+/.test(r.out));
  ck('file left byte-identical', read(f) === before);
}
{
  const f = fx(page(`<p title="a > b" onclick="x()">fine</p>`));
  ck('a well-formed quoted ">" is not mistaken for one', run(['convert-handlers', f]).code === 0);
}

console.log('\n-- positive control --');
{
  const f = fx(page(`<button id="b">no handlers here</button>`));
  const before = read(f);
  const r = run(['convert-handlers', f]);
  ck('reports nothing to convert', /nothing to convert/.test(r.out));
  ck('file untouched', read(f) === before);
}

console.log('\n' + '-'.repeat(40));
console.log(`  ${pass} passed, ${fail} failed  (handler conversion)`);
console.log('-'.repeat(40));
try { fs.rmSync(TMP, { recursive: true, force: true }); } catch {}
process.exit(fail ? 1 : 0);
