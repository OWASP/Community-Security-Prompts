# 0html — Design & Rollout Plan: SVG rendering, same-origin URL mode, id/name clobbering

Target release: **v1.5.0** (feature set; likely split into 1.5.0 / 1.6.0 / 1.7.0 by
item — see rollout). This is a *plan*, not an implementation. Each item is
independently shippable and independently opt-in.

## Shared principles (non-negotiable, inherited from the existing library)

Every item below MUST hold these, or it doesn't ship:

1. **Allowlist over denylist.** New surface is gated by an explicit allowlist, not
   a blocklist of known-bad values.
2. **Fail closed / fail safe.** Unknown or unsafe input is dropped with a visible
   `console.warn` (never silently accepted); hard bounds throw. No fail-open path.
3. **Opt-in, default-off.** None of these changes the behavior of an existing
   deployment until the operator turns it on. This keeps every change a **minor**
   semver bump and makes rollout incremental.
4. **Zero new dependencies.** Node stdlib / browser built-ins only (`URL`,
   `createElementNS` are both universal).
5. **Headless-testable.** Every guard is reachable through the in-file DOM shim
   used by the existing suites; each item ships with its own `*-test.cjs` plus
   fuzz-corpus additions, and wires into `build.sh`.
6. **Log-safe.** Any new warning that interpolates untrusted input routes it
   through `logSafe()` (I7).

Non-goals (unchanged): 0html remains output/DOM safety — not an HTML sanitizer,
not prompt-injection defense, not a secret-isolation boundary.

---

## Unified configuration surface

All three land as additive `compile(spec, opts)` / `fromJSON(text, opts)` options.
Proposed shape (defaults shown = current behavior):

```js
compile(spec, {
  // ...existing (maxDepth, maxNodes, maxAttrs, allowTrustedHTML, trustedGenerators, onWarn)...

  svg: false,                              // Item 1 — off = SVG tags stay inert (today's behavior)

  urlPolicy: {                             // Item 2
    mode: 'any',                           //   'any' (today) | 'same-origin'
    allowedOrigins: [],                    //   extra origins permitted in same-origin mode
    base: undefined,                       //   origin to resolve against (browser: defaults to location)
  },

  idPolicy: {                              // Item 3
    mode: 'off',                           //   'off' (today) | 'namespace' | 'strict'
    prefix: '0h-',                         //   applied to ids + id-references in namespace/strict mode
  },
})
```

Rationale for the object-per-policy shape: each policy has >1 knob and will grow;
flat options (`sameOriginURLs: true`) would sprawl. Objects keep it legible and
let `validate()`/tooling introspect a policy.

---

## Item 1 — Safe SVG rendering (`createElementNS` + SVG attribute allowlist)

**Framework mapping:** A05 Injection (SVG is a historically deep XSS surface:
SMIL animation, `xlink:href`, `<foreignObject>`, in-SVG `<style>`/`<script>`,
external paint/filter refs). **Highest-risk item** — plan it last.

### Current state
SVG tags (`svg, path, g, circle, rect, line, polyline, polygon, text, use`) are in
`ALLOWED_TAGS` but `el()` builds every element with `document.createElement(tag)`,
which puts them in the **HTML** namespace → they become inert `HTMLUnknownElement`s
that don't render. Safe, but a latent trap (documented at the `createElement`
site). Making them render requires `createElementNS(SVG_NS, tag)`, which reopens
the SVG attack surface — hence the gating below.

### Design

**1a. Namespace-correct creation, keyed by tag name.** Add
`const SVG_NS = 'http://www.w3.org/2000/svg'` and an explicit `SVG_TAGS` set (the
allowlisted subset). In `el()`:

```js
const node = (cfg_svg_enabled && SVG_TAGS.has(tag))
  ? document.createElementNS(SVG_NS, tag)
  : document.createElement(tag);
```

Keying off the **tag name** works because the allowlisted SVG subset is
unambiguous: `path/circle/rect/line/polyline/polygon/use` are SVG-only names, and
`text` is not a valid HTML element. The one overlap, `<a>`, stays **HTML-only and
scheme-gated** (SVG `<a>` is *not* supported) — so no subtree/context tracking is
needed; each element's namespace is a pure function of its tag. `<foreignObject>`
is deliberately absent from the allowlist, so no HTML re-enters an SVG subtree.

**1b. SVG attribute allowlist (allowlist-over-denylist).** When `tag ∈ SVG_TAGS`,
apply an SVG-specific attribute policy instead of the HTML one:

- **Reuse the existing namespace-agnostic gates** — they already cover the script
  vectors: `on*` refusal (I2), `URL_ATTRS` scheme-check (covers `href`/`xlink:href`;
  `<use>` stays `#`-fragment-only, I3d), and `style` via `sanitizeStyle` (I5).
- **Add `SVG_ATTR_ALLOW`** — the safe geometry/presentation/text attributes for the
  subset: `d, points, x, y, x1, y1, x2, y2, cx, cy, r, rx, ry, width, height,
  viewBox, preserveAspectRatio, transform, fill, stroke, stroke-width,
  stroke-linecap, stroke-linejoin, stroke-dasharray, stroke-dashoffset, opacity,
  fill-opacity, stroke-opacity, color, text-anchor, dominant-baseline, font-size,
  font-family, dx, dy, id, class`, plus `href`/`xlink:href` (already gated). Any
  attribute not on this list is dropped+warned. This is the core safety property:
  unknown SVG attributes never reach the element.
- **`url()`-bearing paint/reference attributes** (`fill, stroke, clip-path, mask,
  filter, marker, marker-start, marker-mid, marker-end, cursor`) must have their
  `url(...)` payload pass an `isCssUrlSafe`-style check (fragment/same-origin only,
  never `data:svg`, never off-origin) — reusing the existing `isCssUrlSafe`. This
  blocks `fill="url(http://evil/x)"` exfil while allowing `fill="url(#grad)"`.

**1c. Namespaced attribute setting.** `xlink:href` on SVG should be set via
`setAttributeNS('http://www.w3.org/1999/xlink', 'href', v)`; prefer SVG2 plain
`href` for `<use>`. Everything else uses `setAttribute`.

**1d. No compiler-context needed.** Because namespace and attribute-policy are both
functions of the tag, `build()` needs only to thread `cfg.svg` down to `el()` (or
pre-select the attribute policy in `build()` when `cfg.svg && SVG_TAGS.has(tag)`).
The frozen-API/stateless-`el()` constraint is respected by passing `cfg.svg`
explicitly rather than via global state.

### Fail-closed behavior
`cfg.svg` off → SVG tags render inert exactly as today (no regression). On → only
allowlisted SVG elements + attributes render; everything else drops with a warn.

### Edge cases / risks
- **SMIL mXSS** (`<animate attributeName="href" to="javascript:…">`): mitigated by
  keeping `animate/set/animateTransform` out of the allowlist. Because 0html builds
  via DOM (not `innerHTML`), there is no re-parse for SMIL to hook.
- **CSS-in-SVG** (`<style>` element): not allowlisted. Inline `style` attr still
  goes through `sanitizeStyle`.
- **External filter/mask/paint refs**: covered by 1b `url()` check.
- **Testing needs a namespaced shim**: extend the DOM shim with
  `document.createElementNS(ns, tag)` recording `namespaceURI`, so tests assert
  (a) `svg/path/...` land in `SVG_NS`, (b) HTML tags stay HTML, (c) each
  adversarial SVG vector is refused.

### Test plan (`0svg-test.cjs`, new)
Positive: `svg > path[d]`, `circle[cx,cy,r,fill]`, `use[href="#i"]`, `g[transform]`
render in SVG_NS with expected attrs. Negative: `<animate>`/`<foreignObject>`/
in-SVG `<script>` refused (not allowlisted); `onload` refused; `fill="url(http://evil)"`
refused; `fill="url(#g)"` kept; `<use href="http://evil/x.svg#i">` refused;
unknown attr `foo="bar"` dropped; `xlink:href="javascript:…"` refused. Plus a
dedicated SVG payload block appended to `0html-fuzz.cjs`.

### Deployment applicability
- **Trusted-iconography / chart tools** (author-controlled SVG): enable
  `svg:true`. Big usability win, low residual risk given the allowlist.
- **Fully-untrusted-spec renderers** (the hostile-author model): keep `svg:false`
  unless SVG is genuinely needed; the SVG allowlist is safe but SVG is a larger
  surface than the HTML subset — smaller-surface-by-default is the safer posture.
- Pairs with CSP: ship `img-src`/`default-src` already restrict where any
  referenced asset could load; the attribute `url()` gate prevents emission.

### Semver / effort
Opt-in ⇒ **minor**. Effort: **L** (largest of the three; the attribute allowlist +
namespaced shim + fuzz corpus are the bulk). Ship last, behind the most red-teaming.

---

## Item 2 — Same-origin-only URL mode (opt-in)

**Framework mapping:** A01 (SSRF-adjacent / off-origin fetch) and the exfil theme —
an untrusted spec emitting `<img src="https://evil/track">` or `<a href="//evil">`
is a beacon / navigation-exfil vector. **Smallest, highest-confidence item — ship
first.**

### Current state
`isSafeUrl` allows `http(s)/mailto/tel/ftp`, relative, and **protocol-relative
`//host`** and **absolute cross-origin** URLs for `href`/`src`/`srcset` and the
other `URL_ATTRS`. (Note: CSS `url()` via `isCssUrlSafe` is *already* same-origin/
fragment-only, so this item only needs to cover the navigation/resource attributes,
not CSS — and, once Item 1 lands, its SVG paint `url()`s inherit the same CSS gate.)

### Design (origin logic verified against Node's `URL`)

Add `originAllowed(value, policy)` to 0bind and apply it, in same-origin mode, to
`URL_ATTRS` + `SRCSET_ATTRS` candidates:

```js
// policy = { mode, allowedOrigins:Set, base }
const originAllowed = (value, policy) => {
  if (policy.mode !== 'same-origin') return true;              // 'any' → unchanged
  const base = policy.base
    || (typeof location !== 'undefined' ? location.href : null);
  if (!base) return false;                                     // SSR/test w/o base → fail closed
  let u;
  try { u = new URL(String(value), base); } catch { return false; }
  if (u.protocol === 'mailto:' || u.protocol === 'tel:') return true; // no origin, not load-exfil
  const baseOrigin = new URL(base).origin;
  return u.origin === baseOrigin || policy.allowedOrigins.has(u.origin);
};
```

Verified behavior (Node `URL`, base `https://app.example.com/…`):

| input | resolved origin | same-origin verdict |
|---|---|---|
| `/rel`, `img.png`, `#frag` | `https://app.example.com` | ✅ allow |
| `//evil.com/track` | `https://evil.com` | ❌ refuse |
| `https://evil.com/x` | `https://evil.com` | ❌ refuse |
| `https://cdn.jsdelivr.net/…` | `https://cdn.jsdelivr.net` | ❌ unless allow-listed |
| `https://evil@app.example.com/x` | `https://app.example.com` | ✅ (userinfo stripped from origin; request really goes to app) |
| `https://app.example.com:8443/x` | `…:8443` | ❌ (port is part of origin) |
| `https://xn--e1afmkfd.com/x` (homograph) | punycode origin | ❌ (exact string compare catches homographs) |
| `mailto:a@b.com` | `null` | ✅ (scheme-gated, not a silent load) |

**Where it's applied:** cleanest home is the **compiler** (`build()`), pre-`el()`:
for each URL/srcset attribute, if `cfg.urlPolicy.mode === 'same-origin'` and
`!bind.originAllowed(value, resolvedPolicy)` → drop+warn before handing attrs to
`el()`. `el()` still runs its scheme allowlist (double gate). This keeps `el()`
stateless. (Alternative: teach `el()` the policy directly — rejected to avoid
threading config through the frozen stateless primitive.) 0bind exports
`originAllowed` + an `isUrlBearingAttr(name)` predicate so the compiler applies it
without duplicating the `URL_ATTRS`/`SRCSET_ATTRS` sets.

### Fail-closed behavior
`mode:'any'` → identical to today. `mode:'same-origin'` with no resolvable base
(SSR without `base`) → **refuse** (don't silently allow). Each candidate in a
`srcset` is checked independently; one bad candidate drops the whole attribute
(consistent with existing `isSafeSrcset`).

### Test plan (`0urlmode-test.cjs`, new)
With a fixed `base`: relative/fragment allowed; `//host` and cross-origin refused;
`allowedOrigins` entry allowed; `mailto:`/`tel:` allowed; each `srcset` candidate
origin-checked; missing-base ⇒ refuse; homograph refused. End-to-end through
`compile`, asserting the attribute is present/absent on the built node.

### Deployment applicability (decision matrix)
| Deployment | Recommended `urlPolicy` |
|---|---|
| Internal tool, untrusted specs, no external assets | `same-origin`, `allowedOrigins: []` — hardest exfil posture |
| Uses a known CDN | `same-origin` + `allowedOrigins: ['https://cdn…']` |
| Public tool that must render arbitrary external images | `any` (keep today's behavior), rely on CSP `img-src`/`connect-src` |
| SSR / non-browser build | set `base` explicitly (no `location`) |

Pairs with CSP as belt-and-suspenders: the URL mode prevents the URL from being
*emitted*; CSP is the network-layer *enforcement* backstop.

### Semver / effort
Opt-in ⇒ **minor**. Effort: **S**. Self-contained; ship **first**.

---

## Item 3 — DOM-clobbering mitigation for `id` / `name`

**Framework mapping:** A05 / A08 (integrity) — attacker-controlled `id`/`name` in a
spec can shadow globals the host app reads (`window.config`, `document.X`), defeat
`getElementById` assumptions, or clobber form-field access. **Reaches into the
consuming app's assumptions**, so it stays strictly opt-in.

### Design — uniform prefix transform (deterministic, no lookups)

Because a prefix transform is deterministic (`x → 0h-x`), we can apply it uniformly
to **both** id-defining and id-referencing attributes in a single pass, with no
cross-referencing:

- **Define sites:** `id`, `name`.
- **Reference sites:** `for`, `list`, `form`, `headers` (space-separated → prefix
  each token), `aria-labelledby`, `aria-describedby`, `aria-controls`, `aria-owns`,
  `aria-activedescendant` (space-separated → each), and `href`/`xlink:href`/`<use>`
  values of the form `#frag` → `#` + prefix + `frag`.

`idPolicy.mode`:
- **`off`** (default) — no change.
- **`namespace`** — apply the prefix transform everywhere above. Spec authors keep
  writing unprefixed ids/refs; rendered ids become `0h-<id>`. Anything in the host
  page not under the `0h-` prefix is now unclobberable by spec ids. Intra-spec
  wiring (label↔input, aria, fragment links, `<use>` sprites) is preserved because
  both sides get the same transform.
- **`strict`** — `namespace` **plus** refuse (drop+warn) any raw id/name matching a
  small high-value collision denylist (`length`, `name`, `constructor`,
  `__proto__`, `location`, `forms`, `cookie`, numeric-only, single-char, empty) as
  defense-in-depth before prefixing.

### Honest limitations (must be documented)
- Protects host-page globals **only if** the app's own globals don't live under the
  chosen prefix. Document "don't prefix your app globals with `0h-`."
- Does **not** protect against clobbering *within* the rendered subtree, and named
  form-field access still resolves within a form (that's spec-local and expected).
- `namespace` mode assumes id references are **spec-local**; a reference to an
  external (non-spec) id would be prefixed and break. Escape hatch options: (a)
  document the constraint, or (b) a `#!rawfrag` sentinel that opts a single
  reference out of prefixing. Recommend (a) for v1; add (b) only if requested.
- Changes rendered ids ⇒ external CSS/JS targeting those ids must use the prefixed
  form. This is why it's opt-in.

### Test plan (`0idpolicy-test.cjs`, new)
`namespace`: `id`/`name` prefixed; `label[for]`↔`input[id]` stay linked;
multi-token `aria-labelledby`/`headers` each prefixed; `href="#x"`→`href="#0h-x"`;
`<use href="#i">`→`#0h-i`. `strict`: `id:"constructor"` / `id:"__proto__"` / numeric
refused. `off`: untouched. End-to-end via `compile`.

### Deployment applicability
- **0html output shares a document/scope with trusted app JS** that reads globals
  or does `getElementById` → enable `namespace` (or `strict`).
- **Standalone/isolated render** (its own iframe/document, no app globals in scope)
  → `off` is fine.
- Composes with COOP/COEP isolation from the headers layer for stronger separation.

### Semver / effort
Opt-in ⇒ **minor**. Effort: **M** (the transform is simple; the surface is the list
of reference attributes + multi-token handling + tests).

---

## Recommended rollout order & rationale

1. **Item 2 — same-origin URL mode** → **v1.5.0**. Smallest, highest-confidence,
   self-contained; origin logic already de-risked. Immediate exfil-hardening value.
2. **Item 3 — id/name policy** → **v1.6.0**. Moderate; deterministic transform;
   valuable wherever 0html shares scope with app JS.
3. **Item 1 — safe SVG** → **v1.7.0**. Largest surface, needs the most red-teaming
   (SVG allowlist + namespaced shim + dedicated fuzz corpus). Ship last, behind the
   most testing.

Each is independent — order can change if a specific deployment needs SVG first.

## Cross-cutting work each item carries
- New `*-test.cjs` added to the `build.sh --test` gate (like `0harden2`/`0sbom`).
- Payload additions to `0html-fuzz.cjs` (SVG vectors; off-origin URLs; clobber ids).
- New invariant IDs + doc-header entries (e.g. I8 URL-origin, J11 SVG allowlist,
  J12 id-namespace), and a `THREAT-MODEL.md` note per item.
- `SECURITY-IMPROVEMENTS.md` changelog entry; `dist/` rebuild + lock re-pin +
  SBOM regen (versions bump; SBOM component hashes update automatically).
- `validate(spec, opts)` should surface which policies were active in its report.

## Decisions needed from the maintainer
1. **Defaults:** confirm all three stay **opt-in/off** for v1.5–1.7 (recommended),
   or should any become default-on in a later major (e.g. same-origin default in
   a hardened preset)?
2. **Presets:** worth adding a `preset: 'strict'` that flips `urlPolicy:same-origin`
   + `idPolicy:strict` (+ `svg:false`) in one switch, for locked-down deployments?
3. **SVG scope:** ship only the current subset, or also add commonly-needed safe
   elements (`ellipse`, `defs`, `symbol`, `title`, `desc`, `tspan`) in the same
   pass?
4. **id escape hatch:** ship the `#!rawfrag` opt-out in v1.6, or defer until asked?
