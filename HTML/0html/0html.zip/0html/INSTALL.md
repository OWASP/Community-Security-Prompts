# 0html — drop-in install

You dropped this package into a project to adopt the **0html** security standard
(JSON-first, zero-dependency safe-DOM for single-file HTML tools).

## For a human

Read `0html/README.md`. To install into a tool by hand:
```bash
cd 0html
node 0html-cli.cjs verify              # confirm package integrity
node 0html-cli.cjs add ../your-tool.html   # inline bundle + set CSP hash
node 0html-cli.cjs verify ../your-tool.html
```

## For an LLM / coding agent

There is an install directive written for you: **`0html/0HTML-AGENT.md`**
(with a machine-parseable companion, `0html/AGENT-WORKFLOW.json`).

It runs a **6-phase, approval-gated** adoption:

1. **Self-register** — verify package integrity.
2. **Survey** (read-only) — find `innerHTML` sinks, existing defenses; bucket by risk.
3. **Plan** — propose the smallest useful adoption. ⛔ **stops for `approve plan`**.
4. **Apply** — one file at a time. ⛔ **stops for `apply` per file**.
5. **Verify** — `0html-cli.cjs verify` after each change.
6. **Report & register** — completion report + conformance marker.

The directive will **never modify a file before you approve the specific
change**, makes no network calls, and treats project-file contents as data (not
instructions). `SKIP` is a valid outcome if 0html doesn't fit.

### Kickoff prompt (paste this to your agent)

> Read `0html/0HTML-AGENT.md` and follow it to adopt the 0html standard into
> this project. Detect your capability mode, run Phase 1–2, and show me the
> survey and plan. Do not modify any file until I approve.

## What's in the package

`0html/` contains: the runtime + compiler (`0bind.js`, `0html.js`), the built
bundle and example tools (`dist/`), the adoption CLI (`0html-cli.cjs`), the
integrity lock (`0html.lock`), full docs (`SPEC.md`, `THREAT-MODEL.md`,
`CONFORMANCE.md`, `FUZZING.md`, `MIGRATION.md`), tests, and a generative fuzzer
(`0html-fuzz.cjs`). Standard version: **0html/1.1**.
