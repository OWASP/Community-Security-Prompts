# What 0html Does to a Project

**In one sentence:** 0html adds layered, opt-in Content-Security-Policy and DOM hardening
to a single-file HTML tool as reversible, individually-verified layers behind a
tamper-evident conformance gate — turning "we should harden this" into a maintainable,
tested build invariant.

It is a **rendering/platform trust boundary**, not a total security system, and it is
deliberate about saying what it does *not* do (see §5).

---

## 1. How it's applied

```
survey  →  pick a tier  →  (convert handlers)  →  apply  →  conformance gate  →  browser-verify
  L0        safe/rec/max     if L2 reports them    per-layer   --require=<tier>     before shipping
```

- `node 0html-layers.cjs layers <file>` — read-only survey: CSP posture, `innerHTML`
  sinks bucketed by risk, inline handlers, which layers apply, **plus a SECURITY NOTES
  pass** flagging CSP weaknesses (`unsafe-eval`, broad/`*` sources, missing hardening
  directives, `style-src 'unsafe-inline'`) and external-resource SRI status.
- `node 0html-layers.cjs apply <file> --tier=recommended` (or `--layers=1,2,3`) — applies
  a batch; each layer backs up (`.0html.bak`), applies, and self-verifies.
- `node 0html-layers.cjs conformance <file> --require=1,2,3` — tamper-evident attestation
  with a CI exit code; **`--require` enforces a minimum**, not just internal consistency.

Every mutating step is behind approval, halts on a failed verify, makes no network calls,
and treats project-file text as data. Each layer is **idempotent** and **reversible**
(`unapply --layer=N` reverses exactly what that layer added).

**Tiers:** `safe` = L1 + L3 · `recommended` = L1 + L2 + L3 · `max` = L1 + L2 + L3 + L4 + L7.

---

## 2. The layers — what each does and what it changes in your files

| Layer | Does | Changes in your files | Cost |
|---|---|---|---|
| **L1** CSP baseline | adds `frame-ancestors`, `base-uri`, `object-src`, `form-action` if missing | merges directives into the CSP meta | very low, non-breaking |
| **L2** drop `'unsafe-inline'` | hash-pins inline `<script>`s, removes `'unsafe-inline'` from `script-src` | adds `'sha256-…'` per inline script; needs handlers converted first | medium; **re-pin each build** |
| **L3** TT report-only | adds `require-trusted-types-for 'script'` as a *separate* Report-Only meta | one new meta tag (no script change) | low, non-breaking (diagnostic) |
| **L4** TT enforce | registers a **default** TT policy + flips enforce on the main CSP | adds a small policy `<script>`; adds the enforce directive; re-pins L2 | high; **browser-verify** |
| **L5** connect-src allowlist | replaces `connect-src *` with your origins | rewrites `connect-src` (needs `--origins=`) | medium; app-aware, partial for arbitrary-URL apps |
| **L8** style-src hardening | hash-pins `<style>` blocks, drops `style-src 'unsafe-inline'` | adds style hashes; blocks on inline `style=` attrs | medium; often blocked by inline styles |
| **L7** JSON compiler | renders UI through the 0html allowlist compiler | inlines the bundle; rewrites rendering | high; the real sanitizer |
| **convert-handlers** | inline `on*=` → `addEventListener` (with `return false` → `preventDefault`) | strips `on*` attrs, adds `data-0h` hooks + a wiring `<script>` | prerequisite for L2 |
| **audit-secrets** (L6) | reports `localStorage`/`sessionStorage` secret writes + guidance | none — advisory only | — |
| **audit-sri** | verifies external `<script>`/`<link>` have Subresource Integrity (recomputes + checks the hash) | none — reports gaps/mismatches, CI-gateable | — |

---

## 3. What it protects (threats it closes or backstops)

- **Clickjacking** — `frame-ancestors 'none'` (L1).
- **Injected inline `<script>` / `on*` handler execution** — hash-pinned `script-src` with
  no `'unsafe-inline'` (L2 + convert-handlers). Even if a DOM sink regresses, an injected
  inline script is refused by CSP.
- **Base-tag hijack, plugin/`object` injection, form exfiltration** — L1 directives.
- **String→script (`eval`, dynamic script)** — L4's default policy **throws** on
  `createScript`/`createScriptURL`.
- **DOM-XSS platform backstop** — L4 enforce routes all HTML through one choke point (with
  the caveat in §5), and L3 report-only surfaces which sinks need attention first.
- **Data exfiltration to arbitrary hosts** — L5 scopes `connect-src` to your endpoints
  (when they're enumerable).
- **CSS injection / CSS exfil** — L8 drops `style-src 'unsafe-inline'` (for `<style>`-only
  tools).
- **Supply-chain / drift** — `conformance` is tamper-evident (`sha256`) and CI-gated; the
  engine + registry are integrity-pinned in `0html.lock` (checked by `0html-cli verify`);
  and **`audit-sri`** verifies external resources carry a correct Subresource Integrity
  hash. Integrity is thus covered end-to-end: **inline** scripts (L2 hash-pin), the
  **toolchain** (lock), and **external** resources (SRI).

---

## 4. What it changes in the built output (summary)

- **CSP meta** — tightened/added directives; `'unsafe-inline'` replaced by script hashes.
- **Inline scripts** — their `sha256` added to `script-src` (recomputed each build).
- **Inline handlers** — converted to `addEventListener` + one wiring `<script>`;
  `data-0h` hooks on the elements.
- **A conformance marker** — an HTML comment recording adopted layers, for `verify`.
- **(L3)** a Report-Only meta; **(L4)** a default-TT-policy `<script>`.

Your **source** is unchanged when hardening runs at build time — the transforms apply to
the built file, and (because L2's hashes track the built scripts) run every build.

---

## 5. What it does NOT do (honest limits — read these)

- **It is not an HTML sanitizer.** L4's default policy is a **choke point, not
  sanitization** — it passes HTML through (so existing escaped sinks don't break) and only
  blocks string→script. For real HTML sanitization, adopt **L7** (the allowlist compiler)
  or supply a sanitizing policy. Do not read "Trusted Types enforce" as DOM-XSS immunity.
- **`connect-src` can't scope an arbitrary-URL app.** If users type any URL, L5 is partial
  (allowlist the fixed set + warn). **Navigation exfil** (`location = 'evil?'+data`,
  `window.open`) is out of scope for any CSP.
- **A browser-only app can't isolate secrets.** L6 is advisory; TT/CSP reduce rogue-script
  odds but don't hide a key any script can read. The real fix is a server-side token.
- **Inline `style=` attributes block L8.** Move them to `<style>`/classes first.
- **Prompt injection / input safety is orthogonal.** 0html is *output* (DOM) safety.
- **Runtime behaviour needs a browser.** L2 (loads without `'unsafe-inline'`), L3/L4 (TT
  console/violations), and converted handlers are **structurally** verified headless but
  must be confirmed in a browser before shipping.
- **The converter's parser is regex-based** and can mis-parse unusual HTML; browser-verify
  converted output.

---

## 6. Why layered + gated (the design)

- **Opt-in** — you choose the posture (a tier, or individual layers); "do nothing" is a
  valid outcome if 0html doesn't fit.
- **Reversible** — each layer un-applies exactly what it added; nothing is one-way.
- **Individually verified** — each layer has a check; `conformance` attests the whole set
  and gates CI with `--require`.
- **Honest by doctrine** — residuals are documented in the THREAT-MODEL, not faked. A
  control that *looks* stronger than it is (a passthrough posing as enforce, a consistency
  check posing as a floor) is worse than none, because it invites misplaced trust. 0html's
  guarantees are written to be *relied on*, and its non-guarantees to be *seen*.

---

## 7. Adopting into a build (keeps the hash-pin fresh)

Because L2's hashes track the built scripts, run the hardening as the **last build step**
and gate on conformance, so a rebuild never leaves a stale hash:

```sh
# after your build writes dist/app.html:
node 0html/0html-layers.cjs convert-handlers dist/app.html          # if L2 reports handlers
node 0html/0html-layers.cjs apply dist/app.html --tier=recommended
node 0html/0html-layers.cjs conformance dist/app.html --require=1,2,3   # fails the build on drift
```

CI runs `0html-cli verify` (integrity) before the build, and the conformance gate after.
See the `ci-examples/` in the package and, for a worked integration, 0ui's `HARDENING.md`.
