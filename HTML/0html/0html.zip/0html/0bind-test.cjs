// 0bind-test.cjs — zero-dependency security + behavior tests
// Uses a tiny in-file DOM shim (no jsdom). Run: node 0bind-test.cjs

'use strict';

// ─────────────────────────────────────────────────────────────
// Minimal DOM shim — just enough to exercise 0bind's sinks.
// Records everything so we can assert no raw HTML slips through.
// ─────────────────────────────────────────────────────────────
let SCRIPT_EXECUTIONS = 0;   // bumped if any <script> "runs" (it never should)

class Node {
  constructor() { this.childNodes = []; this.nodeType = 1; }
  appendChild(c) {
    if (c instanceof DocumentFragment) {
      for (const k of c.childNodes.slice()) this.appendChild(k);
      return c;
    }
    c.parentNode = this; this.childNodes.push(c); return c;
  }
  get textContent() {
    return this.childNodes.map(c => c.textContent ?? '').join('');
  }
  set textContent(v) {
    // clears children, adds a single text node
    this.childNodes = [];
    if (v !== '') this.appendChild(new TextNode(String(v)));
  }
  // serialize to compare against XSS payloads
  serialize() {
    if (this.tagName === undefined) return this.textContent;
    let a = '';
    for (const [k, v] of Object.entries(this._attrs || {})) a += ` ${k}="${v}"`;
    const kids = this.childNodes.map(c => c.serialize ? c.serialize() : c.data).join('');
    return `<${this.tagName}${a}>${kids}</${this.tagName}>`;
  }
}
class TextNode {
  constructor(data) { this.data = String(data); this.nodeType = 3; }
  get textContent() { return this.data; }
  serialize() {
    // text nodes are inert — escape for display only
    return this.data.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }
}
class Element extends Node {
  constructor(tag) {
    super();
    this.tagName = String(tag).toLowerCase();
    this._attrs = {};
    this.dataset = {};
  }
  setAttribute(k, v) {
    this._attrs[k] = String(v);
    if (k.startsWith('data-')) {
      const camel = k.slice(5).replace(/-([a-z])/g, (_, c) => c.toUpperCase());
      this.dataset[camel] = String(v);
    }
    // Simulate a browser: assigning on*="..." would create a handler.
    // Our shim NEVER executes it, but we flag if one was ever set.
    if (k.toLowerCase().startsWith('on')) this._hadInlineHandler = true;
  }
  getAttribute(k) { return this._attrs[k]; }
  hasAttribute(k) { return Object.prototype.hasOwnProperty.call(this._attrs, k); }
  set id(v) { this._attrs.id = v; }
  get id() { return this._attrs.id; }
  set className(v) { this._attrs.class = v; }
  get className() { return this._attrs.class || ''; }
  addEventListener() { /* delegation target; not exercised in shim */ }
}
class Template extends Element {
  constructor() { super('template'); this.content = new DocumentFragment(); }
  set innerHTML(html) {
    // TT ENFORCE SIMULATION: if global.__TT_ENFORCE is set, a bare string
    // assignment throws — exactly like a real browser under
    // `require-trusted-types-for 'script'`. A TrustedHTML-marked value
    // (produced by the shim's policy) is accepted.
    if (global.__TT_ENFORCE && !(html && html.__isTrustedHTML)) {
      throw new TypeError("This document requires 'TrustedHTML' assignment.");
    }
    const raw = (html && html.__isTrustedHTML) ? html.toString() : String(html);
    // Simulate the browser's <template> parse: it does NOT run scripts.
    if (/<script[\s>]/i.test(raw)) {
      const s = new Element('script');
      s.appendChild(new TextNode(raw));
      this.content.appendChild(s);
    } else {
      const holder = new Element('span');
      holder.appendChild(new TextNode('[[HTML]]'));
      this.content.appendChild(holder);
    }
  }
}
class DocumentFragment extends Node {
  constructor() { super(); this.nodeType = 11; }
}
const document = {
  createElement: (t) => t === 'template' ? new Template() : new Element(t),
  createTextNode: (d) => new TextNode(d),
  createDocumentFragment: () => new DocumentFragment(),
  body: new Element('body'),
  addEventListener: () => {},
};
global.document = document;
global.Node = Node;
global.window = { addEventListener: () => {} };

// ─────────────────────────────────────────────────────────────
// Load 0bind against the shim.
// Repo is "type":"module", so 0bind.js is ESM to Node. Copy it to a
// .cjs temp so require() returns module.exports (the real object),
// not an empty ESM-interop namespace. (Same reason 0ui's tests are .cjs.)
// ─────────────────────────────────────────────────────────────
const fs = require('fs');
const os = require('os');
const pathm = require('path');
const _srcPath = pathm.join(__dirname, '0bind.js');
const _cjsPath = pathm.join(os.tmpdir(), `0bind-${process.pid}.cjs`);
fs.writeFileSync(_cjsPath, fs.readFileSync(_srcPath, 'utf8'));
const bind = require(_cjsPath);

// ─────────────────────────────────────────────────────────────
// Tiny test runner
// ─────────────────────────────────────────────────────────────
let pass = 0, fail = 0;
const eq = (name, got, want) => {
  const ok = got === want;
  console.log(`${ok ? '✓' : '✗'} ${name}`);
  if (!ok) { console.log(`    got:  ${JSON.stringify(got)}`); console.log(`    want: ${JSON.stringify(want)}`); fail++; } else pass++;
};
const ok = (name, cond) => eq(name, !!cond, true);

const XSS = [
  `<img src=x onerror=alert(1)>`,
  `<script>alert(1)</script>`,
  `"><svg/onload=alert(1)>`,
  `<iframe src=javascript:alert(1)>`,
  `<a href="javascript:alert(1)">x</a>`,
];

console.log('\n── SAFE DOM SINK: text never becomes markup ──');
for (const payload of XSS) {
  const node = bind.el('div');
  bind.setSafe(node, payload);
  // The payload must live as a TEXT node — serialize shows it escaped,
  // and there must be NO child element named from the payload.
  const hasElementChild = node.childNodes.some(c => c.tagName !== undefined);
  ok(`setSafe keeps as text (no element injected): ${payload.slice(0,24)}…`, !hasElementChild);
  ok(`  textContent preserved verbatim`, node.textContent === payload);
}

console.log('\n── el(): inline event handlers REFUSED (I2) ──');
{
  const n = bind.el('button', { onclick: 'alert(1)', onmouseover: 'x()' }, 'go');
  ok('onclick not set as attribute', !n.hasAttribute('onclick'));
  ok('onmouseover not set as attribute', !n.hasAttribute('onmouseover'));
  ok('no inline handler ever reached the element', !n._hadInlineHandler);
  ok('text child still added', n.textContent === 'go');
}

console.log('\n── el(): URL scheme allowlist (I3) ──');
{
  const bad = bind.el('a', { href: 'javascript:alert(1)' }, 'x');
  ok('javascript: href dropped', !bad.hasAttribute('href'));

  const bad2 = bind.el('img', { src: 'data:text/html,<script>alert(1)</script>' });
  ok('data: src dropped', !bad2.hasAttribute('src'));

  const obf = bind.el('a', { href: 'java\tscript:alert(1)' }, 'x');
  ok('control-char-obfuscated javascript: dropped', !obf.hasAttribute('href'));

  const good = bind.el('a', { href: 'https://0ui.ai/x' }, 'x');
  eq('https href kept', good.getAttribute('href'), 'https://0ui.ai/x');

  const rel = bind.el('a', { href: '/local/path' }, 'x');
  eq('relative href kept', rel.getAttribute('href'), '/local/path');

  const frag = bind.el('a', { href: '#section' }, 'x');
  eq('fragment href kept', frag.getAttribute('href'), '#section');

  const mail = bind.el('a', { href: 'mailto:a@b.com' }, 'x');
  eq('mailto kept', mail.getAttribute('href'), 'mailto:a@b.com');
}

console.log('\n── isSafeUrl() direct ──');
eq('blocks javascript:', bind.isSafeUrl('javascript:alert(1)'), false);
eq('blocks vbscript:', bind.isSafeUrl('vbscript:msgbox(1)'), false);
eq('blocks data:', bind.isSafeUrl('data:text/html,x'), false);
eq('allows https', bind.isSafeUrl('https://x.com'), true);
eq('allows relative', bind.isSafeUrl('foo/bar'), true);
eq('allows anchor', bind.isSafeUrl('#top'), true);
eq('blocks empty', bind.isSafeUrl(''), false);
eq('blocks null', bind.isSafeUrl(null), false);

console.log('\n── trust(): only path to raw HTML, and scripts DO NOT execute ──');
{
  SCRIPT_EXECUTIONS = 0;
  const node = bind.el('div');
  // Even wrapping a script in trust() must not EXECUTE it (template parse).
  bind.setSafe(node, bind.trust('<script>global.__PWNED=1</script>'));
  ok('script inside trust() did not execute', global.__PWNED === undefined);
  ok('SCRIPT_EXECUTIONS stayed 0', SCRIPT_EXECUTIONS === 0);
  // trusted non-script HTML round-trips (represented by shim as [[HTML]])
  const n2 = bind.el('div');
  bind.setSafe(n2, bind.trust('<b>bold</b>'));
  ok('trusted HTML produced a child node', n2.childNodes.length > 0);
}

console.log('\n── el(): tag.class#id parsing ──');
{
  const n = bind.el('button.primary.big#go');
  eq('tag', n.tagName, 'button');
  eq('classes', n.className, 'primary big');
  eq('id', n.id, 'go');
}

console.log('\n── frag(): multiple children, single container ──');
{
  const f = bind.frag('a', bind.el('span', null, 'b'), 'c');
  eq('fragment child count', f.childNodes.length, 3);
}

console.log('\n── clear(): empties node ──');
{
  const n = bind.el('div', null, 'x', 'y', 'z');
  ok('has children before', n.childNodes.length === 3);
  bind.clear(n);
  eq('empty after clear', n.childNodes.length, 0);
}

console.log('\n── event registry: name → handler lookup (no eval of DOM) ──');
{
  let called = 0, gotArg = null;
  bind.on('save', (e, elm, ctx) => { called++; gotArg = ctx.arg; });
  ok('handler registered', bind._registry.has('save'));
  // simulate dispatch by pulling the handler and invoking as the layer would
  const btn = bind.el('button', { 'data-on-click': 'save', 'data-arg': 'rows' }, 'save');
  const handler = bind._registry.get('save');
  handler({ preventDefault(){} }, btn, { arg: btn.dataset.arg, name: 'save', type: 'click' });
  eq('handler invoked', called, 1);
  eq('ctx.arg passed from data-arg', gotArg, 'rows');
  bind.off('save');
  ok('handler removed', !bind._registry.has('save'));
}

console.log('\n── unknown handler name: no throw, warns only ──');
{
  // registry miss must not crash — covered by dispatch guard; assert lookup
  ok('missing handler returns undefined (safe)', bind._registry.get('nope') === undefined);
}

console.log('\n────────────────────────────────────────');
console.log(`  ${pass} passed, ${fail} failed`);
console.log('────────────────────────────────────────\n');
process.exit(fail ? 1 : 0);
