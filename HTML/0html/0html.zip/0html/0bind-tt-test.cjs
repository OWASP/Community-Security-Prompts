// 0bind-tt-test.cjs — J7: 0html operates under Trusted Types enforce mode.
// Sets up a TT shim BEFORE loading 0bind, flips enforce ON, and proves
// trust() still renders while a bare string assignment would throw.
// Run: node 0bind-tt-test.cjs

'use strict';

// ── TrustedHTML marker the shim policy produces ────────────────
class ShimTrustedHTML {
  constructor(s) { this.__isTrustedHTML = true; this._s = String(s); }
  toString() { return this._s; }
}

// ── minimal DOM shim with TT-enforce-aware <template> ──────────
class Node { constructor(){ this.childNodes=[]; this.nodeType=1; }
  appendChild(c){ if(c instanceof DocumentFragment){ for(const k of c.childNodes.slice()) this.appendChild(k); return c; } c.parentNode=this; this.childNodes.push(c); return c; }
  get textContent(){ return this.childNodes.map(c=>c.textContent??'').join(''); }
  set textContent(v){ this.childNodes=[]; if(v!=='') this.appendChild(new TextNode(String(v))); } }
class TextNode { constructor(d){ this.data=String(d); this.nodeType=3; } get textContent(){ return this.data; } }
class Element extends Node { constructor(t){ super(); this.tagName=String(t).toLowerCase(); this._attrs={}; this.dataset={}; }
  setAttribute(k,v){ this._attrs[k]=String(v); } getAttribute(k){ return this._attrs[k]; }
  hasAttribute(k){ return Object.prototype.hasOwnProperty.call(this._attrs,k); }
  set id(v){ this._attrs.id=v; } set className(v){ this._attrs.class=v; } get className(){ return this._attrs.class||''; }
  addEventListener(){} }
class Template extends Element {
  constructor(){ super('template'); this.content=new DocumentFragment(); }
  set innerHTML(html){
    // ENFORCE: bare string throws; only a TrustedHTML marker passes.
    if (global.__TT_ENFORCE && !(html && html.__isTrustedHTML)) {
      throw new TypeError("This document requires 'TrustedHTML' assignment.");
    }
    const raw = (html && html.__isTrustedHTML) ? html.toString() : String(html);
    const holder = new Element('span'); holder.appendChild(new TextNode(raw)); this.content.appendChild(holder);
  }
}
class DocumentFragment extends Node { constructor(){ super(); this.nodeType=11; } }
global.document = {
  createElement:(t)=> t==='template'? new Template(): new Element(t),
  createTextNode:(d)=> new TextNode(d),
  createDocumentFragment:()=> new DocumentFragment(),
  body:new Element('body'), addEventListener:()=>{},
};
global.Node = Node;

// ── TT shim: createPolicy returns a policy whose createHTML wraps ──
let policyName = null;
global.window = {
  addEventListener: ()=>{},
  trustedTypes: {
    createPolicy(name, rules){
      policyName = name;
      return { name, createHTML: (s)=> new ShimTrustedHTML(rules.createHTML(s)) };
    }
  }
};

// ── enable enforce mode, THEN load 0bind fresh ─────────────────
global.__TT_ENFORCE = true;
const fs=require('fs'), os=require('os'), pathm=require('path');
const cjs = pathm.join(os.tmpdir(), `0bind-tt-${process.pid}.cjs`);
fs.writeFileSync(cjs, fs.readFileSync(pathm.join(__dirname,'0bind.js'),'utf8'));
const bind = require(cjs);

// ── runner ─────────────────────────────────────────────────────
let pass=0, fail=0;
const ok=(n,c)=>{ const p=!!c; console.log(`${p?'✓':'✗'} ${n}`); p?pass++:fail++; };
const eq=(n,g,w)=>{ const p=g===w; console.log(`${p?'✓':'✗'} ${n}`); if(!p){console.log(`    got ${JSON.stringify(g)} want ${JSON.stringify(w)}`); fail++;} else pass++; };

console.log('\n── J7: Trusted Types enforce mode ──');
eq('0html registered its own namespaced policy', policyName, '0html');
ok('bind.ttActive is true under TT', bind.ttActive === true);

// control: a bare template assignment MUST throw in enforce mode
{
  let threw=false;
  try { const t=document.createElement('template'); t.innerHTML='<b>x</b>'; }
  catch(e){ threw = e instanceof TypeError; }
  ok('control: bare innerHTML string throws under enforce', threw);
}

// the actual proof: trust() renders WITHOUT throwing under enforce
{
  let threw=false, node=null;
  try {
    node = bind.el('div');
    bind.setSafe(node, bind.trust('<b>rendered under TT</b>'));
  } catch(e){ threw=true; console.log('    unexpected throw:', e.message); }
  ok('trust() does NOT throw under TT enforce', !threw);
  ok('trust() produced content under TT', node && node.childNodes.length>0);
  ok('content routed through policy (text present)', node && node.textContent.includes('rendered under TT'));
}

// scripts STILL do not execute, even routed through the policy
{
  delete global.__PWNED;
  const n = bind.el('div');
  bind.setSafe(n, bind.trust('<script>global.__PWNED=1</script>'));
  ok('script through TT policy did not execute', global.__PWNED === undefined);
}

// el() + text still fine under enforce (no raw sink involved)
{
  const n = bind.el('button', { 'data-on-click':'x' }, '<img onerror=alert(1)>');
  ok('plain text child stays inert under TT', n.textContent === '<img onerror=alert(1)>');
  ok('no element injected from text under TT', n.childNodes.every(c=>c.tagName===undefined));
}

console.log('\n────────────────────────────────────────');
console.log(`  ${pass} passed, ${fail} failed`);
console.log('────────────────────────────────────────\n');
process.exit(fail?1:0);
