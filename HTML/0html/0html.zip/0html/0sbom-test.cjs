// 0sbom-test.cjs — validates the CycloneDX 1.6 SBOM the CLI emits.
//   • correct CycloneDX envelope + metadata
//   • every component hash (hex SHA-256) matches the real file on disk
//   • ZERO external-dependency components (0html's core claim, machine-checked)
//   • dependency graph is internally consistent (no dangling refs)
// Regenerates the SBOM via the real CLI, so it tests the shipped code path.
// Requires a prior build (dist/0html.bundle.js present). Run: node 0sbom-test.cjs
'use strict';
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const { execFileSync } = require('child_process');

const DIR = __dirname;
const CDX = path.join(DIR, 'dist', '0html.cdx.json');
const hx = (p) => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');

let pass = 0, fail = 0;
const ok = (n, c) => { const g = !!c; console.log(`${g ? '✓' : '✗ FAIL'} ${n}`); g ? pass++ : fail++; };

// regenerate via the real CLI
execFileSync('node', [path.join(DIR, '0html-cli.cjs'), 'sbom'], { cwd: DIR, stdio: 'ignore' });
ok('CLI produced dist/0html.cdx.json', fs.existsSync(CDX));

let bom;
try { bom = JSON.parse(fs.readFileSync(CDX, 'utf8')); ok('SBOM is valid JSON', true); }
catch (e) { ok('SBOM is valid JSON', false); console.log(e.message); process.exit(1); }

console.log('\n── CycloneDX envelope ──');
ok('bomFormat = CycloneDX', bom.bomFormat === 'CycloneDX');
ok('specVersion = 1.6', bom.specVersion === '1.6');
ok('serialNumber is a urn:uuid', /^urn:uuid:[0-9a-f-]{36}$/i.test(bom.serialNumber || ''));
ok('version is a positive integer', Number.isInteger(bom.version) && bom.version >= 1);

console.log('\n── metadata ──');
ok('metadata.timestamp parses as a date', !Number.isNaN(Date.parse(bom.metadata?.timestamp)));
ok('metadata.tools lists 0html-cli', (bom.metadata?.tools?.components || []).some(t => t.name === '0html-cli'));
ok('primary component is 0html (library)', bom.metadata?.component?.name === '0html' && bom.metadata.component.type === 'library');
ok('primary component has a purl', /^pkg:generic\/0html@/.test(bom.metadata?.component?.purl || ''));
const props = Object.fromEntries((bom.metadata?.properties || []).map(p => [p.name, p.value]));
ok('declares 0 external runtime dependencies', props['0html:externalRuntimeDependencies'] === '0');

console.log('\n── components + hash accuracy ──');
const comps = bom.components || [];
ok('has the expected core components', ['0bind', '0html-compiler', '0html.bundle.js'].every(n => comps.some(c => c.name === n)));
const fileFor = {
  '0bind': path.join(DIR, '0bind.js'),
  '0html-compiler': path.join(DIR, '0html.js'),
  '0html.bundle.js': path.join(DIR, 'dist', '0html.bundle.js'),
};
let hashOk = true, hashChecked = 0;
for (const c of comps) {
  const fp = fileFor[c.name] || (c.type === 'file' ? path.join(DIR, c.name) : null);
  if (!fp || !fs.existsSync(fp)) continue;
  const want = (c.hashes || []).find(h => h.alg === 'SHA-256');
  if (!want) { hashOk = false; console.log('    missing SHA-256 for', c.name); continue; }
  hashChecked++;
  if (!/^[0-9a-f]{64}$/.test(want.content)) { hashOk = false; console.log('    non-hex hash for', c.name); }
  if (want.content !== hx(fp)) { hashOk = false; console.log('    hash MISMATCH for', c.name); }
}
ok(`every component hash is hex SHA-256 and matches its file (${hashChecked} checked)`, hashOk && hashChecked >= 3);

console.log('\n── zero external dependencies (the core claim) ──');
const externalPurl = /^pkg:(npm|pypi|maven|gem|cargo|composer|golang|nuget)\//i;
const externals = comps.filter(c => externalPurl.test(c.purl || ''));
ok('no external-ecosystem components present', externals.length === 0);

console.log('\n── dependency graph integrity ──');
const deps = bom.dependencies || [];
const refs = new Set([bom.metadata?.component?.['bom-ref'], ...comps.map(c => c['bom-ref'])].filter(Boolean));
let danglers = [];
for (const d of deps) {
  if (!refs.has(d.ref)) danglers.push(d.ref);
  for (const on of (d.dependsOn || [])) if (!refs.has(on)) danglers.push(on);
}
ok('no dangling dependency refs', danglers.length === 0);
if (danglers.length) console.log('    dangling:', danglers.slice(0, 6));
ok('bundle depends on both 0bind and 0html-compiler',
   deps.some(d => d.ref === '0html.bundle.js' && ['0bind', '0html-compiler'].every(x => (d.dependsOn || []).includes(x))));

console.log(`\n────────────────────────────────────────`);
console.log(`  ${pass} passed, ${fail} failed  (CycloneDX SBOM)`);
console.log(`────────────────────────────────────────`);
process.exit(fail ? 1 : 0);
