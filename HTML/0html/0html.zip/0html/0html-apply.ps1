<#
╔══════════════════════════════════════════════════════════════════════════╗
║  0html-apply.ps1 — apply the review patch, build, test, verify           ║
╚══════════════════════════════════════════════════════════════════════════╝

  .\0html-apply.ps1 [-Patch FILE] [-NoTest] [-Yes]

Run from a 0html package root. Idempotent: if the patch is already applied it
skips straight to build + verify.

This is a DRIVER, not a second build. Everything that decides what bytes land
in dist/ is done by 0build.cjs — the same module 0html-apply.sh calls. A
PowerShell re-implementation of those rules is precisely how findings #23–#29
happened: one rule expressed twice, drifting apart. So there is no awk, no sed
and no openssl here, and nothing platform-specific touches file contents.

Requires: node 18+, and git (or patch) to apply the diff.
Optional:  python3   → scanner differential vs html.parser
           playwright → in-browser verification of the shipped tools
#>
[CmdletBinding()]
param(
  [string]$Patch = "0html-1.9.1-consolidated.patch",
  [switch]$NoTest,
  [switch]$Yes
)

$ErrorActionPreference = 'Stop'

function Say  { param($m) Write-Host $m }
function OK   { param($m) Write-Host "  " -NoNewline; Write-Host "OK  " -ForegroundColor Green -NoNewline; Write-Host $m }
function Warn { param($m) Write-Host "  " -NoNewline; Write-Host "!   " -ForegroundColor Yellow -NoNewline; Write-Host $m }
function Die  { param($m) Write-Host "  " -NoNewline; Write-Host "X   " -ForegroundColor Red -NoNewline; Write-Host $m; exit 1 }
function Have { param($c) $null -ne (Get-Command $c -ErrorAction SilentlyContinue) }

# Run a command, stream its output, and fail on a non-zero exit code.
function Invoke-Step {
  param([string]$Exe, [string[]]$Args, [string]$What)
  & $Exe @Args
  if ($LASTEXITCODE -ne 0) { Die "$What failed (exit $LASTEXITCODE)" }
}

Say ""
Say "  0html - apply + build + verify"
Say "  --------------------------------------------"

# ── preconditions ───────────────────────────────────────────────
if (-not (Test-Path '0bind.js') -or -not (Test-Path '0html.js')) {
  Die "run this from a 0html package root (0bind.js not found)"
}
if (-not (Have 'node')) { Die "node is required and was not found on PATH" }

$nodeMajor = [int](& node -p "process.versions.node.split('.')[0]")
if ($nodeMajor -lt 18) { Die "node 18+ required (found $(& node -v))" }
OK "node $(& node -v)"

if ((Have 'python3') -or (Have 'python')) { OK "python - scanner differential enabled" }
else { Warn "python3 not found - the differential vs html.parser will be SKIPPED" }

& node -e "require('playwright')" 2>$null
if ($LASTEXITCODE -eq 0) { OK "playwright - in-browser verification enabled" }
else {
  Warn "playwright not found - 0browser-test will SKIP."
  Warn "  that suite is what caught #35 (two security controls refused by the"
  Warn "  page's own CSP). Consider making it a hard requirement in CI."
}

# ── apply, if needed ────────────────────────────────────────────
$current = & node -p "(require('fs').readFileSync('0bind.js','utf8').match(/version: *'([0-9.]+)'/)||[])[1]||'?'"

if ((Test-Path '0scan-html.cjs') -and (Test-Path '0csp-hashes.cjs')) {
  OK "patch already applied (version $current) - rebuilding"
} else {
  if (-not (Test-Path $Patch)) { Die "patch not found: $Patch   (use -Patch FILE)" }
  if (-not $Yes) {
    Say ""
    Say "  About to patch this tree (currently $current) with:"
    Say "    $Patch"
    $reply = Read-Host "  Continue? [y/N]"
    if ($reply -notmatch '^(y|Y|yes|YES)$') { Die "aborted" }
  }
  if (Have 'git') {
    & git apply --whitespace=nowarn $Patch
    if ($LASTEXITCODE -ne 0) { Die "git apply failed" }
  } elseif (Have 'patch') {
    & patch -p1 --forward -i $Patch | Out-Null
    if ($LASTEXITCODE -ne 0) { Die "patch failed to apply cleanly" }
  } else {
    Die "neither 'git' nor 'patch' found - install Git for Windows, or apply the patch manually"
  }
  OK "patch applied"
  if (Test-Path 'scanner-harness.cjs') {
    Remove-Item 'scanner-harness.cjs' -Force
    OK "removed obsolete scanner-harness.cjs"
  }
}

# ── build ───────────────────────────────────────────────────────
# build.sh is POSIX shell. If a bash is present (Git for Windows ships one) use
# it, so Windows runs the identical pipeline including the test phases.
# Otherwise fall back to 0build.cjs plus the suites invoked directly — same
# build either way, since build.sh only orchestrates.
Say ""
Say "  building"

$bash = $null
foreach ($c in @('bash', "$env:ProgramFiles\Git\bin\bash.exe", "${env:ProgramFiles(x86)}\Git\bin\bash.exe")) {
  if ((Have $c) -or (Test-Path -LiteralPath $c -ErrorAction SilentlyContinue)) { $bash = $c; break }
}

if ($bash) {
  $buildArgs = if ($NoTest) { @('build.sh') } else { @('build.sh', '--test') }
  Invoke-Step $bash $buildArgs "build"
} else {
  Warn "no bash found - running 0build.cjs and the suites directly"
  Invoke-Step 'node' @('0build.cjs') "build"

  if (-not $NoTest) {
    $sourceSuites = @('0bind-test','0html-test','0bind-tt-test','0harden2-test','0urlmode-test',
                      '0idpolicy-test','0svg-test','0advise-test','0cssesc-test','0cspval-test',
                      '0handlers-test','0sri-test','0l5l8-test','0tt-test','0clobber-test','0layers-test')
    foreach ($s in $sourceSuites) {
      if (Test-Path "$s.cjs") { Invoke-Step 'node' @("$s.cjs") $s }
    }
    Invoke-Step 'node' @('0scanner-fuzz.cjs','2000','42') "scanner fuzz"
    if (Have 'python3') { Invoke-Step 'node' @('0scanner-diff.cjs','800','42') "scanner differential" }

    # artifact suites AFTER the build - they read dist/ (#36)
    foreach ($s in @('0hardening-test','0scan-test','0sbom-test','0pin-test','0browser-test')) {
      if (Test-Path "$s.cjs") { Invoke-Step 'node' @("$s.cjs") $s }
    }
    Invoke-Step 'node' @('0html-fuzz.cjs','2000','42') "spec fuzz"
  }

  Invoke-Step 'node' @('0html-cli.cjs','pin')  "pin"
  Invoke-Step 'node' @('0html-cli.cjs','sbom') "sbom"
  if (-not $NoTest -and (Test-Path '0verify-test.cjs')) {
    Invoke-Step 'node' @('0verify-test.cjs') "0verify-test"
  }
}

# ── verify ──────────────────────────────────────────────────────
Say ""
Say "  verifying"
& node 0html-cli.cjs verify | Out-Null
if ($LASTEXITCODE -ne 0) { Die "integrity verify failed" }
OK "bundle + toolchain + SBOM integrity"

foreach ($t in @('dist/0html-starter.html', 'dist/0scan.html')) {
  if (Test-Path $t) {
    & node 0html-cli.cjs verify $t | Out-Null
    if ($LASTEXITCODE -ne 0) { Die "$t failed verification" }
    OK $t
  }
}

$ver = & node -p "(require('fs').readFileSync('0bind.js','utf8').match(/version: *'([0-9.]+)'/)||[])[1]"
Say ""
Say "  --------------------------------------------"
OK "0html $ver - built, tested, verified"
Say ""
Say "  The shipped v1.8.0 dist/ artifacts did not execute at all (#15), so"
Say "  rebuilding is mandatory, not optional. dist/ is now regenerated."
Say ""
