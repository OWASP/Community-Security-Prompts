// 0advise-test.cjs — advise() detection + presets.
// Zero-dep, in-file DOM shim. Run: node 0advise-test.cjs
'use strict';

class Node { constructor(){ this.childNodes=[]; this.nodeType=1; }
  appendChild(c){ if(c instanceof DocumentFragment){for(const k of c.childNodes.slice())this.appendChild(k);return c;} c.parentNode=this; this.childNodes.push(c); return c; }
  get textContent(){ return this.childNodes.map(c=>c.textContent??'').join(''); }
  set textContent(v){ this.childNodes=[]; if(v!=='')this.appendChild(new TextNode(String(v))); } }
class TextNode{ constructor(d){ this.data=String(d); this.nodeType=3; } get textContent(){ return this.data; } }
class Element extends Node { constructor(tag, ns){ super(); this.tagName=String(tag).toLowerCase(); this.namespaceURI=ns||null; this._attrs={}; this._attrsNS={}; this.dataset={}; }
  setAttribute(k,v){ this._attrs[k]=String(v); } setAttributeNS(ns,k,v){ this._attrs[k]=String(v); this._attrsNS[k]=ns; }
  getAttribute(k){ return this._attrs[k]; } hasAttribute(k){ return k in this._attrs; }
  set id(v){ this._attrs.id=v; } get id(){ return this._attrs.id; }
  set className(v){ this._attrs.class=v; } get className(){ return this._attrs.class||''; } addEventListener(){} }
class Template extends Element { constructor(){ super('template'); this.content=new DocumentFragment(); } set innerHTML(h){ this.content.appendChild(new Element('span')); } }
class DocumentFragment extends Node { constructor(){ super(); this.nodeType=11; } }
const document={ createElement:(t)=>t==='template'?new Template():new Element(t,null), createElementNS:(ns,t)=>new Element(t,ns), createTextNode:(d)=>new TextNode(d), createDocumentFragment:()=>new DocumentFragment(), body:new Element('body'), addEventListener:()=>{} };
global.document=document; global.Node=Node; global.window={ addEventListener:()=>{} };

const fs=require('fs'), os=require('os'), pathm=require('path');
const toCjs=(n)=>{const p=pathm.join(os.tmpdir(),`adv-${n}-${process.pid}.cjs`); fs.writeFileSync(p, fs.readFileSync(pathm.join(__dirname,`${n}.js`),'utf8')); return p;};
global.OUI_BIND=require(toCjs('0bind'));
const html0=require(toCjs('0html'));

let pass=0, fail=0;
const ok=(n,c)=>{const g=!!c; console.log(`${g?'✓':'✗ FAIL'} ${n}`); g?pass++:fail++;};
const find=(r,policy)=> r.findings.find(f=>f.policy===policy);

// ═══════════════════════════════════════════════════════════════
console.log('\n── clean spec: nothing suggested ──');
{
  const r = html0.advise({ tag:'div', children:[
    { tag:'a', attrs:{ href:'/local/page' } },
    { tag:'img', attrs:{ src:'img.png' } },
    { tag:'p', text:'hello' },
  ]});
  ok('no findings on a clean same-origin spec', r.findings.length === 0);
  ok('recommended is empty', Object.keys(r.recommended).length === 0);
}

console.log('\n── detects off-origin URLs ──');
{
  const r = html0.advise({ tag:'div', children:[
    { tag:'a', attrs:{ href:'https://cdn.jsdelivr.net/x.js' } },
    { tag:'img', attrs:{ src:'//tracker.evil/beacon.gif' } },
    { tag:'a', attrs:{ href:'mailto:a@b.com' } },        // not counted
  ]});
  const f = find(r,'urlPolicy');
  ok('flags off-origin URLs', !!f && f.severity==='medium');
  ok('reports both external origins', r.externalOrigins.includes('https://cdn.jsdelivr.net') && r.externalOrigins.includes('https://tracker.evil'));
  ok('mailto not counted as external', !r.externalOrigins.some(o=>/mailto/.test(o)));
  ok('recommends same-origin WITHOUT auto-allowlisting the origins', JSON.stringify(r.recommended.urlPolicy) === JSON.stringify({mode:'same-origin'}));
}

console.log('\n── detects off-origin inside srcset ──');
{
  const r = html0.advise({ tag:'img', attrs:{ srcset:'/a.png 1x, https://evil.example/b.png 2x' } });
  ok('srcset external candidate detected', r.externalOrigins.includes('https://evil.example'));
}

console.log('\n── detects clobber-risk id/name ──');
{
  const r = html0.advise({ tag:'div', children:[
    { tag:'img', attrs:{ id:'location' } },
    { tag:'form', attrs:{ name:'constructor' } },
  ]});
  const f = find(r,'idPolicy');
  ok('high-severity idPolicy finding for global-ish ids', !!f && f.severity==='high');
  ok('recommends idPolicy strict', f && r.recommended.idPolicy.mode==='strict');
}

console.log('\n── mild id suggestion when only benign ids present ──');
{
  const r = html0.advise({ tag:'div', attrs:{ id:'myPanel' }, children:[{ tag:'input', attrs:{ id:'email' } }] });
  const f = find(r,'idPolicy');
  ok('low-severity namespace suggestion for benign ids', !!f && f.severity==='low' && r.recommended.idPolicy.mode==='namespace');
}

console.log('\n── detects inert SVG ──');
{
  const r = html0.advise({ tag:'div', children:[{ tag:'svg', children:[{ tag:'circle', attrs:{cx:'5'} },{ tag:'path', attrs:{d:'M0 0'} }] }] });
  const f = find(r,'svg');
  ok('info-severity svg finding', !!f && f.severity==='info');
  ok('recommends svg:true', r.recommended.svg === true);
  ok('lists svg tag types', r.svgTags.includes('svg') && r.svgTags.includes('circle') && r.svgTags.includes('path'));
}

console.log('\n── recommendation is spreadable into compile and actually enforces ──');
{
  const spec = { tag:'a', attrs:{ href:'https://evil.example/x' } };
  const rec = html0.advise(spec).recommended;         // { urlPolicy:{mode:'same-origin'} }
  const withRec = html0.compile(spec, rec);
  ok('applying the recommendation drops the off-origin URL', withRec._attrs.href === undefined);
}

console.log('\n── active policies suppress their finding ──');
{
  const spec = { tag:'a', attrs:{ href:'https://evil.example/x' } };
  const r = html0.advise(spec, { urlPolicy:{ mode:'same-origin' } });
  ok('no urlPolicy finding when same-origin already active', !find(r,'urlPolicy'));
}

console.log('\n── presets ──');
{
  // advise sees preset:strict as activating url same-origin + id strict → suppresses those
  const spec = { tag:'a', attrs:{ href:'https://evil.example/x', id:'location' } };
  const r = html0.advise(spec, { preset:'strict' });
  ok('preset strict suppresses url + id findings in advise', !find(r,'urlPolicy') && !find(r,'idPolicy'));

  // preset actually enforces in compile
  const n1 = html0.compile({ tag:'a', attrs:{ href:'https://evil.example/x' } }, { preset:'strict' });
  ok('preset strict enforces same-origin (off-origin dropped)', n1._attrs.href === undefined);
  const n2 = html0.compile({ tag:'div', attrs:{ id:'constructor' } }, { preset:'strict' });
  ok('preset strict enforces id strict (dangerous id refused)', n2._attrs.id === undefined);
  const n3 = html0.compile({ tag:'div', attrs:{ id:'panel' } }, { preset:'namespace' });
  ok('preset namespace prefixes ids', n3._attrs.id === '0h-panel');

  // explicit opts override preset
  const n4 = html0.compile({ tag:'a', attrs:{ href:'https://evil.example/x' } }, { preset:'strict', urlPolicy:{ mode:'any' } });
  ok('explicit opts override preset (urlPolicy any wins)', n4._attrs.href === 'https://evil.example/x');
}

console.log('\n── advise never throws / is bounded ──');
{
  let threw=false;
  try {
    let deep={ tag:'div' }, cur=deep;
    for (let i=0;i<500;i++){ cur.children=[{tag:'div'}]; cur=cur.children[0]; }
    html0.advise(deep);
    html0.advise(null); html0.advise('x'); html0.advise({});
  } catch(e){ threw=true; }
  ok('advise handles deep/degenerate input without throwing', !threw);
}

console.log(`\n────────────────────────────────────────`);
console.log(`  ${pass} passed, ${fail} failed  (advise + presets)`);
console.log(`────────────────────────────────────────`);
process.exit(fail ? 1 : 0);
