#!/usr/bin/env bash
# ╔═══════════════════════════════════════════════════════════════╗
# ║  build.sh — assemble 0html dist artifacts (single-file)        ║
# ╚═══════════════════════════════════════════════════════════════╝
# Zero external deps. Inlines 0bind + 0html into the playground and
# produces dist/ artifacts. Mirrors 0ui's combine.sh philosophy.
#
#   ./build.sh          — build everything to dist/
#   ./build.sh --test   — run test suites, then build
set -euo pipefail
cd "$(dirname "$0")"

DIST="dist"
mkdir -p "$DIST"

# ── run tests if asked ──────────────────────────────────────────
if [[ "${1:-}" == "--test" ]]; then
  echo "▶ running test suites"
  node 0bind-test.cjs
  node 0html-test.cjs
  node 0bind-tt-test.cjs
  node 0harden2-test.cjs
  node 0urlmode-test.cjs
  node 0idpolicy-test.cjs
  node 0svg-test.cjs
  node 0advise-test.cjs
  node 0cssesc-test.cjs
  node 0cspval-test.cjs
  node 0handlers-test.cjs
  node 0sri-test.cjs
  node 0l5l8-test.cjs
  node 0tt-test.cjs
  echo "▶ scanner fuzz (2k hostile documents, fixed seed)"
  node 0scanner-fuzz.cjs 2000 42
  if command -v python3 >/dev/null 2>&1; then
    echo "▶ scanner differential vs python3 html.parser"
    node 0scanner-diff.cjs 800 42
  else
    echo "▶ scanner differential skipped (python3 not found)"
  fi
  node 0clobber-test.cjs
  node 0layers-test.cjs      # 68 assertions — was never wired into the build
  echo "✓ core tests passed"
  echo
fi

# ── build: one Node implementation, shared with 0html-apply.ps1 ──
# Everything that decides what bytes land in dist/ lives in 0build.cjs, so the
# POSIX and Windows entry points cannot drift apart. It also retires the last
# `awk`: finding #15 — every shipped tool throwing SyntaxError for six releases
# — was awk collapsing "\\" to "\" in a -v assignment. Verified byte-identical
# to the previous shell build before the switch.
node 0build.cjs

# ── 6. integration test: 0scan against the BUILT bundle ─────────
# Runs after dist/ exists; proves the example tool contains hostile
# scan input under TT enforce using the exact bundle it ships with.
if [[ "${1:-}" == "--test" ]]; then
  echo
  # 0html-fuzz loads dist/0html.bundle.js, so it belongs HERE, not in the
  # pre-build block where it lived. There it exercised the PREVIOUS bundle: a
  # source change that introduced a vulnerability was checked against the old,
  # clean artifact and passed, and a freshly patched tree failed against a stale
  # one. The suite that most directly tests the shipped library could not see
  # the library the build was producing.
  # 0hardening-test also loads dist/0html.bundle.js — same reason as the fuzzer.
  node 0hardening-test.cjs
  echo "▶ fuzz smoke (2k adversarial specs, fixed seed) — against the bundle just built"
  node 0html-fuzz.cjs 2000 42
  echo "▶ integration: 0scan hostile-input containment"
  node 0scan-test.cjs
  node 0sbom-test.cjs
  node 0pin-test.cjs
  node 0browser-test.cjs
  echo "✓ integration passed"
fi

# ── 7. integrity: pin the bundle + self-verify (the standard) ───
# Always runs — a build that can't verify itself isn't a standard.
echo
echo "▶ integrity: pin + verify"
node 0html-cli.cjs pin
node 0html-cli.cjs sbom
node 0html-cli.cjs verify dist/0html-starter.html
node 0html-cli.cjs verify dist/0scan.html
echo "✓ integrity OK — bundle pinned, SBOM generated, tools verified"

# ── 8. attestation test: what does `verify <file>` actually prove? ──────
# Runs last: needs dist/ built AND the lock pinned above.
if [[ "${1:-}" == "--test" ]]; then
  echo
  echo "▶ attestation: verify ↔ tool binding"
  node 0verify-test.cjs
fi
