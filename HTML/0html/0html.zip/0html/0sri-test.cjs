#!/usr/bin/env node
/*
  0sri-test.cjs — audit-sri correctness.

  The command's one job is to tell you whether external code is pinned. It was
  two regexes requiring QUOTED attribute values and unable to cross a '>' inside
  an earlier attribute, so a page whose only external resource was

      <script src=https://cdn.example/only.js></script>

  audited as "✓ no external <script>/<link> — fully self-contained". It also
  reported valid multi-hash SRI as a MISMATCH, accepted md5-/sha1- pins as
  legitimate algorithms, aborted the whole run on an unknown one, and treated
  protocol-relative "//cdn/…" as a local file.
*/
'use strict';
const { execFileSync } = require('child_process');
const fs = require('fs'), os = require('os'), path = require('path'), crypto = require('crypto');
const ENGINE = path.join(__dirname, '0html-layers.cjs');
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), '0sri-'));
let pass = 0, fail = 0;
const ck = (n, c) => c ? (pass++, console.log('  \u2713 ' + n)) : (fail++, console.log('  \u2717 FAIL ' + n));
function run(f) {
  try { return { out: execFileSync('node', [ENGINE, 'audit-sri', f], { encoding: 'utf8' }), code: 0 }; }
  catch (e) { return { out: (e.stdout || '') + (e.stderr || ''), code: e.status || 1 }; }
}
let n = 0;
const fx = (html) => { const p = path.join(TMP, 'f' + (++n) + '.html'); fs.writeFileSync(p, html); return p; };
const page = (head) => `<!doctype html><html><head>\n${head}\n</head><body></body></html>`;

// a real local asset to pin
fs.writeFileSync(path.join(TMP, 'good.js'), 'console.log("hi");\n');
const digest = (algo) => crypto.createHash(algo).update(fs.readFileSync(path.join(TMP, 'good.js'))).digest('base64');
const S256 = digest('sha256'), S384 = digest('sha384');

console.log('\n-- external resources must not be invisible --');
{
  const f = fx(page(`<script src=https://cdn.example/only.js></script>`));
  const r = run(f);
  ck('unquoted src is found', /cdn\.example\/only\.js/.test(r.out));
  ck('does NOT claim fully self-contained', !/fully self-contained/.test(r.out));
  ck('exits non-zero', r.code !== 0);
}
{
  const f = fx(page(`<script data-n="a > b" src="https://cdn.example/hidden.js"></script>`));
  const r = run(f);
  ck('src behind a quoted ">" is found', /hidden\.js/.test(r.out));
  ck('flagged as missing integrity', /NO integrity/.test(r.out));
}
{
  const f = fx(page(`<link rel=stylesheet href=https://cdn.example/x.css>`));
  ck('unquoted <link rel=stylesheet> is found', /x\.css/.test(run(f).out));
}
{
  const f = fx(page(`<link rel="modulepreload" href="https://cdn.example/m.js">`));
  ck('modulepreload is covered', /m\.js/.test(run(f).out));
}

console.log('\n-- protocol-relative is remote, not local --');
{
  const f = fx(page(`<script src="//cdn.example/p.js"></script>`));
  const r = run(f);
  ck('//host reported as a CDN resource', /CDN resource/.test(r.out) && !/file not alongside/.test(r.out));
}

console.log('\n-- SRI algorithm validity --');
{
  const f = fx(page(`<script src="./good.js" integrity="md5-Xw=="></script>`));
  const r = run(f);
  ck('md5 rejected, not "verified"', /NOT a valid SRI hash/.test(r.out) && !/SRI verified/.test(r.out));
  ck('says the browser will block it', /BLOCKED/.test(r.out));
}
{
  const f = fx(page(`<script src="./good.js" integrity="sha1-Xw=="></script>`));
  ck('sha1 rejected', /NOT a valid SRI hash/.test(run(f).out));
}
{
  const f = fx(page(`<script src="./good.js" integrity="whirlpool-AAAA"></script>\n<script src="./good.js" integrity="sha384-${S384}"></script>`));
  const r = run(f);
  ck('unknown algorithm does not abort the run', /SRI verified/.test(r.out));
  ck('and is reported', /whirlpool/.test(r.out));
}

console.log('\n-- multiple hashes are valid SRI --');
{
  const f = fx(page(`<script src="./good.js" integrity="sha256-${S256} sha384-${S384}"></script>`));
  const r = run(f);
  ck('multi-algo verifies (strongest wins)', /SRI verified \(sha384/.test(r.out));
  ck('not reported as a mismatch', !/MISMATCH/.test(r.out));
}
{
  const f = fx(page(`<script src="./good.js" integrity="sha384-AAAAWRONGAAAA sha384-${S384}"></script>`));
  ck('any matching hash of the strongest algo verifies', /SRI verified/.test(run(f).out));
}
{
  const f = fx(page(`<script src="./good.js" integrity="sha384-AAAAWRONGAAAA"></script>`));
  const r = run(f);
  ck('a genuine mismatch is still caught', /MISMATCH/.test(r.out));
  ck('and exits non-zero', r.code !== 0);
}

console.log('\n-- cross-origin needs crossorigin --');
{
  const f = fx(page(`<script src="https://cdn.example/x.js" integrity="sha384-${S384}"></script>`));
  const r = run(f);
  ck('integrity without crossorigin is flagged', /no crossorigin/.test(r.out));
  ck('explains the resource is blocked', /BLOCKS/.test(r.out));
  ck('exits non-zero', r.code !== 0);
}
{
  const f = fx(page(`<script src="https://cdn.example/x.js" integrity="sha384-${S384}" crossorigin="anonymous"></script>`));
  const r = run(f);
  ck('with crossorigin it is accepted', /SRI present/.test(r.out) && r.code === 0);
}

console.log('\n-- comments and JS strings are not markup --');
{
  const f = fx(page(`<!-- <script src="https://cdn.example/ghost.js"></script> -->`));
  const r = run(f);
  ck('commented-out script ignored', /fully self-contained/.test(r.out) && r.code === 0);
}
{
  const f = fx(page(`<script>var s = '<script src="https://cdn.example/injs.js"><\\/script>';</script>`));
  ck('script src inside a JS string ignored', /fully self-contained/.test(run(f).out));
}

console.log('\n-- positive control --');
{
  const f = fx(page(`<script src="./good.js" integrity="sha384-${S384}"></script>`));
  const r = run(f);
  ck('correctly pinned local file verifies', /SRI verified \(sha384\)/.test(r.out));
  ck('exits zero', r.code === 0);
}
{
  const f = fx(page(`<script>console.log(1)</script>`));
  const r = run(f);
  ck('inline-only page is self-contained', /fully self-contained/.test(r.out) && r.code === 0);
}

console.log('\n' + '-'.repeat(40));
console.log(`  ${pass} passed, ${fail} failed  (SRI audit)`);
console.log('-'.repeat(40));
try { fs.rmSync(TMP, { recursive: true, force: true }); } catch {}
process.exit(fail ? 1 : 0);
