#!/usr/bin/env node
/*
  0scanner-diff.cjs — differential test of scanTags()/maskNonMarkup() against an
  INDEPENDENT HTML tokenizer: Python's stdlib html.parser.

  Rounds eleven-sixteen replaced five regexes with one hand-written scanner that
  every markup-reading command now depends on. 0scanner-fuzz.cjs checks that its
  output is internally well-formed (spans in range, ordered, non-overlapping).
  That is necessary and not sufficient: a scanner can be perfectly self-consistent
  and still disagree with a real tokenizer about where a tag ends or what its
  attributes are — which is the exact class of error this whole review has been
  about. html.parser is a separate implementation by separate authors, and it
  independently reproduces the two rules the fixes rest on:

      * '>' inside a quoted attribute value does NOT close the tag
      * <script>/<style> switch to CDATA: markup inside the body is not markup

  Compared for every generated document, per start tag:
      offset · tag name · attribute names · attribute values

  Divergence on WELL-FORMED input is a defect. On deliberately malformed input
  (unterminated quotes, truncated tags) there is no single correct answer —
  browsers, html.parser and this scanner all differ — so those are reported
  separately as leads rather than failures.

  Run: node 0scanner-diff.cjs [iterations] [seed]
*/
'use strict';
const fs = require('fs'), path = require('path'), os = require('os');
const { execFileSync } = require('child_process');

const ENGINE = path.join(__dirname, '0html-layers.cjs');
// The scanner is its own module now, so the harnesses require it directly
// rather than slicing main() off the engine.
const S = require(path.join(__dirname, '0scan-html.cjs'));

// ── the oracle ───────────────────────────────────────────────────
const ORACLE = path.join(os.tmpdir(), `0oracle-${process.pid}.py`);
fs.writeFileSync(ORACLE, `
import sys, json
from html.parser import HTMLParser

class P(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.out = []
    def handle_starttag(self, tag, attrs):
        self.out.append({"pos": self.getpos(), "tag": tag,
                         "attrs": [[k, v] for k, v in attrs]})
    handle_startendtag = handle_starttag

docs = json.load(sys.stdin)
res = []
for d in docs:
    p = P()
    try:
        p.feed(d)
        p.close()
        starts = [0]
        for ch in d:
            starts.append(starts[-1] + 1)
        lines = [0]
        for i, ch in enumerate(d):
            if ch == "\\n":
                lines.append(i + 1)
        tags = []
        for t in p.out:
            ln, col = t["pos"]
            off = (lines[ln - 1] if ln - 1 < len(lines) else 0) + col
            tags.append({"off": off, "tag": t["tag"], "attrs": t["attrs"]})
        res.append({"ok": True, "tags": tags})
    except Exception as e:
        res.append({"ok": False, "err": str(e)})
json.dump(res, sys.stdout)
`);

function oracle(docs) {
  const out = execFileSync('python3', [ORACLE], { input: JSON.stringify(docs), encoding: 'utf8', maxBuffer: 64 * 1024 * 1024 });
  return JSON.parse(out);
}

// ── corpus ───────────────────────────────────────────────────────
let seed = Number(process.argv[3] || 1) >>> 0;
const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
const pick = (a) => a[Math.floor(rnd() * a.length)];
const times = (n, f) => Array.from({ length: n }, (_, i) => f(i)).join('');

const NAMES = ['id', 'class', 'title', 'data-x', 'onclick', 'onsubmit', 'once', 'style',
               'src', 'href', 'integrity', 'rel', 'crossorigin', 'data-0h', 'viewBox'];
const VALS = ['a > b', 'x', '', 'a b c', 'url(#f)', '//cdn/x.js', 'sha384-AA',
              'a&quot;b', 'a&#39;b', 'a<b', '-->', 'x=y', "it's", 'a/b'];

// wellFormed: no unterminated quotes or truncated tags
function attr(wellFormed) {
  const n = pick(NAMES), v = pick(VALS);
  const r = Math.floor(rnd() * (wellFormed ? 4 : 5));
  switch (r) {
    case 0: return ` ${n}="${v.replace(/"/g, '&quot;')}"`;
    case 1: return ` ${n}='${v.replace(/'/g, '&#39;')}'`;
    case 2: return ` ${n}=${(v.split(/[\s>'"]/)[0] || 'x')}`;
    case 3: return ` ${n}`;
    default: return ` ${n}="${v}`;                      // unterminated
  }
}
function element(depth, wf) {
  const tag = pick(['div', 'p', 'span', 'b', 'button', 'img', 'script', 'style', 'link', 'a', 'svg']);
  const a = times(Math.floor(rnd() * 4), () => attr(wf));
  if (tag === 'script') return `<script${a}>${pick(['var t = "<b onclick=\\"x()\\">";', 'a < b && c > d;', 'x="a > b";', ''])}</script>`;
  if (tag === 'style') return `<style${a}>${pick(['a{b:c}', '/* <i onclick="x"> */', ''])}</style>`;
  if (tag === 'img' || tag === 'link') return `<${tag}${a}${rnd() < 0.3 ? ' /' : ''}>`;
  const kids = depth > 0 && rnd() < 0.5 ? times(Math.floor(rnd() * 3), () => element(depth - 1, wf)) : pick(['text', 'a &gt; b', '']);
  return `<${tag}${a}>${kids}</${tag}>`;
}
function makeDoc(wf) {
  const head = times(Math.floor(rnd() * 3), () => pick([
    `<meta http-equiv="Content-Security-Policy" content="script-src 'self' 'unsafe-inline'">`,
    `<!-- <button onclick="ghost()">c</button> -->`,
    `<style>x{y:z}</style>`,
  ]));
  const body = times(1 + Math.floor(rnd() * 5), () => element(2, wf));
  return `<!doctype html><html><head>${head}</head><body>${body}</body></html>`;
}

// ── our side, in the oracle's shape ──────────────────────────────
const decode = (s) => String(s)
  .replace(/&quot;/gi, '"').replace(/&#39;|&apos;/gi, "'")
  .replace(/&lt;/gi, '<').replace(/&gt;/gi, '>').replace(/&amp;/gi, '&');
function ours(html) {
  const masked = S.maskNonMarkup(html);
  return S.scanTags(masked).map((t) => ({
    off: t.index,
    tag: t.tag.toLowerCase(),
    attrs: t.attrs.map((a) => [a.name.toLowerCase(), a.valStart >= 0 ? decode(html.slice(a.valStart, a.valEnd)) : null]),
  }));
}

const key = (t) => `${t.off}:${t.tag}:${JSON.stringify(t.attrs)}`;

const N = Number(process.argv[2] || 1500);
console.log(`\n  0html SCANNER DIFFERENTIAL vs python3 html.parser — ${N} documents, seed ${process.argv[3] || 1}\n`);

let checked = 0, wfDiffs = [], mfDiffs = 0; const mfSamples = [];
const BATCH = 250;
for (let done = 0; done < N; done += BATCH) {
  const n = Math.min(BATCH, N - done);
  const wf = [], docs = [];
  for (let i = 0; i < n; i++) { const w = rnd() < 0.75; wf.push(w); docs.push(makeDoc(w)); }
  const res = oracle(docs);
  for (let i = 0; i < n; i++) {
    if (!res[i].ok) continue;
    checked++;
    const a = res[i].tags.map(key).join('\n');
    const b = ours(docs[i]).map(key).join('\n');
    if (a === b) continue;
    if (wf[i]) { if (wfDiffs.length < 6) wfDiffs.push({ html: docs[i], oracle: res[i].tags, ours: ours(docs[i]) }); }
    else { mfDiffs++; if (mfSamples.length < 4) mfSamples.push({ html: docs[i], oracle: res[i].tags, ours: ours(docs[i]) }); }
  }
}

for (const d of wfDiffs) {
  console.log(`  \u2717 divergence on well-formed input:`);
  console.log(`      ${JSON.stringify(d.html.slice(0, 200))}`);
  const A = d.oracle.map(key), B = d.ours.map(key);
  for (const line of A) if (!B.includes(line)) console.log(`      oracle only: ${line}`);
  for (const line of B) if (!A.includes(line)) console.log(`      ours   only: ${line}`);
  console.log('');
}
if (process.argv.includes('--show-malformed')) {
  for (const d of mfSamples) {
    console.log(`  \u00b7 malformed-input divergence:`);
    console.log(`      ${JSON.stringify(d.html.slice(0, 200))}`);
    const A = d.oracle.map(key), B = d.ours.map(key);
    for (const line of A) if (!B.includes(line)) console.log(`      oracle only: ${line}`);
    for (const line of B) if (!A.includes(line)) console.log(`      ours   only: ${line}`);
    console.log('');
  }
}
console.log(`  ${checked} documents compared`);
console.log(`  malformed-input divergences: ${mfDiffs}  (informational — no single correct answer)`);
console.log(wfDiffs.length
  ? `\n  \u2717 ${wfDiffs.length} WELL-FORMED DIVERGENCE(S)\n`
  : `\n  \u2713 agrees with html.parser on every well-formed document\n`);
try { fs.rmSync(ORACLE, { force: true }); } catch {}
process.exit(wfDiffs.length ? 1 : 0);
