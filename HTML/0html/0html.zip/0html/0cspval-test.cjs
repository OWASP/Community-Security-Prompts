#!/usr/bin/env node
/*
  0cspval-test.cjs — L1 must check directive VALUES, not just names.

  `form-action *` satisfied a presence check, so a page with every L1 directive
  at its most permissive value reported ✓ conformant, `apply` was a no-op, and
  `conformance --require=L1` exited 0. form-action 'none' is the control
  THREAT-MODEL.md names as the mitigation for a hostile spec emitting
  <form action="https://evil/…"> under the default urlPolicy:'any', so the
  attestation was certifying a control that was not there.

  Runs the CLI end-to-end, same shape as 0layers-test.cjs.
*/
'use strict';
const { execFileSync } = require('child_process');
const fs = require('fs'), os = require('os'), path = require('path');
const ENGINE = path.join(__dirname, '0html-layers.cjs');
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), '0cspval-'));
let pass = 0, fail = 0;
const ck = (n, c) => c ? (pass++, console.log('  \u2713 ' + n)) : (fail++, console.log('  \u2717 FAIL ' + n));
function run(args) {
  try { return { out: execFileSync('node', [ENGINE, ...args], { encoding: 'utf8' }), code: 0 }; }
  catch (e) { return { out: (e.stdout || '') + (e.stderr || ''), code: e.status || 1 }; }
}
let n = 0;
const fx = (html) => { const p = path.join(TMP, 'f' + (++n) + '.html'); fs.writeFileSync(p, html); return p; };
const read = (p) => fs.readFileSync(p, 'utf8');
const csp = (c) => `<meta http-equiv="Content-Security-Policy" content="${c}">`;
const wrap = (head, body) => `<!doctype html><html><head>${head}</head><body>${body || '<script type="module">console.log(1)</script>'}</body></html>`;

const WIDE = "default-src 'self'; script-src 'self'; frame-ancestors *; base-uri *; object-src *; form-action *";
const GOOD = "default-src 'self'; script-src 'self'; frame-ancestors 'none'; base-uri 'self'; object-src 'none'; form-action 'none'";

console.log('\n-- a permissive value is not a satisfied directive --');
{
  const f = fx(wrap(csp(WIDE)));
  const d = run(['layers', f]);
  ck('layers reports L1 as available, not done', /L1/.test(d.out) && /TIGHTEN|would add/i.test(d.out));
  ck('names the permissive directives', /form-action/.test(d.out));

  run(['apply', f, '--layers=1']);
  const h = read(f);
  ck("apply tightens form-action to 'none'", /form-action 'none'/.test(h) && !/form-action \*/.test(h));
  ck("apply tightens frame-ancestors to 'none'", /frame-ancestors 'none'/.test(h));
  ck("apply tightens base-uri to 'self'", /base-uri 'self'/.test(h));
  ck("apply tightens object-src to 'none'", /object-src 'none'/.test(h));
  ck('unrelated directives untouched', /default-src 'self'/.test(h) && /script-src 'self'/.test(h));
  ck('conformance passes once tightened', run(['conformance', f]).code === 0);
}

console.log('\n-- reversal restores the author\'s original values verbatim --');
{
  const f = fx(wrap(csp(WIDE)));
  run(['apply', f, '--layers=1']);
  run(['unapply', f, '--layer=1']);
  const h = read(f);
  ck('form-action * restored, not deleted', /form-action \*/.test(h));
  ck('base-uri * restored', /base-uri \*/.test(h));
  ck('directive count preserved', (h.match(/frame-ancestors|base-uri|object-src|form-action/g) || []).length === 4);
}

console.log('\n-- the CI gate --');
{
  const f = fx(wrap(csp(WIDE)) + '\n<!-- 0html-layers: {"L1":{"added":[]}} -->');
  ck('conformance reports DRIFT on a claimed-but-permissive L1', /DRIFT|NON-CONFORMANT/.test(run(['conformance', f]).out));
  ck('conformance exits non-zero', run(['conformance', f]).code !== 0);
  ck('--require=L1 exits non-zero', run(['conformance', f, '--require=L1']).code !== 0);
}

console.log('\n-- positive controls: correct policies must not be disturbed --');
{
  const f = fx(wrap(csp(GOOD)));
  const before = read(f);
  const a = run(['apply', f, '--layers=1']);
  ck('already-correct L1 is a no-op', /already satisfied|no change/.test(a.out));
  ck('CSP byte-identical after no-op apply', read(f).includes(GOOD));
  ck('conformance passes', run(['conformance', f]).code === 0);
  ck('--require=L1 passes', run(['conformance', f, '--require=L1']).code === 0);
}
{
  // 'self' is stricter than the 'self' baseline asks for on base-uri; 'none' too.
  const f = fx(wrap(csp("default-src 'self'; script-src 'self'; frame-ancestors 'none'; base-uri 'none'; object-src 'none'; form-action 'none'")));
  run(['apply', f, '--layers=1']);
  ck("base-uri 'none' accepted as satisfying 'self'", /base-uri 'none'/.test(read(f)));
}
{
  // a directive missing entirely still gets ADDED, as before
  const f = fx(wrap(csp("script-src 'self'")));
  run(['apply', f, '--layers=1']);
  const h = read(f);
  ck('absent directives still added', /form-action 'none'/.test(h) && /frame-ancestors 'none'/.test(h));
  run(['unapply', f, '--layer=1']);
  ck('and removed again on unapply', !/form-action/.test(read(f)));
}

console.log('\n-- wildcard forms that must all be rejected --');
{
  for (const [label, val] of [
    ['bare *', '*'],
    ['scheme-wide https:', 'https:'],
    ['host wildcard *.example', '*.example'],
    ["'self' plus *", "'self' *"],
    ['data:', 'data:'],
  ]) {
    const f = fx(wrap(csp(`script-src 'self'; frame-ancestors 'none'; base-uri 'self'; object-src 'none'; form-action ${val}`)));
    run(['apply', f, '--layers=1']);
    ck(`form-action ${label} tightened`, /form-action 'none'/.test(read(f)));
  }
}

console.log('\n' + '-'.repeat(40));
console.log(`  ${pass} passed, ${fail} failed  (L1 value checking)`);
console.log('-'.repeat(40));
try { fs.rmSync(TMP, { recursive: true, force: true }); } catch {}
process.exit(fail ? 1 : 0);
