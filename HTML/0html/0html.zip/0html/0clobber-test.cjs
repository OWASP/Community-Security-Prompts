// 0clobber-test.cjs — regression locks for I10: the delegated dispatch walk
// versus DOM clobbering.
//
// HTMLFormElement is [LegacyOverrideBuiltIns], so a named child shadows
// built-ins on the WHOLE prototype chain:
//     <form><input name="hasAttribute">   →  form.hasAttribute IS the <input>
// Before I10, dispatch() called those accessors straight off the untrusted
// node: a TypeError escaped the handler try/catch, preventDefault() never ran
// on submit (real page navigation), a clobbered parentNode cycled the walk
// forever, and a clobbered nodeType silently dropped the binding.
//
// The shim below models the browser FAITHFULLY on the point that matters:
// nodeType/parentNode are prototype GETTERS and hasAttribute/getAttribute are
// prototype METHODS, with clobbering applied as own properties on the form.
// A shim that put them on the instance would not be able to tell the fix from
// the bug. Run: node 0clobber-test.cjs
'use strict';

const listeners = [];

class Node {
  constructor() { this._childNodes = []; this._parentNode = null; this._nodeType = 1; }
  appendChild(c) { c._parentNode = this; this._childNodes.push(c); return c; }
  get textContent() { return ''; }
  set textContent(v) {}
}
// Browser-faithful: these live on the PROTOTYPE, so an own named property
// on the instance shadows them exactly the way form named-access does.
Object.defineProperty(Node.prototype, 'nodeType',   { get() { return this._nodeType; }, configurable: true });
Object.defineProperty(Node.prototype, 'parentNode', { get() { return this._parentNode; }, configurable: true });

class TextNode extends Node { constructor(d) { super(); this._nodeType = 3; this.data = String(d); } }
class DocumentFragment extends Node { constructor() { super(); this._nodeType = 11; } }

class Element extends Node {
  constructor(tag) { super(); this._tag = String(tag).toLowerCase(); this._attrs = {}; }
  get tagName() { return this._tag; }
  addEventListener(type, fn, cap) { listeners.push({ type, fn, cap }); }
  set id(v) { this._attrs.id = String(v); } get id() { return this._attrs.id; }
  set className(v) { this._attrs.class = String(v); } get className() { return this._attrs.class || ''; }
}
Element.prototype.setAttribute = function (k, v) { this._attrs[k] = String(v); };
Element.prototype.getAttribute = function (k) { return Object.prototype.hasOwnProperty.call(this._attrs, k) ? this._attrs[k] : null; };
Element.prototype.hasAttribute = function (k) { return Object.prototype.hasOwnProperty.call(this._attrs, k); };
Object.defineProperty(Element.prototype, 'dataset', {
  get() { const d = {}; for (const k of Object.keys(this._attrs)) if (k.startsWith('data-')) d[k.slice(5).replace(/-([a-z])/g, (_, x) => x.toUpperCase())] = this._attrs[k]; return d; },
  configurable: true,
});

class Template extends Element {
  constructor() { super('template'); this.content = new DocumentFragment(); }
  set innerHTML(h) { const s = new Element('span'); s.appendChild(new TextNode('[[RAW]]')); this.content.appendChild(s); }
}

global.document = {
  createElement: (t) => t === 'template' ? new Template() : new Element(t),
  createElementNS: (ns, t) => new Element(t),
  createTextNode: (d) => new TextNode(d),
  createDocumentFragment: () => new DocumentFragment(),
  body: new Element('body'),
  addEventListener: (type, fn, cap) => listeners.push({ type, fn, cap }),
};
global.Node = Node;
global.window = { addEventListener: () => {} };

const fs = require('fs'), os = require('os'), pathm = require('path');
const toCjs = (n) => { const p = pathm.join(os.tmpdir(), `clob-${n}-${process.pid}.cjs`); fs.writeFileSync(p, fs.readFileSync(pathm.join(__dirname, `${n}.js`), 'utf8')); return p; };
global.OUI_BIND = require(toCjs('0bind'));
const html0 = require(toCjs('0html'));
const bind = global.OUI_BIND;

let pass = 0, fail = 0;
const ok = (n, c) => { const g = !!c; console.log(`${g ? '✓' : '✗ FAIL'} ${n}`); g ? pass++ : fail++; };
const quiet = (fn) => { const w = console.warn, e = console.error; console.warn = () => {}; console.error = () => {}; try { return fn(); } finally { console.warn = w; console.error = e; } };

// ── wire the delegation layer ──────────────────────────────────
let ran = 0, lastCtx = null;
bind.on('save', (e, el, ctx) => { ran++; lastCtx = ctx; });
bind.init(document.body, ['click', 'submit']);
ok('shim captured the delegated listeners', listeners.length === 2);

const fire = (type, target) => {
  const l = listeners.find((x) => x.type === type);
  if (!l) return { harness: 'NO LISTENER' };
  let prevented = false, threw = null;
  const e = { target, type, preventDefault() { prevented = true; } };
  quiet(() => { try { l.fn(e); } catch (ex) { threw = ex; } });
  return { prevented, threw };
};

// A <form> whose named child shadows `key` on the prototype chain.
const clobberedForm = (key) => {
  const form = new Element('form');
  const input = new Element('input');
  input.setAttribute('name', key);
  form.appendChild(input);
  form.setAttribute('data-on-submit', 'save');
  form.setAttribute('data-on-click', 'save');
  form.setAttribute('data-arg', 'rows');
  document.body.appendChild(form);
  Object.defineProperty(form, key, { value: input, configurable: true, writable: true });
  return form;
};

// ═══ the walk survives every clobbered accessor it touches ══════
console.log('\n── I10: clobbered accessors on the event target ──');
for (const key of ['hasAttribute', 'getAttribute', 'nodeType', 'parentNode', 'dataset']) {
  ran = 0;
  const form = clobberedForm(key);
  const r = fire('submit', form);
  ok(`name="${key}" — no exception escapes dispatch`, r.threw === null);
  ok(`name="${key}" — preventDefault still runs (no real submit)`, r.prevented === true);
  ok(`name="${key}" — handler still fired`, ran === 1);
}

// ═══ ctx.arg is read from the attribute, not the clobberable dataset ══
console.log('\n── ctx.arg integrity ──');
{
  ran = 0; lastCtx = null;
  const form = clobberedForm('dataset');
  fire('click', form);
  ok('ctx.arg survives a clobbered dataset', lastCtx && lastCtx.arg === 'rows');
}
{
  ran = 0; lastCtx = null;
  const el = new Element('button');
  el.setAttribute('data-on-click', 'save');
  document.body.appendChild(el);
  fire('click', el);
  ok('ctx.arg is undefined when data-arg is absent', lastCtx && lastCtx.arg === undefined);
}

// ═══ a cyclic parentNode chain terminates ══════════════════════
console.log('\n── bounded walk ──');
{
  const form = new Element('form'), input = new Element('input'), span = new Element('span');
  form.appendChild(input); form.appendChild(span);
  document.body.appendChild(form);
  input.setAttribute('name', 'parentNode');
  let hops = 0;
  Object.defineProperty(form, 'parentNode', { get() { return input; }, configurable: true });
  Object.defineProperty(input, 'parentNode', { get() { if (++hops > 50000) throw new Error('UNBOUNDED'); return form; }, configurable: true });
  const r = fire('click', span);
  ok('cyclic parentNode terminates, does not hang', r.threw === null);
  ok('walk is bounded well under the cycle guard', hops < 1000);
}

// ═══ normal delegation is unaffected ═══════════════════════════
console.log('\n── positive controls ──');
{
  ran = 0; lastCtx = null;
  const outer = new Element('div');
  outer.setAttribute('data-on-click', 'save');
  const inner = new Element('span');
  outer.appendChild(inner);
  document.body.appendChild(outer);
  fire('click', inner);
  ok('binding found by walking up from a child', ran === 1);
  ok('ctx.target is the bound element', lastCtx && lastCtx.target === outer);
}
{
  ran = 0;
  const a = new Element('div'); a.setAttribute('data-on-click', 'save');
  const b = new Element('div'); b.setAttribute('data-on-click', 'nope');
  a.appendChild(b); document.body.appendChild(a);
  fire('click', b);
  ok('nearest binding still wins (unregistered name → inert)', ran === 0);
}
{
  ran = 0;
  const form = new Element('form');
  form.setAttribute('data-on-submit', 'save');
  document.body.appendChild(form);
  const r = fire('submit', form);
  ok('clean submit still preventDefault()s', r.prevented === true && ran === 1);
}

// ═══ strict mode refuses the accessor names outright ═══════════
console.log('\n── J12 denylist (defense in depth) ──');
for (const nm of ['hasAttribute', 'parentNode', 'nodeType', 'attributes', 'submit']) {
  const n = quiet(() => html0.compile({ tag: 'input', attrs: { name: nm } }, { idPolicy: { mode: 'strict' } }));
  ok(`strict refuses name="${nm}"`, n._attrs.name === undefined);
}
{
  const n = quiet(() => html0.compile({ tag: 'input', attrs: { name: 'email' } }, { idPolicy: { mode: 'strict' } }));
  ok('strict keeps a normal name unprefixed', n._attrs.name === 'email');
}

console.log('\n' + '─'.repeat(40));
console.log(`  ${pass} passed, ${fail} failed  (I10 dispatch clobbering)`);
console.log('─'.repeat(40));
process.exit(fail ? 1 : 0);
