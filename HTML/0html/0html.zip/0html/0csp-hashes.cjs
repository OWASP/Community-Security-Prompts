#!/usr/bin/env node
/* 0csp-hashes.cjs — emit the CSP source list for EVERY inline <script> in a file.
   Under `script-src 'sha256-…'` a hash source removes 'unsafe-inline', so every
   inline script needs its own hash. build.sh used to hash only the LAST
   <script type="module">, which left the Trusted Types bootstrap and the
   clickjacking frame-buster in the shipped tools refused by the very CSP that
   was supposed to harden them — confirmed in Chromium. Uses the shared scanner
   so "which text is the script body" is decided exactly once in this project. */
'use strict';
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const SCAN = require(path.join(__dirname, '0scan-html.cjs'));

function inlineScriptBodies(html) {
  const out = [], masked = SCAN.maskNonMarkup(html);
  for (const t of SCAN.scanTags(masked)) {
    if (t.tag.toLowerCase() !== 'script') continue;
    if (t.attrs.some((a) => a.name.toLowerCase() === 'src')) continue;   // external: SRI's job
    const close = html.toLowerCase().indexOf('</script', t.end);
    if (close === -1) continue;
    const body = html.slice(t.end, close);
    if (body.trim()) out.push(body);
  }
  return out;
}
const sha = (s) => "'sha256-" + crypto.createHash('sha256').update(s, 'utf8').digest('base64') + "'";

module.exports = { inlineScriptBodies, hashesFor: (html) => inlineScriptBodies(html).map(sha) };

if (require.main === module) {
  const f = process.argv[2];
  if (!f) { console.error('usage: 0csp-hashes.cjs <file.html>'); process.exit(1); }
  process.stdout.write(module.exports.hashesFor(fs.readFileSync(f, 'utf8')).join(' '));
}
