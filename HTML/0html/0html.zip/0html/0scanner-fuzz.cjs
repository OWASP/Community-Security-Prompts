#!/usr/bin/env node
/*
  0scanner-fuzz.cjs — property fuzz for maskNonMarkup() + scanTags().

  Rounds eleven-fifteen replaced five separate regexes with ONE hand-written
  scanner. Every markup-reading command now depends on it: convert-handlers,
  restore-handlers, the L2 and L8 interlocks, styleBlocks, audit-sri, and the
  L4 shim check. That makes it a single point of failure that had only ever been
  tested against cases the author happened to think of — the same weakness that
  produced the bugs it replaced.

  Properties (all must hold for EVERY generated document):

    P1  mask preserves length            — every span rewrite depends on this
    P2  mask only ever blanks            — masked[i] === html[i] || ' '
    P3  tag spans are well-formed        — 0 <= index < end <= len, starts at '<'
    P4  tag spans are ordered, disjoint  — end[i] <= index[i+1]
    P5  attribute spans lie inside tag   — index < start < end <= tag.end
    P6  value spans lie inside attribute
    P7  no crash, no hang                — bounded work on hostile input
    P8  convert-handlers is a fixpoint   — after it, inlineHandlers() === 0
    P9  convert→restore preserves the handler multiset (semantic round-trip)

  Run: node 0scanner-fuzz.cjs [iterations] [seed]
*/
'use strict';
const fs = require('fs'), path = require('path'), os = require('os');
const { execFileSync } = require('child_process');

const ENGINE = path.join(__dirname, '0html-layers.cjs');
// The scanner is its own module now, so the harnesses require it directly
// rather than slicing main() off the engine.
const S = require(path.join(__dirname, '0scan-html.cjs'));

// ── deterministic RNG ────────────────────────────────────────────
let seed = Number(process.argv[3] || 1) >>> 0;
const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
const pick = (a) => a[Math.floor(rnd() * a.length)];
const times = (n, f) => Array.from({ length: n }, (_, i) => f(i)).join('');

// ── hostile document generator ───────────────────────────────────
const ATTR_NAMES = ['id', 'class', 'title', 'data-x', 'onclick', 'onsubmit', 'once', 'onward',
                    'style', 'src', 'href', 'integrity', 'rel', 'crossorigin', 'data-0h'];
const VALUES = ['a > b', 'x', '', 'a"b', "a'b", 'a<b', '</script>', '-->', 'a\\b', 'url(#f)',
                'javascript:x', '//cdn/x.js', 'a b c', '>', '<', '="', "sha384-AA", 'a\nb'];
function attr() {
  const n = pick(ATTR_NAMES);
  const v = pick(VALUES);
  switch (Math.floor(rnd() * 4)) {
    case 0: return ` ${n}="${v.replace(/"/g, '&quot;')}"`;
    case 1: return ` ${n}='${v.replace(/'/g, '&#39;')}'`;
    case 2: return ` ${n}=${v.split(/[\s>]/)[0] || 'x'}`;
    default: return ` ${n}`;
  }
}
function element(depth) {
  const tag = pick(['div', 'p', 'span', 'b', 'button', 'img', 'script', 'style', 'link', 'a']);
  const a = times(Math.floor(rnd() * 4), attr);
  if (tag === 'script') {
    const body = pick(['var t = "<b onclick=\\"x()\\">";', 'var s = "</scr" + "ipt>";',
                       'a < b && c > d;', 'x = "a > b";', '/* <p style="x"> */', '']);
    return `<script${a}>${body}</script>`;
  }
  if (tag === 'style') return `<style${a}>${pick(['a{b:c}', '/* <i onclick="x"> */', ''])}</style>`;
  if (tag === 'img' || tag === 'link') return `<${tag}${a}${rnd() < 0.3 ? ' /' : ''}>`;
  const kids = depth > 0 && rnd() < 0.5 ? times(Math.floor(rnd() * 3), () => element(depth - 1)) : pick(['text', 'a > b', '']);
  return `<${tag}${a}>${kids}</${tag}>`;
}
function document_() {
  const head = times(Math.floor(rnd() * 3), () => pick([
    `<meta http-equiv="Content-Security-Policy" content="script-src 'self' 'unsafe-inline'">`,
    `<!-- <button onclick="ghost()">c</button> -->`,
    `<!-- unterminated comment`,
    `<style>x{y:z}</style>`,
  ]));
  const body = times(1 + Math.floor(rnd() * 5), () => element(2));
  const tail = rnd() < 0.15 ? pick(['<div class="', '<p onclick="x', '<<>>', '</', '<b a="b']) : '';
  return `<!doctype html><html><head>${head}</head><body>${body}${tail}</body></html>`;
}

// ── properties ───────────────────────────────────────────────────
const fails = [];
const bad = (p, html, why) => { if (fails.length < 8) fails.push({ p, html, why }); };

function checkStructure(html) {
  const masked = S.maskNonMarkup(html);
  if (masked.length !== html.length) return bad('P1', html, `mask changed length ${html.length} -> ${masked.length}`);
  for (let i = 0; i < html.length; i++) {
    if (masked[i] !== html[i] && masked[i] !== ' ') return bad('P2', html, `mask wrote ${JSON.stringify(masked[i])} at ${i}`);
  }
  const tags = S.scanTags(masked);
  let prevEnd = -1;
  for (const t of tags) {
    if (!(t.index >= 0 && t.index < t.end && t.end <= html.length)) return bad('P3', html, `span ${t.index}..${t.end} len ${html.length}`);
    if (masked[t.index] !== '<') return bad('P3', html, `tag does not start at '<' (${JSON.stringify(masked[t.index])})`);
    if (t.index < prevEnd) return bad('P4', html, `tag at ${t.index} overlaps previous end ${prevEnd}`);
    prevEnd = t.end;
    for (const a of t.attrs) {
      if (!(a.start > t.index && a.end <= t.end && a.start < a.end)) return bad('P5', html, `attr ${a.name} span ${a.start}..${a.end} outside tag ${t.index}..${t.end}`);
      if (a.valStart >= 0 && !(a.valStart >= a.start && a.valEnd <= a.end && a.valStart <= a.valEnd)) {
        return bad('P6', html, `value span ${a.valStart}..${a.valEnd} outside attr ${a.start}..${a.end}`);
      }
    }
  }
}

// handler multiset of a document, for the round-trip property
function handlerSet(html) {
  const out = [];
  for (const f of S.findHandlers(html)) for (const h of f.handlers) out.push(h.ev + '=' + h.body);
  return out.sort().join('|');
}

const TMP = fs.mkdtempSync(path.join(os.tmpdir(), '0scanfuzz-'));
function runCli(args) {
  try { return { out: execFileSync('node', [ENGINE, ...args], { encoding: 'utf8', timeout: 20000 }), code: 0 }; }
  catch (e) { return { out: (e.stdout || '') + (e.stderr || ''), code: e.status === undefined ? 'TIMEOUT/CRASH' : e.status }; }
}

const N = Number(process.argv[2] || 3000);
console.log(`\n  0html SCANNER FUZZ — ${N} documents, seed ${process.argv[3] || 1}\n`);

const t0 = Date.now();
let cliRuns = 0;
for (let i = 0; i < N; i++) {
  const html = document_();
  try {
    checkStructure(html);
  } catch (e) {
    bad('P7', html, `threw: ${e.message}`);
  }
  // The CLI round-trip is expensive; sample it.
  if (i % 40 === 0) {
    cliRuns++;
    const f = path.join(TMP, 'd.html');
    fs.writeFileSync(f, html);
    const before = handlerSet(html);
    const c = runCli(['convert-handlers', f]);
    if (typeof c.code !== 'number') { bad('P7', html, `convert-handlers ${c.code}`); continue; }
    const after = fs.readFileSync(f, 'utf8');
    if (/converted \d+ inline handler/.test(c.out) && S.inlineHandlers(after) !== 0) {
      bad('P8', html, `convert reported success but ${S.inlineHandlers(after)} handler(s) remain`);
    }
    if (/converted \d+ inline handler/.test(c.out)) {
      const r = runCli(['restore-handlers', f]);
      if (typeof r.code !== 'number') { bad('P7', html, `restore-handlers ${r.code}`); continue; }
      if (r.code === 0) {
        const back = handlerSet(fs.readFileSync(f, 'utf8'));
        if (back !== before) bad('P9', html, `round-trip lost handlers\n      before: ${before}\n      after:  ${back}`);
      }
    }
    fs.rmSync(f, { force: true });
  }
}
const secs = ((Date.now() - t0) / 1000).toFixed(1);

for (const f of fails) {
  console.log(`  \u2717 ${f.p}: ${f.why}`);
  console.log(`      ${JSON.stringify(f.html.slice(0, 160))}\n`);
}
console.log(`  ${N} documents scanned, ${cliRuns} convert/restore round-trips, ${secs}s`);
console.log(fails.length ? `\n  \u2717 ${fails.length} COUNTEREXAMPLE(S)\n` : `\n  \u2713 P1\u2013P9 held for every document\n`);
try { fs.rmSync(TMP, { recursive: true, force: true }); } catch {}
process.exit(fails.length ? 1 : 0);
