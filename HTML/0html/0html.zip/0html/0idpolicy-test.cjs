// 0idpolicy-test.cjs — id/name namespacing (J12, opt-in).
// Zero-dep, in-file DOM shim. Run: node 0idpolicy-test.cjs
'use strict';

class Node { constructor(){ this.childNodes=[]; this.nodeType=1; }
  appendChild(c){ if(c instanceof DocumentFragment){for(const k of c.childNodes.slice())this.appendChild(k);return c;} c.parentNode=this; this.childNodes.push(c); return c; }
  get textContent(){ return this.childNodes.map(c=>c.textContent??'').join(''); }
  set textContent(v){ this.childNodes=[]; if(v!=='')this.appendChild(new TextNode(String(v))); } }
class TextNode{ constructor(d){ this.data=String(d); this.nodeType=3; } get textContent(){ return this.data; } }
class Element extends Node { constructor(tag){ super(); this.tagName=String(tag).toLowerCase(); this._attrs={}; this.dataset={}; }
  setAttribute(k,v){ this._attrs[k]=String(v); if(k.startsWith('data-')){const c=k.slice(5).replace(/-([a-z])/g,(_,x)=>x.toUpperCase());this.dataset[c]=String(v);} }
  getAttribute(k){ return this._attrs[k]; } hasAttribute(k){ return Object.prototype.hasOwnProperty.call(this._attrs,k); }
  set id(v){ this._attrs.id=v; } get id(){ return this._attrs.id; }
  set className(v){ this._attrs.class=v; } get className(){ return this._attrs.class||''; } addEventListener(){} }
class Template extends Element { constructor(){ super('template'); this.content=new DocumentFragment(); } set innerHTML(h){ const s=new Element('span'); s.appendChild(new TextNode('[[RAW]]')); this.content.appendChild(s); } }
class DocumentFragment extends Node { constructor(){ super(); this.nodeType=11; } }
const document={ createElement:(t)=>t==='template'?new Template():new Element(t), createTextNode:(d)=>new TextNode(d), createDocumentFragment:()=>new DocumentFragment(), body:new Element('body'), addEventListener:()=>{} };
global.document=document; global.Node=Node; global.window={ addEventListener:()=>{} };

const fs=require('fs'), os=require('os'), pathm=require('path');
const toCjs=(n)=>{const p=pathm.join(os.tmpdir(),`ip-${n}-${process.pid}.cjs`); fs.writeFileSync(p, fs.readFileSync(pathm.join(__dirname,`${n}.js`),'utf8')); return p;};
global.OUI_BIND=require(toCjs('0bind'));
const html0=require(toCjs('0html'));

let pass=0, fail=0;
const ok=(n,c)=>{const g=!!c; console.log(`${g?'✓':'✗ FAIL'} ${n}`); g?pass++:fail++;};

const NS={ idPolicy:{ mode:'namespace' } };            // prefix '0h-'
const STRICT={ idPolicy:{ mode:'strict' } };
const A=(spec,opts)=> html0.compile(spec,opts)._attrs;

// ═══════════════════════════════════════════════════════════════
console.log('\n── off (default): nothing changes ──');
ok('id untouched by default', A({tag:'div',attrs:{id:'panel'}}).id === 'panel');
ok('href#frag untouched by default', A({tag:'a',attrs:{href:'#sec'}}).href === '#sec');

console.log('\n── namespace: id + references prefixed ──');
ok('attrs.id prefixed', A({tag:'div',attrs:{id:'panel'}}, NS).id === '0h-panel');
ok('dedicated id field prefixed', A({tag:'div',id:'panel'}, NS).id === '0h-panel');
ok('for prefixed', A({tag:'label',attrs:{for:'email'}}, NS).for === '0h-email');
ok('list prefixed', A({tag:'input',attrs:{list:'opts'}}, NS).list === '0h-opts');
ok('headers multi-token each prefixed', A({tag:'td',attrs:{headers:'h1 h2'}}, NS).headers === '0h-h1 0h-h2');
ok('aria-labelledby multi each prefixed', A({tag:'div',attrs:{'aria-labelledby':'a b'}}, NS)['aria-labelledby'] === '0h-a 0h-b');
ok('aria-describedby prefixed', A({tag:'div',attrs:{'aria-describedby':'d'}}, NS)['aria-describedby'] === '0h-d');
ok('href "#frag" prefixed inside fragment', A({tag:'a',attrs:{href:'#sec'}}, NS).href === '#0h-sec');
ok('use xlink:href "#icon" prefixed', A({tag:'use',attrs:{'xlink:href':'#icon'}}, NS)['xlink:href'] === '#0h-icon');

console.log('\n── namespace: things that must NOT be prefixed ──');
ok('non-fragment href left alone', A({tag:'a',attrs:{href:'/page'}}, NS).href === '/page');
ok('name is NOT prefixed (form submission stays intact)', A({tag:'input',attrs:{name:'email'}}, NS).name === 'email');
ok('class left alone', A({tag:'div',attrs:{class:'card'}}, NS).class === 'card');
ok('bare "#" (empty frag) left alone', A({tag:'a',attrs:{href:'#'}}, NS).href === '#');

console.log('\n── namespace: intra-spec wiring stays linked ──');
{
  const tree = html0.compile({ tag:'div', children:[
    { tag:'label', attrs:{ for:'email' }, text:'Email' },
    { tag:'input', attrs:{ id:'email', type:'text' } },
  ]}, NS);
  const label = tree.childNodes.find(c=>c.tagName==='label');
  const input = tree.childNodes.find(c=>c.tagName==='input');
  ok('label[for] still equals input[id] after prefixing',
     label._attrs.for === input._attrs.id && input._attrs.id === '0h-email');
}

console.log('\n── strict: dangerous raw id/name refused; safe ones handled ──');
ok('id "constructor" refused (dropped)', A({tag:'div',attrs:{id:'constructor'}}, STRICT).id === undefined);
ok('id "location" refused', A({tag:'div',attrs:{id:'location'}}, STRICT).id === undefined);
ok('numeric id refused', A({tag:'div',attrs:{id:'42'}}, STRICT).id === undefined);
ok('single-char id refused', A({tag:'div',attrs:{id:'x'}}, STRICT).id === undefined);
ok('safe id still prefixed in strict', A({tag:'div',attrs:{id:'myPanel'}}, STRICT).id === '0h-myPanel');
ok('name "constructor" refused in strict', A({tag:'input',attrs:{name:'constructor'}}, STRICT).name === undefined);
ok('safe name kept (unprefixed) in strict', A({tag:'input',attrs:{name:'email'}}, STRICT).name === 'email');
ok('references still prefixed in strict', A({tag:'label',attrs:{for:'myField'}}, STRICT).for === '0h-myField');

console.log('\n── custom prefix ──');
ok('custom prefix applied', A({tag:'div',attrs:{id:'p'}}, { idPolicy:{ mode:'namespace', prefix:'app_' } }).id === 'app_p');

console.log('\n── composes with same-origin URL mode ──');
{
  const opts={ urlPolicy:{ mode:'same-origin', base:'https://app.example.com/x' }, idPolicy:{ mode:'namespace' } };
  const a = A({tag:'a',attrs:{href:'#sec'}}, opts);
  ok('same-origin fragment kept AND id-prefixed', a.href === '#0h-sec');
  const b = A({tag:'a',attrs:{href:'https://evil.example/x'}}, opts);
  ok('off-origin href still refused with id policy on', b.href === undefined);
}

console.log(`\n────────────────────────────────────────`);
console.log(`  ${pass} passed, ${fail} failed  (id/name namespacing, J12)`);
console.log(`────────────────────────────────────────`);
process.exit(fail ? 1 : 0);
