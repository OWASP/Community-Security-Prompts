// adversary.cjs — independent red-team probes, payloads NOT from the shipped suite.
// Focus: invariants that are pure logic (real in Node), not innerHTML behavior (needs a browser).
'use strict';

// ── DOM shim (same shape as the project's tests) ───────────────
class Node {
  constructor() { this.childNodes = []; this.nodeType = 1; }
  appendChild(c) {
    if (c instanceof DocumentFragment) { for (const k of c.childNodes.slice()) this.appendChild(k); return c; }
    c.parentNode = this; this.childNodes.push(c); return c;
  }
  get textContent() { return this.childNodes.map(c => c.textContent ?? '').join(''); }
  set textContent(v) { this.childNodes = []; if (v !== '') this.appendChild(new TextNode(String(v))); }
}
class TextNode { constructor(d) { this.data = String(d); this.nodeType = 3; } get textContent() { return this.data; } }
class Element extends Node {
  constructor(tag) { super(); this.tagName = String(tag).toLowerCase(); this._attrs = {}; this.dataset = {}; }
  setAttribute(k, v) {
    this._attrs[k] = String(v);
    if (k.startsWith('data-')) { const c = k.slice(5).replace(/-([a-z])/g, (_, x) => x.toUpperCase()); this.dataset[c] = String(v); }
    if (k.toLowerCase().startsWith('on')) this._hadInlineHandler = true;
  }
  getAttribute(k) { return this._attrs[k]; }
  hasAttribute(k) { return Object.prototype.hasOwnProperty.call(this._attrs, k); }
  set id(v) { this._attrs.id = v; } get id() { return this._attrs.id; }
  set className(v) { this._attrs.class = v; } get className() { return this._attrs.class || ''; }
  countEls() { let n = 1; for (const c of this.childNodes) if (c.countEls) n += c.countEls(); return n; }
  tags(out = []) { out.push(this.tagName); for (const c of this.childNodes) if (c.tags) c.tags(out); return out; }
  attrDump(out = []) { out.push({ t: this.tagName, a: { ...this._attrs } }); for (const c of this.childNodes) if (c.attrDump) c.attrDump(out); return out; }
  addEventListener() {}
}
class Template extends Element {
  constructor() { super('template'); this.content = new DocumentFragment(); }
  set innerHTML(html) {
    if (/<script[\s>]/i.test(html)) { const s = new Element('script'); s.appendChild(new TextNode(html)); this.content.appendChild(s); }
    else { const h = new Element('span'); h.appendChild(new TextNode('[[RAWHTML]]')); this.content.appendChild(h); }
  }
}
class DocumentFragment extends Node { constructor() { super(); this.nodeType = 11; } }
const document = {
  createElement: (t) => t === 'template' ? new Template() : new Element(t),
  createTextNode: (d) => new TextNode(d),
  createDocumentFragment: () => new DocumentFragment(),
  body: new Element('body'), addEventListener: () => {},
};
global.document = document; global.Node = Node;
global.window = { addEventListener: () => {} };

const fs = require('fs'), os = require('os'), pathm = require('path');
const toCjs = (name) => { const p = pathm.join(os.tmpdir(), `adv-${name}-${process.pid}.cjs`); fs.writeFileSync(p, fs.readFileSync(pathm.join(__dirname, `${name}.js`), 'utf8')); return p; };
global.OUI_BIND = require(toCjs('0bind'));
const html0 = require(toCjs('0html'));
const bind = global.OUI_BIND;

let pass = 0, fail = 0;
const ok = (n, c) => { const g = !!c; console.log(`${g ? '✓' : '✗ FAIL'} ${n}`); g ? pass++ : fail++; };

// ═══════════════════════════════════════════════════════════════
console.log('\n── A. Prototype pollution via PARSED JSON (the real attack surface) ──');
// JSON.parse gives __proto__ as an OWN property — the classic vector.
{
  const before = ({}).polluted;
  const mal = '{"tag":"div","attrs":{"__proto__":{"polluted":"yes"}}}';
  html0.fromJSON(mal);
  ok('Object.prototype.polluted still undefined after fromJSON', ({}).polluted === undefined && before === undefined);
}
{
  // nested deep in children
  const mal = '{"tag":"div","children":[{"tag":"span","attrs":{"constructor":{"x":1},"prototype":{"y":2}}}]}';
  html0.fromJSON(mal);
  ok('constructor/prototype keys did not corrupt', ({}).x === undefined && ({}).y === undefined);
}
{
  // pollute via the `on` map keys
  const mal = '{"tag":"button","on":{"__proto__":"evil","click":"real"}}';
  const n = html0.fromJSON(mal);
  const dump = n.attrDump()[0].a;
  ok('__proto__ not emitted as a data-on-* attr', !Object.keys(dump).some(k => /proto/i.test(k)));
  ok('legit handler still wired (data-on-click)', dump['data-on-click'] === 'real');
}

console.log('\n── B. Case / unicode tricks on forbidden keys & tags ──');
{
  // FORBIDDEN_KEYS is lowercase-exact. Does a mixed-case key slip a prototype write?
  // It shouldn't matter: even if it slips safeEntries, it can only become a setAttribute call.
  const n = html0.compile({ tag: 'div', attrs: { '__PROTO__': { polluted: 1 }, 'CONSTRUCTOR': { z: 1 } } });
  ok('mixed-case proto keys cause no prototype write', ({}).polluted === undefined && ({}).z === undefined);
  // and the object-valued attr should be coerced/handled, not crash
  ok('compile did not throw on object-valued attrs', n && n.nodeType === 1);
}
{
  const tags = ['ScRiPt', 'IFRAME', 'Object', 'EMBED', 'link', 'META', 'base', 'STYLE', 'svg\u0000script'];
  let allRefused = true;
  for (const t of tags) {
    const n = html0.compile({ tag: t });
    const refused = n.attrDump()[0].a['data-0html-refused'] !== undefined || n.tagName === 'span';
    if (!refused) { allRefused = false; console.log('    leaked tag:', t, '→', n.tagName); }
  }
  ok('every script/iframe/object/embed/link/meta/base/style variant refused → inert span', allRefused);
}

console.log('\n── C. Handler names are never code (J4) ──');
{
  // A name that looks like an expression must be treated as an opaque lookup key.
  let sideEffect = 0;
  global.__pwn = () => { sideEffect++; };
  const n = html0.compile({ tag: 'button', on: { click: '__pwn(); //' } });
  const dump = n.attrDump()[0].a;
  ok('expression-shaped name stored as literal data-on-click', dump['data-on-click'] === '__pwn(); //');
  ok('no side effect at compile time', sideEffect === 0);
  // simulate a dispatch: registry lookup by exact string → miss → inert
  ok('registry has no such handler (would render inert)', !bind._registry.has('__pwn(); //'));
  delete global.__pwn;
}
{
  // non-string handler (number/object/array) must be refused, not invoked
  const n = html0.compile({ tag: 'button', on: { click: 12345, mouseover: { toString: 'x' }, focus: ['a'] } });
  const dump = n.attrDump()[0].a;
  ok('numeric handler refused', dump['data-on-click'] === undefined);
  ok('object handler refused', dump['data-on-mouseover'] === undefined);
  ok('array handler refused', dump['data-on-focus'] === undefined);
}

console.log('\n── D. URL scheme gate — classic bypass corpus (I3) ──');
{
  const shouldBlock = [
    'javascript:alert(1)',
    'JaVaScRiPt:alert(1)',
    '  javascript:alert(1)',        // leading space
    'java\tscript:alert(1)',        // TAB smuggle
    'java\nscript:alert(1)',        // newline smuggle
    'java\x00script:alert(1)',      // NUL smuggle
    '\x01\x02javascript:alert(1)',  // leading control chars
    'data:text/html,<script>alert(1)</script>',
    'vbscript:msgbox(1)',
    'DATA:text/html;base64,PHNjcmlwdD4=',
  ];
  const shouldPass = [
    'https://example.com/x',
    'http://example.com',
    'mailto:a@b.com',
    'tel:+1555',
    '/relative/path',
    '#anchor',
    './rel',
    '?q=1',
    'ftp://host/file',
  ];
  let blockedAll = true, passedAll = true;
  for (const u of shouldBlock) if (bind.isSafeUrl(u)) { blockedAll = false; console.log('    LEAK (should block):', JSON.stringify(u)); }
  for (const u of shouldPass) if (!bind.isSafeUrl(u)) { passedAll = false; console.log('    false-drop (should pass):', JSON.stringify(u)); }
  ok('all dangerous schemes (incl. control-char obfuscation) blocked', blockedAll);
  ok('all legitimate URLs pass', passedAll);
}
{
  // End-to-end through the compiler: a javascript: href must not survive as an href attr.
  const n = html0.compile({ tag: 'a', attrs: { href: 'javascript:alert(1)' }, text: 'x' });
  const a = n.attrDump()[0].a;
  ok('javascript: href dropped by compiler→el pipeline', a.href === undefined);
}

console.log('\n── E. Resource bounds are hard failures (J2) ──');
{
  // depth bomb just past default 64
  let deep = { tag: 'div' }; let cur = deep;
  for (let i = 0; i < 70; i++) { cur.children = [{ tag: 'div' }]; cur = cur.children[0]; }
  let threw = false; try { html0.compile(deep); } catch (e) { threw = e instanceof RangeError; }
  ok('depth > maxDepth throws RangeError (not stack overflow)', threw);
}
{
  // breadth bomb past default 10000
  const kids = []; for (let i = 0; i < 10050; i++) kids.push({ tag: 'span' });
  let threw = false; try { html0.compile({ tag: 'div', children: kids }); } catch (e) { threw = e instanceof RangeError; }
  ok('node count > maxNodes throws RangeError', threw);
}
{
  // validate() should REPORT the bomb as ok:false, never throw to caller
  let deep = { tag: 'div' }; let cur = deep;
  for (let i = 0; i < 70; i++) { cur.children = [{ tag: 'div' }]; cur = cur.children[0]; }
  const r = html0.validate(deep);
  ok('validate() catches the bomb (ok:false), does not throw', r.ok === false && r.warnings.some(w => /FATAL/.test(w)));
}

console.log('\n── F. Raw-HTML double gate (J5) ──');
{
  const spec = { tag: 'div', html: { $trust: '<b>x</b>', from: 'markdown' } };
  // default: allowTrustedHTML off → refused (no [[RAWHTML]] marker present)
  const off = html0.compile(spec);
  ok('html refused when allowTrustedHTML unset (empty div)', off.childNodes.length === 0);
  // on, but generator not allowlisted → refused
  const wrongGen = html0.compile(spec, { allowTrustedHTML: true, trustedGenerators: ['syntaxHighlight'] });
  ok('html refused when generator not allowlisted', wrongGen.childNodes.length === 0);
  // on + allowlisted → passes to trust() (marker appears)
  const okGen = html0.compile(spec, { allowTrustedHTML: true, trustedGenerators: ['markdown'] });
  ok('html renders only when BOTH gates open', okGen.textContent.includes('[[RAWHTML]]'));
  // malformed html node (missing $trust) refused even with gates open
  const bad = html0.compile({ tag: 'div', html: { from: 'markdown', notrust: '<b>x</b>' } }, { allowTrustedHTML: true, trustedGenerators: ['markdown'] });
  ok('html without $trust string refused', bad.childNodes.length === 0);
}

console.log('\n── G. eventish attrs in the attrs map (J6, defense in depth) ──');
{
  const n = html0.compile({ tag: 'div', attrs: { onclick: 'x', OnMouseOver: 'y', 'on\u0000load': 'z', title: 'ok' } });
  const a = n.attrDump()[0].a;
  ok('onclick refused in attrs map', a.onclick === undefined);
  ok('OnMouseOver (case) refused', a.OnMouseOver === undefined && a.onmouseover === undefined);
  ok('legit title attr kept', a.title === 'ok');
  ok('no attribute starting with "on" survived', !Object.keys(a).some(k => /^on/i.test(k)));
}

console.log(`\n────────────────────────────────────────`);
console.log(`  ${pass} passed, ${fail} failed  (independent red-team)`);
console.log(`────────────────────────────────────────`);
process.exit(fail ? 1 : 0);
