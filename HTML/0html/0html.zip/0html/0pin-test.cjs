#!/usr/bin/env node
/*
  0pin-test.cjs — the toolchain pin set must cover every toolchain file, and
  must be able to GROW.

  Extracting the shared scanner into 0scan-html.cjs added a third file that the
  tooling's behaviour depends on. Two things had to be true for that to be safe:

    1. it is pinned in 0html.lock and listed in the SBOM, so `verify` fails if
       it is tampered with — otherwise the scanner every markup-reading command
       relies on would be the one unprotected file in the toolchain;

    2. an install that already has a lock picks it up. pinToolchain() used to do
       `files = prev.toolchain.map(...)`, REPLACING the defaults, so the set
       could only shrink or stay the same — a file added by an upgrade would
       never be pinned, and `verify` only checks what the lock lists, so it
       would pass while shipping an unpinned toolchain file.

  Runs the real CLI against a disposable copy of the package.
*/
'use strict';
const { execFileSync } = require('child_process');
const fs = require('fs'), os = require('os'), path = require('path');
let pass = 0, fail = 0;
const ck = (n, c) => c ? (pass++, console.log('  \u2713 ' + n)) : (fail++, console.log('  \u2717 FAIL ' + n));

// disposable copy: the CLI resolves everything from its own directory
const SRC = __dirname;
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), '0pin-'));
for (const f of ['0html-cli.cjs', '0html-layers.cjs', '0scan-html.cjs', 'layers.json', '0bind.js', '0html.js']) {
  fs.copyFileSync(path.join(SRC, f), path.join(TMP, f));
}
fs.mkdirSync(path.join(TMP, 'dist'));
for (const f of ['0html.bundle.js', '0bind.js', '0html.js']) {
  const p = path.join(SRC, 'dist', f);
  if (fs.existsSync(p)) fs.copyFileSync(p, path.join(TMP, 'dist', f));
}
const CLI = path.join(TMP, '0html-cli.cjs');
const LOCK = path.join(TMP, '0html.lock');
function run(args) {
  try { return { out: execFileSync('node', [CLI, ...args], { encoding: 'utf8', cwd: TMP }), code: 0 }; }
  catch (e) { return { out: (e.stdout || '') + (e.stderr || ''), code: e.status || 1 }; }
}
const lockFiles = () => JSON.parse(fs.readFileSync(LOCK, 'utf8')).toolchain.map((t) => t.file).sort();

console.log('\n-- the scanner is part of the pinned toolchain --');
{
  run(['pin']);
  ck('pin covers 0scan-html.cjs', lockFiles().includes('0scan-html.cjs'));
  ck('and still covers the engine + registry', lockFiles().includes('0html-layers.cjs') && lockFiles().includes('layers.json'));
  run(['sbom']);
  const sbom = JSON.parse(fs.readFileSync(path.join(TMP, 'dist', '0html.cdx.json'), 'utf8'));
  ck('SBOM lists it as a component', sbom.components.some((c) => c.name === '0scan-html.cjs'));
  ck('verify passes on a clean tree', run(['verify']).code === 0);
}

console.log('\n-- tampering with it is caught --');
{
  const p = path.join(TMP, '0scan-html.cjs');
  const orig = fs.readFileSync(p, 'utf8');
  fs.writeFileSync(p, orig + '\n// tampered\n');
  const r = run(['verify']);
  ck('verify fails', r.code !== 0);
  ck('names TOOLCHAIN DRIFT', /TOOLCHAIN DRIFT\s+0scan-html\.cjs/.test(r.out));
  ck('and SBOM STALE', /SBOM STALE\s+0scan-html\.cjs/.test(r.out));
  fs.writeFileSync(p, orig);
  ck('restoring it passes again', run(['verify']).code === 0);
}

console.log('\n-- the pin set can grow --');
{
  // simulate an install locked before the scanner existed
  const lock = JSON.parse(fs.readFileSync(LOCK, 'utf8'));
  lock.toolchain = lock.toolchain.filter((t) => t.file !== '0scan-html.cjs');
  fs.writeFileSync(LOCK, JSON.stringify(lock, null, 2));
  ck('pre-upgrade lock lacks it', !lockFiles().includes('0scan-html.cjs'));
  run(['pin']);
  ck('re-pinning adds it', lockFiles().includes('0scan-html.cjs'));
}
{
  // a project that pinned an extra file of its own keeps it
  const lock = JSON.parse(fs.readFileSync(LOCK, 'utf8'));
  fs.writeFileSync(path.join(TMP, 'site-policy.json'), '{"custom":true}\n');
  lock.toolchain.push({ file: 'site-policy.json', sha256: 'stale' });
  fs.writeFileSync(LOCK, JSON.stringify(lock, null, 2));
  run(['pin']);
  const files = lockFiles();
  ck('project addition preserved', files.includes('site-policy.json'));
  ck('defaults still present', ['0html-layers.cjs', '0scan-html.cjs', 'layers.json'].every((f) => files.includes(f)));
  ck('its hash was recomputed, not carried over',
     JSON.parse(fs.readFileSync(LOCK, 'utf8')).toolchain.find((t) => t.file === 'site-policy.json').sha256 !== 'stale');
}

console.log('\n' + '-'.repeat(40));
console.log(`  ${pass} passed, ${fail} failed  (toolchain pin coverage)`);
console.log('-'.repeat(40));
try { fs.rmSync(TMP, { recursive: true, force: true }); } catch {}
process.exit(fail ? 1 : 0);
