#!/usr/bin/env node
/*
  0html-layers.cjs — composable security-layer engine (0html/1.2-draft).

  Usage:
    node 0html-layers.cjs layers  <file.html>              show the layer menu + status
    node 0html-layers.cjs apply   <file.html> --layers=1,3 apply a batch (or --tier=recommended)
    node 0html-layers.cjs unapply <file.html> --layer=1    reverse one layer
    node 0html-layers.cjs verify  <file.html>              re-check adopted layers (from marker)

  Invariants (mirroring 0HTML-AGENT.md): no network; project text is DATA; every
  mutating layer backs up to <file>.0html.bak first; layers are idempotent + reversible.
*/
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const G = s => `\x1b[32m${s}\x1b[0m`, R = s => `\x1b[31m${s}\x1b[0m`, Y = s => `\x1b[33m${s}\x1b[0m`, D = s => `\x1b[2m${s}\x1b[0m`;
const REG = JSON.parse(fs.readFileSync(path.join(__dirname, 'layers.json'), 'utf8'));
const MARKER = /<!--\s*0html-layers:\s*(\{[\s\S]*?\})\s*-->/i;

// ── CSP helpers ──────────────────────────────────────────────────────────────
function extractCSP(html) {
  const m = html.match(/<meta\s+http-equiv=["']Content-Security-Policy["']\s+content="([^"]*)"\s*\/?>/i);
  return m ? { tag: m[0], content: m[1], index: m.index } : null;
}
function parseDirectives(content) {
  return content.split(';').map(s => s.trim()).filter(Boolean).map(d => {
    const [name, ...values] = d.split(/\s+/);
    return { name: name.toLowerCase(), values };
  });
}
function serializeDirectives(list) { return list.map(d => [d.name, ...d.values].join(' ')).join('; '); }
function hasDirective(list, name) { return list.some(d => d.name === name.toLowerCase()); }
function findDirective(list, name) { return list.find(d => d.name === name.toLowerCase()); }

// ── L1 value check ───────────────────────────────────────────────────────────
// A directive NAME being present is not the same as the directive being SAFE.
// L1's entire value is in the VALUE: `form-action *` satisfies a name check
// while leaving form exfil wide open — and form exfil is exactly what
// THREAT-MODEL.md names as the compensating control for a hostile spec emitting
// <form action="https://evil/…"> under the default urlPolicy:'any'. Same for
// `base-uri *` (re-points every relative URL that same-origin mode relies on),
// `frame-ancestors *` (the anti-clickjacking control) and `object-src *`.
// Presence-only checking made `apply` a no-op, `conformance` report ✓ intact,
// and `conformance --require=L1` exit 0 on a page with all four at '*'.
const WILDCARD_SRC = /^\*$|^\*\.|^(?:https?|data|blob|filesystem|ws|wss):$/i;
function directiveSatisfies(values, expected) {
  const v = (values || []).map(s => s.toLowerCase()).filter(Boolean);
  if (!v.length) return false;
  if (hasWildcardSource(v)) return false;                 // any wildcard/scheme-wide source defeats it
  const want = String(expected).toLowerCase();
  if (want === "'none'") return v.length === 1 && v[0] === "'none'";
  if (want === "'self'") return v.every(x => x === "'self'" || x === "'none'");
  return v.includes(want);
}
// Exposed separately because connect-src has no single "expected" value — the
// question there is only whether the source list is scoped at all.
/* Finding #26 lives here. 0mutate flagged this as a SURVIVOR: breaking it changed
   nothing, because it had zero call sites while the same test ran inline in two
   places. Dead code shaped like a guard is worse than no guard — a reader assumes
   it is load-bearing, and anyone "fixing" wildcard detection here would change
   nothing at all. Wired to both call sites so the concept has one home. */
function hasWildcardSource(values) {
  return (values || []).some((v) => WILDCARD_SRC.test(String(v).toLowerCase()));
}
// Directives the browser IGNORES when the policy is delivered in a <meta>
// element (CSP §3.3; confirmed in Chromium, which logs each one). L1 adds
// frame-ancestors to a meta policy and conformance certified it present — but
// it does nothing there. The single-file tools have the frame-buster script as
// a backstop; an app whose CSP is meta-only has no clickjacking control at all.
const META_IGNORED = new Set(['frame-ancestors', 'sandbox', 'report-uri']);
function metaIneffective(layer) {
  return (layer.addDirectives || []).map((d) => d.name).filter((n) => META_IGNORED.has(n));
}
function directiveOk(list, d) {
  const cur = findDirective(list, d.name);
  return !!cur && directiveSatisfies(cur.values, d.value);
}

// ── conformance marker (structured: records per-layer reversal data) ─────────
function readState(html) {
  const m = html.match(MARKER);
  if (!m) return {};
  try { return JSON.parse(m[1]); } catch { return {}; }
}
function readApplied(html) { return Object.keys(readState(html)).sort(); }
function writeState(html, state) {
  const marker = `<!-- 0html-layers: ${JSON.stringify(state)} -->`;
  if (MARKER.test(html)) return html.replace(MARKER, marker);
  if (/<head[^>]*>/i.test(html)) return html.replace(/(<head[^>]*>)/i, `$1\n${marker}`);
  return marker + '\n' + html;
}

// ── layer detection: is layer already satisfied? what would it do? ───────────
function detect(layer, html) {
  const csp = extractCSP(html);
  if (layer.kind === 'survey') return { status: 'n/a', note: 'read-only' };
  if (layer.kind === 'csp-directives') {
    if (!csp) return { status: 'blocked', note: 'no CSP meta present — add one first' };
    const list = parseDirectives(csp.content);
    const absent = layer.addDirectives.filter(d => !hasDirective(list, d.name));
    const weak = layer.addDirectives.filter(d => hasDirective(list, d.name) && !directiveOk(list, d));
    if (!absent.length && !weak.length) {
      const inert = metaIneffective(layer);
      return {
        status: 'done',
        note: inert.length
          ? `all baseline directives present and at their intended values — but ${inert.join(', ')} ${inert.length > 1 ? 'are' : 'is'} IGNORED in a <meta> CSP; serve ${inert.length > 1 ? 'them' : 'it'} as a response header (clickjacking is otherwise unprotected except by the frame-buster script)`
          : 'all baseline directives present and at their intended values',
      };
    }
    const parts = [];
    if (absent.length) parts.push(`would add: ${absent.map(d => d.name).join(', ')}`);
    if (weak.length) {
      parts.push(`would TIGHTEN (present but permissive): ${weak.map(d => `${d.name} ${findDirective(list, d.name).values.join(' ')} → ${d.value}`).join(', ')}`);
    }
    return { status: 'available', note: parts.join(' · '), missing: absent, weak };
  }
  // planned layers: report presence heuristics where cheap, else "available/planned"
  if (layer.kind === 'csp-hash-pin') return detectHashPin(html);
  if (layer.kind === 'tt-report-only') return detectTT(html);
  if (layer.kind === 'tt-enforce') return detectTTEnforce(html);
  if (layer.kind === 'connect-src-allowlist') return detectConnectSrc(html);
  if (layer.kind === 'style-src-hash-pin') return detectStyleSrc(html);
  return { status: 'planned', note: '' };
}

// ── L1 transform ─────────────────────────────────────────────────────────────
function applyCspDirectives(html, layer) {
  const csp = extractCSP(html);
  if (!csp) throw new Error('cannot apply ' + layer.id + ': no Content-Security-Policy meta tag found');
  const list = parseDirectives(csp.content);
  const added = [], tightened = [];
  for (const d of layer.addDirectives) {
    const cur = findDirective(list, d.name);
    if (!cur) { list.push({ name: d.name, values: [d.value] }); added.push(d.name); continue; }
    // Present but permissive: tighten it, recording the previous value so
    // unapply can put the author's original directive back verbatim.
    if (!directiveSatisfies(cur.values, d.value)) {
      tightened.push({ name: d.name, prev: cur.values.slice() });
      cur.values = [d.value];
    }
  }
  const newContent = serializeDirectives(list);
  const newTag = csp.tag.replace(/content="[^"]*"/, `content="${newContent}"`);
  return {
    html: html.replace(csp.tag, newTag),
    added: added.concat(tightened.map(t => `${t.name} (tightened)`)),
    meta: { tightened },
    changed: added.length > 0 || tightened.length > 0,
  };
}
function unapplyCspDirectives(html, layer, rec) {
  const csp = extractCSP(html);
  if (!csp) return { html, removed: [] };
  let list = parseDirectives(csp.content);
  // Accept both shapes: the legacy bare array of added names, and the record
  // written since value-tightening landed.
  const addedNames = Array.isArray(rec) ? rec : ((rec && rec.added) || []);
  const tightened = (rec && !Array.isArray(rec) && rec.tightened) || [];
  // reverse ONLY the directives this layer actually added — never pre-existing ones
  const names = new Set(addedNames.map(n => String(n).toLowerCase()).filter(n => !/ \(tightened\)$/.test(n)));
  const before = list.length;
  const removed = list.filter(d => names.has(d.name)).map(d => d.name);
  list = list.filter(d => !names.has(d.name));
  // restore any directive we tightened to the author's original value
  const restored = [];
  for (const t of tightened) {
    const cur = findDirective(list, t.name);
    if (cur) { cur.values = t.prev.slice(); restored.push(`${t.name} (restored)`); }
  }
  const newTag = csp.tag.replace(/content="[^"]*"/, `content="${serializeDirectives(list)}"`);
  return { html: html.replace(csp.tag, newTag), removed: removed.concat(restored), changed: list.length !== before || restored.length > 0 };
}

// ── L2: hash-pin inline scripts + drop 'unsafe-inline' ───────────────────────
function inlineScripts(html) {
  const out = []; const re = /<script\b([^>]*)>([\s\S]*?)<\/script>/gi; let m;
  while ((m = re.exec(html))) { if (/\bsrc\s*=/i.test(m[1])) continue; if (m[2].trim() === '') continue; out.push(m[2]); }
  return out;
}
function scriptHashes(html) {
  return inlineScripts(html).map(b => "'sha256-" + crypto.createHash('sha256').update(b, 'utf8').digest('base64') + "'");
}
function getScriptSrc(list) { return list.find(d => d.name === 'script-src'); }
function applyHashPin(html, layer) {
  const csp = extractCSP(html); if (!csp) throw new Error(layer.id + ': no Content-Security-Policy meta tag');
  const h = inlineHandlers(html);
  if (h > 0) throw new Error(`blocked: ${h} inline on* handler(s) present — removing 'unsafe-inline' would break them. Run: convert-handlers <file> — first, then re-run ${layer.id}.`);
  const list = parseDirectives(csp.content); const ss = getScriptSrc(list);
  if (!ss) throw new Error(layer.id + ': no script-src directive to pin');
  const hashes = scriptHashes(html);
  if (!hashes.length) throw new Error(layer.id + ': no inline <script> found to hash');
  const hadUnsafeInline = ss.values.includes("'unsafe-inline'");
  ss.values = ss.values.filter(v => v !== "'unsafe-inline'");
  const added = []; for (const x of hashes) if (!ss.values.includes(x)) { ss.values.push(x); added.push(x); }
  const newTag = csp.tag.replace(/content="[^"]*"/, `content="${serializeDirectives(list)}"`);
  return { html: html.replace(csp.tag, newTag), added, meta: { hadUnsafeInline }, changed: hadUnsafeInline || added.length > 0 };
}
function unapplyHashPin(html, layer, rec) {
  const csp = extractCSP(html); if (!csp) return { html, removed: [] };
  const list = parseDirectives(csp.content); const ss = getScriptSrc(list); if (!ss) return { html, removed: [] };
  const set = new Set(rec.added || []); const removed = ss.values.filter(v => set.has(v));
  ss.values = ss.values.filter(v => !set.has(v));
  if (rec.hadUnsafeInline && !ss.values.includes("'unsafe-inline'")) ss.values.push("'unsafe-inline'");
  const newTag = csp.tag.replace(/content="[^"]*"/, `content="${serializeDirectives(list)}"`);
  return { html: html.replace(csp.tag, newTag), removed };
}
function detectHashPin(html) {
  const csp = extractCSP(html); if (!csp) return { status: 'blocked', note: 'no CSP meta present' };
  const list = parseDirectives(csp.content); const ss = getScriptSrc(list);
  if (!ss) return { status: 'blocked', note: 'no script-src directive' };
  const h = inlineHandlers(html);
  if (ss.values.includes("'unsafe-inline'")) return { status: 'available', note: h ? `has 'unsafe-inline' · ⚠ ${h} inline handler(s) to convert first` : "script-src has 'unsafe-inline'" };
  const cur = scriptHashes(html); const missing = cur.filter(x => !ss.values.includes(x));
  if (missing.length) return { status: 'available', note: `${missing.length} inline script(s) not pinned — hashes STALE (re-run to re-pin)` };
  return { status: 'done', note: `'unsafe-inline' removed; ${cur.length} inline script(s) hash-pinned` };
}

// ── L3/L4 presence checks ────────────────────────────────────────────────────
// `require-trusted-types-for` takes exactly one value, 'script'. Bare, or with
// anything else, the directive is invalid and the browser ignores it — but both
// detectors did a substring test on the raw CSP content, so a valueless
// directive reported the layer as satisfied.
function ttRequired(content) {
  const d = parseDirectives(content).find((x) => x.name === 'require-trusted-types-for');
  return !!d && d.values.map((v) => v.toLowerCase()).includes("'script'");
}
// The enforce shim has to be a real <script> element. detectTTEnforce tested
// /0html: default Trusted Types policy/ against the whole file, so the marker
// sitting in an HTML comment — or a JS string — certified L4 as active with no
// policy registered anywhere in the document.
function ttShimPresent(html) {
  const masked = maskNonMarkup(html);
  for (const t of scanTags(masked)) {
    if (t.tag.toLowerCase() !== 'script') continue;
    const close = html.toLowerCase().indexOf('</script', t.end);
    if (close === -1) continue;
    const body = html.slice(t.end, close);
    if (/0html: default Trusted Types policy/.test(body) &&
        /createPolicy\s*\(\s*['"]default['"]/.test(body)) return true;
  }
  return false;
}

// ── L3: Trusted Types report-only (separate meta; no script change) ──────────
function extractReportOnly(html) {
  const m = html.match(/<meta\s+http-equiv=["']Content-Security-Policy-Report-Only["']\s+content="([^"]*)"\s*\/?>/i);
  return m ? { tag: m[0], content: m[1], index: m.index } : null;
}
function applyReportOnlyTT(html, layer) {
  const ro = extractReportOnly(html);
  if (ro) {
    const list = parseDirectives(ro.content);
    if (ttRequired(ro.content)) return { html, added: [], meta: { addedMeta: false }, changed: false };
    const existing = list.find((d) => d.name === 'require-trusted-types-for');
    if (existing) existing.values = ["'script'"];        // repair a valueless/ignored directive
    else list.push({ name: 'require-trusted-types-for', values: ["'script'"] });
    const newTag = ro.tag.replace(/content="[^"]*"/, `content="${serializeDirectives(list)}"`);
    return { html: html.replace(ro.tag, newTag), added: ['require-trusted-types-for'], meta: { addedMeta: false }, changed: true };
  }
  const metaTag = `<meta http-equiv="Content-Security-Policy-Report-Only" content="require-trusted-types-for 'script'">`;
  const csp = extractCSP(html);
  let out;
  if (csp) out = html.replace(csp.tag, csp.tag + '\n' + metaTag);
  else if (/<head[^>]*>/i.test(html)) out = html.replace(/(<head[^>]*>)/i, `$1\n${metaTag}`);
  else out = metaTag + '\n' + html;
  return { html: out, added: ['require-trusted-types-for'], meta: { addedMeta: true }, changed: true };
}
function unapplyReportOnlyTT(html, layer, rec) {
  const ro = extractReportOnly(html);
  if (!ro) return { html, removed: [] };
  if (rec.addedMeta) return { html: html.replace(ro.tag + '\n', '').replace(ro.tag, ''), removed: ['Content-Security-Policy-Report-Only'] };
  const list = parseDirectives(ro.content).filter(d => d.name !== 'require-trusted-types-for');
  const newTag = ro.tag.replace(/content="[^"]*"/, `content="${serializeDirectives(list)}"`);
  return { html: html.replace(ro.tag, newTag), removed: ['require-trusted-types-for'] };
}
function detectTT(html) {
  const ro = extractReportOnly(html);
  if (ro && ttRequired(ro.content)) return { status: 'done', note: 'TT report-only active — sinks reported in the browser console (browser-verify)' };
  if (ro && /require-trusted-types-for/i.test(ro.content)) {
    return { status: 'available', note: "require-trusted-types-for present but not set to 'script' — the browser ignores it" };
  }
  return { status: 'available', note: 'no Trusted Types report-only meta' };
}

// ── L5: connect-src allowlist (app-aware; needs --origins) ───────────────────
function applyConnectSrc(html, layer, origins) {
  const csp = extractCSP(html); if (!csp) throw new Error(layer.id + ': no Content-Security-Policy meta');
  if (!origins || !origins.length) throw new Error("blocked: " + layer.id + " needs --origins=<origin,origin> — connect-src * allows exfiltration to any host; supply the app's real endpoints.");
  const list = parseDirectives(csp.content); const cs = list.find(d => d.name === 'connect-src');
  const orig = cs ? cs.values.slice() : null;
  // ws:/wss: are governed by connect-src too; rejecting them left a WebSocket
  // app unable to scope L5 at all.
  const bad = origins.filter(function(o){ return !/^(?:https?|wss?):\/\/[a-z0-9.\-]+(:\d+)?$/i.test(o); });
  if (bad.length) throw new Error("blocked: " + layer.id + " invalid origin(s): " + bad.join(', ') + " — use scheme://host[:port] (http/https/ws/wss), no wildcards or paths");
  const vals = ["'self'"].concat(origins);
  if (cs) cs.values = vals; else list.push({ name: 'connect-src', values: vals });
  const newTag = csp.tag.replace(/content="[^"]*"/, `content="${serializeDirectives(list)}"`);
  return { html: html.replace(csp.tag, newTag), added: origins, meta: { origConnectSrc: orig }, changed: true };
}
function unapplyConnectSrc(html, layer, rec) {
  const csp = extractCSP(html); if (!csp) return { html, removed: [] };
  const list = parseDirectives(csp.content); const idx = list.findIndex(d => d.name === 'connect-src');
  if (idx < 0) return { html, removed: [] };
  if (rec.origConnectSrc) list[idx].values = rec.origConnectSrc; else list.splice(idx, 1);
  const newTag = csp.tag.replace(/content="[^"]*"/, `content="${serializeDirectives(list)}"`);
  return { html: html.replace(csp.tag, newTag), removed: ['connect-src (restored)'] };
}
function detectConnectSrc(html) {
  const csp = extractCSP(html); if (!csp) return { status: 'blocked', note: 'no CSP meta' };
  const cs = parseDirectives(csp.content).find(d => d.name === 'connect-src');
  if (!cs) return { status: 'available', note: 'no connect-src (default-src applies)' };
  // Only a literal '*' used to count as open. `connect-src https:` is
  // scheme-wide — fetch/XHR/WebSocket to ANY https host — and reported as
  // "scoped to 1 origin(s)", ✓ conformant, --require=L5 exit 0. connect-src is
  // the one directive whose entire purpose is to stop exactly that, and
  // applyConnectSrc's own error text says so: "connect-src * allows
  // exfiltration to any host; supply the app's real endpoints."
  const wide = cs.values.filter((v) => hasWildcardSource([v]));
  if (wide.length) return { status: 'available', note: `connect-src ${wide.join(' ')} is open to any host — supply --origins to scope` };
  return { status: 'done', note: `connect-src scoped to ${cs.values.filter(v => v !== "'self'").length} origin(s)` };
}

// ── L8: style-src hardening (hash-pin <style> blocks, drop 'unsafe-inline') ───
// Locate <style> with the quote-aware scanner: a [^>]* opener ends at a '>'
// inside an attribute, which would hash the wrong text and pin a hash the
// browser never computes — blocking the stylesheet under enforce.
function styleBlocks(html) {
  const out = []; const masked = maskNonMarkup(html);
  for (const t of scanTags(masked)) {
    if (t.tag.toLowerCase() !== 'style') continue;
    const close = html.toLowerCase().indexOf('</style', t.end);
    if (close === -1) continue;
    const body = html.slice(t.end, close);
    if (body.trim()) out.push(body);
  }
  return out;
}
function styleHashes(html) { return styleBlocks(html).map(b => "'sha256-" + crypto.createHash('sha256').update(b,'utf8').digest('base64') + "'"); }
// This is the interlock applyStyleSrc uses to refuse dropping style-src
// 'unsafe-inline'. It only matched DOUBLE-QUOTED values and its [^>]+ could not
// cross a '>' inside an earlier attribute, so `<p title="a > b" style="…">` and
// `<b style='…'>` both counted as zero — L8 then dropped 'unsafe-inline' with
// live inline styles in the document. Same failure the L2 handler counter had.
function inlineStyleAttrs(html) {
  let n = 0;
  for (const t of scanTags(maskNonMarkup(html))) {
    const a = t.attrs.find((x) => x.name.toLowerCase() === 'style');
    if (a && a.valStart >= 0 && html.slice(a.valStart, a.valEnd).trim()) n++;
  }
  return n;
}
function getStyleSrc(list) { return list.find(d => d.name === 'style-src'); }
function applyStyleSrc(html, layer) {
  const csp = extractCSP(html); if (!csp) throw new Error(layer.id + ': no Content-Security-Policy meta');
  const a = inlineStyleAttrs(html);
  if (a > 0) throw new Error("blocked: " + a + " inline style= attribute(s) present — removing style-src 'unsafe-inline' would break them. Move them to a <style> block or a class first, then re-run " + layer.id + ".");
  const list = parseDirectives(csp.content); const ss = getStyleSrc(list);
  if (!ss) throw new Error(layer.id + ": no style-src directive to harden");
  const hashes = styleHashes(html);
  const hadUnsafeInline = ss.values.includes("'unsafe-inline'");
  ss.values = ss.values.filter(v => v !== "'unsafe-inline'");
  const added = []; for (const h of hashes) if (!ss.values.includes(h)) { ss.values.push(h); added.push(h); }
  const newTag = csp.tag.replace(/content="[^"]*"/, `content="${serializeDirectives(list)}"`);
  return { html: html.replace(csp.tag, newTag), added, meta: { hadUnsafeInline }, changed: hadUnsafeInline || added.length > 0 };
}
function unapplyStyleSrc(html, layer, rec) {
  const csp = extractCSP(html); if (!csp) return { html, removed: [] };
  const list = parseDirectives(csp.content); const ss = getStyleSrc(list); if (!ss) return { html, removed: [] };
  const set = new Set(rec.added || []); const removed = ss.values.filter(v => set.has(v));
  ss.values = ss.values.filter(v => !set.has(v));
  if (rec.hadUnsafeInline && !ss.values.includes("'unsafe-inline'")) ss.values.push("'unsafe-inline'");
  const newTag = csp.tag.replace(/content="[^"]*"/, `content="${serializeDirectives(list)}"`);
  return { html: html.replace(csp.tag, newTag), removed };
}
function detectStyleSrc(html) {
  const csp = extractCSP(html); if (!csp) return { status: 'blocked', note: 'no CSP meta' };
  const list = parseDirectives(csp.content); const ss = getStyleSrc(list);
  if (!ss) return { status: 'available', note: 'no style-src (default-src applies)' };
  const a = inlineStyleAttrs(html);
  if (ss.values.includes("'unsafe-inline'")) return { status: 'available', note: a ? `style-src has 'unsafe-inline' · ⚠ ${a} inline style= attr(s) to move first` : "style-src has 'unsafe-inline'" };
  const cur = styleHashes(html); const missing = cur.filter(h => !ss.values.includes(h));
  if (missing.length) return { status: 'available', note: `${missing.length} <style> block(s) not pinned — stale` };
  return { status: 'done', note: `'unsafe-inline' removed from style-src; ${cur.length} <style> block(s) pinned` };
}

// ── sink survey (L0) ─────────────────────────────────────────────────────────
function surveySinks(html) {
  const scripts = (html.match(/<script[^>]*>([\s\S]*?)<\/script>/gi) || []).map(s => s.replace(/<\/?script[^>]*>/gi, '')).join('\n');
  const sink = /\.(innerHTML|outerHTML)\s*=|insertAdjacentHTML/g;
  const lines = scripts.split('\n');
  let A = 0, B = 0, C = 0, Dn = 0, handlers = 0;
  for (const ln of lines) {
    if (!sink.test(ln)) { sink.lastIndex = 0; } else {
      sink.lastIndex = 0;
      if (/\.innerHTML\s*=\s*['"]\s*['"]/.test(ln)) A++;
      else if (/\.(innerHTML|outerHTML)\s*=\s*`[^`]*\$\{/.test(ln) || /\.(innerHTML|outerHTML)\s*=\s*[^'"`;]+\+/.test(ln)) {
        (/htmlEsc|escapeHtml|_esc\b/.test(ln)) ? C++ : Dn++;
      } else B++;
    }
  }
  handlers = inlineHandlers(html);
  return { A, B, C, D: Dn, handlers, total: A + B + C + Dn };
}

// ── Handler conversion (L2 prerequisite): inline on* → addEventListener ───────
const HANDLER_MARKER = /<!--\s*0html-handlers:\s*(\{[\s\S]*?\})\s*-->/i;

// The shared HTML scanner. See 0scan-html.cjs for why this is one module and
// not seven regexes; it is integrity-pinned alongside the engine.
const {
  decodeEntities, maskNonMarkup, scanTags,
  isHandlerAttr, isUnknownOnAttr,
  findHandlers, scriptEmbeddedHandlers, inlineHandlers,
} = require(path.join(__dirname, '0scan-html.cjs'));
function sbody(b) { return String(b).replace(/<\/(script)/gi, '<\\/$1'); }

function cmdConvertHandlers(file) {
  let html = fs.readFileSync(file, 'utf8');
  // A document already carrying data-0h hooks means either a previous
  // conversion was not reversed, or the attribute is in use for something else.
  // Either way a second pass assigns colliding ids, appends a second wiring
  // script, and leaves restore-handlers unable to match hooks to records — the
  // fuzzer hits this by generating data-0h attributes directly. Refuse before
  // touching the file rather than half-converting it.
  // An unterminated attribute value swallows everything after it, including the
  // wiring <script> this command appends — so the conversion would report
  // success while the handlers it just rewired could never be bound. Editing
  // markup that does not tokenise is not something to do on a best-effort basis.
  const broken = scanTags(maskNonMarkup(html)).filter((t) => t.unterminated);
  if (broken.length) {
    const first = html.slice(broken[0].index, Math.min(broken[0].index + 60, html.length)).split('\n')[0];
    console.error(R(`  \u2717 ${broken.length} unterminated tag(s) — the document does not tokenise`));
    console.error(D(`    first at offset ${broken[0].index}: ${JSON.stringify(first)}`));
    console.error(D('    an unclosed quote swallows the markup after it (including anything this'));
    console.error(D('    command would add). Fix the markup, then re-run.'));
    process.exitCode = 1;
    return;
  }
  const existingHooks = [];
  for (const t of scanTags(maskNonMarkup(html))) {
    const a = t.attrs.find((x) => x.name.toLowerCase() === 'data-0h');
    if (a) existingHooks.push(a.valStart >= 0 ? html.slice(a.valStart, a.valEnd) : '');
  }
  if (existingHooks.length) {
    const converted = HANDLER_MARKER.test(html);
    console.error(R(`  \u2717 ${existingHooks.length} element(s) already carry data-0h`));
    console.error(D(converted
      ? '    this file has already been converted — run `restore-handlers` first, or leave it as is.'
      : '    data-0h is this tool\'s hook attribute; rename yours before converting.'));
    process.exitCode = 1;
    return;
  }
  const found = findHandlers(html);
  const embeddedEarly = scriptEmbeddedHandlers(html);
  if (!found.length) {
    if (embeddedEarly) {
      // There is nothing for THIS command to do, but saying "L2 can proceed"
      // here would be wrong: those handlers are real once the markup is
      // injected, and L2 will block them.
      console.log(Y(`  \u26a0 no convertible inline on* handlers in the markup, but ${embeddedEarly} live inside <script> as markup string(s)`));
      console.log(D("    L2 would drop 'unsafe-inline' and break them. Move that markup to createElement +"));
      console.log(D("    addEventListener before running L2, or keep 'unsafe-inline'."));
      return;
    }
    console.log('  no inline on* handlers found — nothing to convert (L2 can proceed)');
    return;
  }
  const bak = file + '.0html.bak';
  if (!fs.existsSync(bak)) { fs.copyFileSync(file, bak); console.log(D(`  backup: ${path.basename(bak)}`)); }
  found.forEach((f, i) => f.id = i + 1);
  const record = [], flagged = [];
  for (const f of found) for (const h of f.handlers) {
    record.push({ id: f.id, ev: h.ev, raw: h.raw, body: h.body });
    if (/\breturn\b/.test(h.body)) flagged.push(`[data-0h="${f.id}"] on${h.ev}: uses 'return' — inline return-false is auto-wrapped (return false -> event.preventDefault()); verify in a browser`);
  }
  // Rewrite by exact span, back to front, so earlier offsets stay valid.
  for (const f of [...found].sort((a, b) => b.index - a.index)) {
    let tagText = html.slice(f.index, f.end);
    for (const sp of [...f.spans].sort((a, b) => b.start - a.start)) {
      tagText = tagText.slice(0, sp.start - f.index) + tagText.slice(sp.end - f.index);
    }
    const selfClose = /\/>$/.test(tagText);
    tagText = tagText.replace(/\s*\/?>$/, '') + ` data-0h="${f.id}"` + (selfClose ? ' />' : '>');
    html = html.slice(0, f.index) + tagText + html.slice(f.end);
  }
  const wire = record.map(r => `    q('${r.id}').forEach(function(el){ el.addEventListener('${r.ev}', function(event){ var _r=(function(){ ${sbody(r.body)} }).call(el); if(_r===false)event.preventDefault(); }); });`).join('\n');
  const script = `<script>\n/* 0html: inline handlers converted to addEventListener (L2 prerequisite) */\n(function(){\n  function q(id){ return document.querySelectorAll('[data-0h="'+id+'"]'); }\n  function wire(){\n${wire}\n  }\n  if (document.readyState !== 'loading') wire(); else document.addEventListener('DOMContentLoaded', wire);\n})();\n</script>`;
  html = /<\/body>/i.test(html) ? html.replace(/<\/body>/i, script + '\n</body>') : html + script;
  const marker = `<!-- 0html-handlers: ${JSON.stringify({ converted: record.map(r => ({ id: r.id, ev: r.ev, raw: r.raw })) })} -->`;
  html = HANDLER_MARKER.test(html) ? html.replace(HANDLER_MARKER, marker) : (/<head[^>]*>/i.test(html) ? html.replace(/(<head[^>]*>)/i, `$1\n${marker}`) : marker + '\n' + html);
  fs.writeFileSync(file, html);
  // Post-condition. The point of this command is to justify dropping
  // 'unsafe-inline'; saying "converted" while a handler survives is the one
  // failure mode that matters, so assert it rather than assume it.
  const unknownOn = [];
  for (const t of scanTags(maskNonMarkup(html))) {
    for (const a of t.attrs) if (isUnknownOnAttr(a.name) && a.valStart >= 0) unknownOn.push(a.name);
  }
  if (unknownOn.length) {
    console.log(D(`  \u00b7 left alone: ${[...new Set(unknownOn)].join(', ')} \u2014 on-prefixed but not event handler attributes, so inert in the browser`));
  }
  const embedded = scriptEmbeddedHandlers(html);
  if (embedded) {
    console.log(Y(`  \u26a0 ${embedded} inline handler(s) are written inside <script> as markup strings`));
    console.log(D("    not converted (rewriting a string literal breaks it) — but they ARE inline handlers"));
    console.log(D("    once injected, and L2 will block them. Move that markup to createElement +"));
    console.log(D("    addEventListener, or keep 'unsafe-inline'."));
  }
  const leftover = inlineHandlers(html);
  if (leftover) {
    console.log(R(`  ✗ ${leftover} inline handler(s) STILL PRESENT after conversion — do NOT run L2`));
    console.log(D('    the file has been left converted-in-part; restore with `restore-handlers` and report this.'));
  }
  console.log(G(`  ✓ converted ${record.length} inline handler(s) on ${found.length} element(s) → addEventListener`));
  if (flagged.length) { console.log(Y('  ⚠ review (return-value semantics differ from inline handlers):')); flagged.forEach(x => console.log('    ' + x)); }
  console.log(D('  → inline handlers gone; run `apply --layers=2` to hash-pin. Reverse with `restore-handlers`.'));
}
function cmdRestoreHandlers(file) {
  let html = fs.readFileSync(file, 'utf8');
  const m = html.match(HANDLER_MARKER);
  if (!m) { console.log('  no handler-conversion record found (nothing to restore)'); return; }
  let rec; try { rec = JSON.parse(m[1]).converted || []; } catch { console.error(R('  corrupt handler record')); process.exit(1); }
  html = html.replace(/<script>\s*\/\* 0html: inline handlers converted[\s\S]*?<\/script>\s*/i, '');
  const byId = {}; for (const r of rec) (byId[r.id] = byId[r.id] || []).push(r);
  // Locate each hook with the same scanner the converter uses. The old
  // `(<[a-z][\w-]*\b[^>]*?)\s*data-0h="N"` could not cross a '>' inside an
  // earlier quoted attribute, so `<p title="a > b" data-0h="2">` never matched
  // and its handler was DROPPED on restore — silent data loss, on exactly the
  // markup the scanner newly made convertible.
  const hooks = [];
  for (const t of scanTags(maskNonMarkup(html))) {
    const a = t.attrs.find(x => x.name.toLowerCase() === 'data-0h' && x.valStart >= 0);
    if (!a) continue;
    const id = html.slice(a.valStart, a.valEnd);
    if (!byId[id]) continue;
    let start = a.start; while (start > 0 && /[ \t]/.test(html[start - 1])) start--;
    hooks.push({ id, start, end: a.end });
  }
  const restoredIds = new Set(hooks.map(h => h.id));
  for (const h of hooks.sort((x, y) => y.start - x.start)) {
    const attrs = byId[h.id].map(r => ` on${r.ev}="${String(r.raw).replace(/"/g, '&quot;')}"`).join('');
    html = html.slice(0, h.start) + attrs + html.slice(h.end);
  }
  const lost = Object.keys(byId).filter(id => !restoredIds.has(id));
  if (lost.length) {
    console.error(R(`  \u2717 could not locate data-0h hook(s) ${lost.join(', ')} — ${lost.reduce((n, id) => n + byId[id].length, 0)} handler(s) NOT restored`));
    console.error(D('    the record is intact; the document was edited after conversion. Restore from the .0html.bak instead.'));
    process.exit(1);
  }
  html = html.replace(HANDLER_MARKER, '');
  fs.writeFileSync(file, html);
  console.log(G(`  ✓ restored ${rec.length} inline handler(s); removed the wiring script + data-hooks`));
}

// ── commands ─────────────────────────────────────────────────────────────────
function securityNotes(html) {
  const notes = []; const csp = extractCSP(html);
  if (!csp) { notes.push(['HIGH', 'no Content-Security-Policy meta \u2014 no platform hardening possible']); }
  else {
    const list = parseDirectives(csp.content); const get = n => list.find(d => d.name === n);
    const ss = get('script-src'), sty = get('style-src');
    if (ss && ss.values.includes("'unsafe-eval'")) notes.push(['HIGH', "script-src has 'unsafe-eval' \u2014 enables string\u2192code (eval/Function); remove it"]);
    if (ss && ss.values.includes("'unsafe-inline'")) notes.push(['MED', "script-src has 'unsafe-inline' \u2014 adopt L2 to hash-pin and drop it"]);
    if (ss && ss.values.includes('*')) notes.push(['HIGH', "script-src allows '*' \u2014 any origin can load scripts"]);
    if (sty && sty.values.includes("'unsafe-inline'")) notes.push(['LOW', "style-src has 'unsafe-inline' \u2014 CSS-injection surface; adopt L8 or move inline styles to classes"]);
    for (const d of list) {
      if (/^(img|media|font|connect|child|worker|object|default)-src$/.test(d.name)) {
        const broad = d.values.filter(v => v === '*' || v === 'https:' || v === 'http:');
        if (broad.length) notes.push(['MED', d.name + " allows " + broad.join(' ') + " \u2014 broad (possible exfil/injection vector; scope it)"]);
      }
    }
    for (const req of ['frame-ancestors', 'object-src', 'base-uri', 'form-action']) if (!get(req)) notes.push(['MED', 'missing ' + req + ' \u2014 adopt L1']);
  }
  const ext = []; let m;
  const reS = /<script\b[^>]*\bsrc\s*=\s*["']([^"']+)["'][^>]*>/gi;
  while ((m = reS.exec(html))) ext.push({ src: m[1], integ: /integrity\s*=/i.test(m[0]) });
  const reL = /<link\b[^>]*>/gi;
  while ((m = reL.exec(html))) { const t = m[0]; if (/rel\s*=\s*["']stylesheet["']/i.test(t)) { const h = t.match(/href\s*=\s*["']([^"']+)["']/i); if (h) ext.push({ src: h[1], integ: /integrity\s*=/i.test(t) }); } }
  const noSri = ext.filter(e => !e.integ);
  if (!ext.length) notes.push(['OK', 'no external <script>/<link> \u2014 self-contained']);
  else if (noSri.length) notes.push(['MED', noSri.length + ' external resource(s) without SRI \u2014 run audit-sri (' + noSri.slice(0, 2).map(e => e.src).join(', ') + ')']);
  else notes.push(['OK', ext.length + ' external resource(s), all carry SRI \u2014 verify with audit-sri']);
  return notes;
}

function cmdLayers(file) {
  const html = fs.readFileSync(file, 'utf8');
  const csp = extractCSP(html);
  const applied = readApplied(html);
  const sinks = surveySinks(html);
  console.log(`\n  0html LAYER MENU — ${path.basename(file)}`);
  console.log(`  ${D('CSP')} ${csp ? 'present' : R('ABSENT')}   ${D('adopted layers:')} ${applied.length ? applied.join(', ') : 'none'}`);
  console.log(`  ${D('innerHTML sinks:')} ${sinks.total}  (clear ${sinks.A} · static ${sinks.B} · dyn-escaped ${sinks.C} · ${sinks.D ? R('dyn-UNescaped ' + sinks.D + ' ⚠ eyeball') : 'dyn-UNescaped 0'})  ${D('inline handlers:')} ${sinks.handlers}\n`);
  for (const L of REG.layers) {
    const d = detect(L, html);
    const isApplied = applied.includes(L.id);
    const tag = isApplied ? G('✓ applied') : d.status === 'done' ? G('done') : d.status === 'available' ? Y('available') : d.status === 'blocked' ? R('blocked') : d.status === 'n/a' ? D('n/a') : D('planned');
    const port = L.portable ? '' : D(' [app-aware]');
    console.log(`  ${L.id.padEnd(3)} ${(tag).padEnd(20)} ${L.name}${port}`);
    console.log(`        ${D(L.value)}`);
    if (d.note) console.log(`        ${D('→ ' + d.note)}`);
  }
  const _sn = securityNotes(html);
  if (_sn.length) { console.log('\n  ' + D('SECURITY NOTES  (posture beyond the layer menu)')); for (const [sv, tx] of _sn) { const c = sv === 'HIGH' ? R : sv === 'OK' ? G : D; console.log('    ' + c('[' + sv.padEnd(4) + ']') + ' ' + tx); } }
  console.log(`\n  ${D('apply:')} node 0html-layers.cjs apply ${path.basename(file)} --layers=1,3   ${D('| tiers: safe · recommended · max')}`);
  console.log(`  ${D('tiers →')} safe=${REG.tiers.safe.join(',')}  recommended=${REG.tiers.recommended.join(',')}  max=${REG.tiers.max.join(',')}\n`);
}

function resolveBatch(arg) {
  if (arg.tier) { const t = REG.tiers[arg.tier]; if (!t) throw new Error('unknown tier: ' + arg.tier); return t.slice(); }
  if (arg.layers) return arg.layers.split(',').map(s => 'L' + s.trim().replace(/^L/i, '')).map(s => s.toUpperCase());
  throw new Error('specify --layers=1,2 or --tier=recommended');
}

function cmdApply(file, arg) {
  let html = fs.readFileSync(file, 'utf8');
  const want = resolveBatch(arg);
  // resolve + expand prereqs, keep registry order
  const ids = new Set(want);
  for (const id of want) { const L = REG.layers.find(l => l.id === id); (L && L.prereq || []).forEach(p => ids.add(p)); }
  const batch = REG.layers.filter(l => ids.has(l.id));
  const unknown = want.filter(id => !REG.layers.some(l => l.id === id));
  if (unknown.length) { console.error(R('  unknown layer(s): ' + unknown.join(', '))); process.exit(1); }

  console.log(`\n  applying batch: ${batch.map(l => l.id).join(', ')}  → ${path.basename(file)}`);
  const bak = file + '.0html.bak';
  if (!fs.existsSync(bak)) { fs.copyFileSync(file, bak); console.log(D(`  backup: ${path.basename(bak)}`)); }

  let state = readState(html), fail = 0;
  for (const L of batch) {
    if (L.status && L.status.startsWith('planned')) { console.log(`  ${Y('skip')} ${L.id} (${L.name}) — not yet implemented in this build`); continue; }
    if (L.kind === 'survey') { console.log(`  ${D('—')} ${L.id} survey is read-only (run \`layers\`)`); continue; }
    const d = detect(L, html);
    if (d.status === 'done' && state[L.id]) { console.log(`  ${G('=')} ${L.id} already satisfied (idempotent no-op)`); continue; }
    if (d.status === 'blocked') { console.log(`  ${R('✗')} ${L.id} blocked: ${d.note}`); fail++; continue; }

    let res;
    try {
      if (L.kind === 'csp-directives') res = applyCspDirectives(html, L);
      else if (L.kind === 'csp-hash-pin') res = applyHashPin(html, L);
      else if (L.kind === 'tt-report-only') res = applyReportOnlyTT(html, L);
      else if (L.kind === 'connect-src-allowlist') res = applyConnectSrc(html, L, (arg.origins || '').split(',').map(x => x.trim()).filter(Boolean));
      else if (L.kind === 'tt-enforce') res = applyTTEnforce(html, L, state);
      else if (L.kind === 'style-src-hash-pin') res = applyStyleSrc(html, L);
      else { console.log(`  ${Y('skip')} ${L.id} — kind '${L.kind}' not implemented yet`); continue; }
    } catch (e) { console.log(`  ${R('✗')} ${L.id} ${e.message}`); fail++; continue; }

    html = res.html;
    state[L.id] = Object.assign({}, state[L.id], { added: ((state[L.id] && state[L.id].added) || []).concat(res.added || []) }, res.meta || {});
    // verify
    const post = detect(L, html);
    const ok = post.status === 'done';
    console.log(`  ${ok ? G('✓') : R('✗')} ${L.id} ${L.name} — ${res.added && res.added.length ? 'added ' + res.added.join(', ') : 'no change'} ${ok ? D('(verified)') : R('(verify FAILED)')}`);
    if (!ok) fail++;
  }
  html = writeState(html, state);
  fs.writeFileSync(file, html);
  console.log(fail ? R(`\n  ${fail} layer(s) failed — see above; ${path.basename(bak)} holds the pre-change file\n`) : G(`\n  ✓ batch applied + verified · adopted: ${readApplied(html).join(', ')}\n`));
  process.exit(fail ? 1 : 0);
}

function cmdUnapply(file, arg) {
  let html = fs.readFileSync(file, 'utf8');
  const id = ('L' + String(arg.layer).replace(/^L/i, '')).toUpperCase();
  const L = REG.layers.find(l => l.id === id);
  if (!L) { console.error(R('  unknown layer: ' + id)); process.exit(1); }
  const state = readState(html);
  const rec = state[id];
  if (!rec) { console.log(Y(`  ${id} is not applied (nothing to reverse)`)); process.exit(0); }
  let res = { removed: [] };
  if (L.kind === 'csp-directives') res = unapplyCspDirectives(html, L, rec);
  else if (L.kind === 'csp-hash-pin') res = unapplyHashPin(html, L, rec);
  else if (L.kind === 'tt-report-only') res = unapplyReportOnlyTT(html, L, rec);
  else if (L.kind === 'connect-src-allowlist') res = unapplyConnectSrc(html, L, rec);
  else if (L.kind === 'tt-enforce') res = unapplyTTEnforce(html, L, rec, readState(html));
  else if (L.kind === 'style-src-hash-pin') res = unapplyStyleSrc(html, L, rec);
  else { console.error(R(`  unapply for kind '${L.kind}' not implemented`)); process.exit(1); }
  html = res.html;
  delete state[id];
  html = writeState(html, state);
  fs.writeFileSync(file, html);
  console.log(G(`  ✓ ${id} reversed — removed ${res.removed.join(', ') || '(nothing)'} · adopted: ${Object.keys(state).join(', ') || 'none'}`));
}

function cmdVerify(file) {
  const html = fs.readFileSync(file, 'utf8');
  const applied = readApplied(html);
  if (!applied.length) { console.log('  no adopted layers recorded (no marker)'); return; }
  let fail = 0;
  console.log(`\n  verifying adopted layers: ${applied.join(', ')}`);
  for (const id of applied) {
    const L = REG.layers.find(l => l.id === id);
    if (!L) { console.log(`  ${Y('?')} ${id} not in registry`); continue; }
    const d = detect(L, html);
    const ok = d.status === 'done';
    console.log(`  ${ok ? G('✓') : R('✗')} ${id} ${L.name} ${ok ? D('(intact)') : R('(DRIFT: ' + d.note + ')')}`);
    if (!ok) fail++;
    if (L.verifyBrowser) console.log(`        ${D('browser check: ' + L.verifyBrowser)}`);
  }
  console.log(fail ? R(`\n  ${fail} layer(s) drifted\n`) : G('\n  ✓ all adopted layers intact\n'));
  process.exit(fail ? 1 : 0);
}

function cmdConformance(file, arg) {
  const html = fs.readFileSync(file, 'utf8');
  const state = readState(html);
  const adopted = Object.keys(state).sort();
  const csp = extractCSP(html);
  const layers = adopted.map(id => {
    const L = REG.layers.find(l => l.id === id) || { name: '?' };
    const d = detect(L, html);
    return { id, name: L.name, intact: d.status === 'done', added: state[id].added || [], note: d.note };
  });
  const required = arg.require ? String(arg.require).split(',').map(function(x){ return ('L' + x.trim().replace(/^L/i, '')).toUpperCase(); }) : [];
  const missingRequired = required.filter(function(id){ return !adopted.includes(id); });
  const report = {
    standard: REG.standard, spec: REG.spec, target: path.basename(file),
    sha256: crypto.createHash('sha256').update(html).digest('hex'),
    csp: csp ? 'present' : 'absent',
    adopted, layers, required, missingRequired,
    conformant: layers.every(function(l){ return l.intact; }) && missingRequired.length === 0
  };
  if (arg.json) { process.stdout.write(JSON.stringify(report, null, 2) + '\n'); process.exit(report.conformant ? 0 : 1); }
  console.log(`\n  0html CONFORMANCE — ${report.target}`);
  console.log(`  ${D('standard')} ${report.standard} · ${report.spec}   ${D('sha256')} ${report.sha256.slice(0, 16)}…`);
  console.log(`  ${D('adopted')} ${adopted.length ? adopted.join(', ') : 'none'}`);
  for (const l of layers) console.log(`  ${l.intact ? G('✓') : R('✗ DRIFT')} ${l.id} ${l.name} ${l.added.length ? D('(added ' + l.added.join(', ') + ')') : ''}`);
  console.log(report.conformant ? G('\n  ✓ conformant — deployed posture matches the record\n') : R('\n  ✗ NON-CONFORMANT — posture drifted from the record\n'));
  process.exit(report.conformant ? 0 : 1);
}

function repin(html, state) {
  if (!state.L2) return html;
  const csp = extractCSP(html); if (!csp) return html;
  const list = parseDirectives(csp.content); const ss = getScriptSrc(list); if (!ss) return html;
  const oldHashes = new Set((state.L2.added || []).filter(h => /^'sha256-/.test(h)));
  ss.values = ss.values.filter(v => !oldHashes.has(v) && v !== "'unsafe-inline'");
  const cur = scriptHashes(html);
  for (const h of cur) if (!ss.values.includes(h)) ss.values.push(h);
  state.L2 = { added: cur, hadUnsafeInline: state.L2.hadUnsafeInline };
  return html.replace(csp.tag, csp.tag.replace(/content="[^"]*"/, `content="${serializeDirectives(list)}"`));
}

// ── L4: Trusted Types enforce (default passthrough policy; needs browser verify) ──
const TT_SHIM = `<script>/* 0html: default Trusted Types policy (L4 enforce) */\nif(window.trustedTypes&&window.trustedTypes.createPolicy){try{window.trustedTypes.createPolicy('default',{createHTML:function(s){return s},createScript:function(){throw new Error('0html: string-to-script blocked (TT enforce)')},createScriptURL:function(){throw new Error('0html: dynamic script URL blocked (TT enforce)')}});}catch(e){}}\n</script>`;
function applyTTEnforce(html, layer, state) {
  const csp = extractCSP(html); if (!csp) throw new Error(layer.id + ': no Content-Security-Policy meta');
  if (ttShimPresent(html)) return { html, added: [], meta: {}, changed: false };
  let out = /<head[^>]*>/i.test(html) ? html.replace(/(<head[^>]*>)/i, `$1\n${TT_SHIM}`) : TT_SHIM + '\n' + html;
  const c2 = extractCSP(out); const list = parseDirectives(c2.content); const added = [];
  const rt = list.find((d) => d.name === 'require-trusted-types-for');
  if (!rt) { list.push({ name: 'require-trusted-types-for', values: ["'script'"] }); added.push('require-trusted-types-for'); }
  else if (!rt.values.map((v) => v.toLowerCase()).includes("'script'")) { rt.values = ["'script'"]; added.push('require-trusted-types-for (value repaired)'); }
  out = out.replace(c2.tag, c2.tag.replace(/content="[^"]*"/, `content="${serializeDirectives(list)}"`));
  out = repin(out, state);  // the shim is a new inline script — refresh L2's hashes if adopted
  return { html: out, added, meta: { addedShim: true }, changed: true };
}
function unapplyTTEnforce(html, layer, rec, state) {
  let out = html.replace(/<script>\/\* 0html: default Trusted Types policy[^]*?<\/script>\s*/i, '');
  const csp = extractCSP(out);
  if (csp) { const list = parseDirectives(csp.content).filter(d => d.name !== 'require-trusted-types-for'); out = out.replace(csp.tag, csp.tag.replace(/content="[^"]*"/, `content="${serializeDirectives(list)}"`)); }
  if (state) out = repin(out, state);
  return { html: out, removed: ['default TT policy + require-trusted-types-for'] };
}
function detectTTEnforce(html) {
  const csp = extractCSP(html);
  const directive = !!csp && ttRequired(csp.content);
  const shim = ttShimPresent(html);
  if (directive && shim) {
    // Note deliberately does NOT promise DOM-XSS immunity: the default policy's
    // createHTML is a passthrough by design (WHAT-IT-DOES.md §5, THREAT-MODEL N7),
    // so "0 TT violations" only ever exercises the script-sink half.
    return { status: 'done', note: 'TT enforce active — string→script blocked; HTML passes through the default policy (choke point, not sanitiser: see THREAT-MODEL N7). BROWSER-VERIFY the app still loads.' };
  }
  if (directive && !shim) return { status: 'available', note: 'enforce directive set but no default-policy <script> in the document — every TT sink will throw' };
  if (!directive && shim) return { status: 'available', note: "default policy present but require-trusted-types-for is missing or not 'script'" };
  return { status: 'available', note: 'no TT enforce (L3 report-only first, then verify sinks)' };
}

function cmdUpdate(file) {
  let html = fs.readFileSync(file, 'utf8');
  const state = readState(html);
  if (!state.L2) { console.log('  no hash-pin (L2) adopted — nothing to refresh'); return; }
  const csp = extractCSP(html);
  if (!csp) { console.error(R('  no Content-Security-Policy meta')); process.exit(1); }
  const cur = scriptHashes(html);
  html = repin(html, state);
  html = writeState(html, state);
  fs.writeFileSync(file, html);
  const d = detectHashPin(html);
  console.log(d.status === 'done' ? G(`  ✓ re-pinned L2 — ${cur.length} inline script(s) hashed; posture refreshed`) : R('  ✗ re-pin failed: ' + d.note));
  process.exit(d.status === 'done' ? 0 : 1);
}

function cmdAuditSecrets(file) {
  const html = fs.readFileSync(file, 'utf8');
  const scripts = inlineScripts(html).join('\n');
  const re = /(localStorage|sessionStorage)\.setItem\s*\(\s*['"`]?([a-z0-9_.\-]*(?:key|token|secret|apikey|api_key|password|credential|auth)[a-z0-9_.\-]*)/gi;
  const hits = []; let m; while ((m = re.exec(scripts))) hits.push(m[1] + ".setItem('" + m[2] + "', ...)");
  console.log(`\n  0html SECRET-STORAGE AUDIT (L6, advisory) - ${path.basename(file)}`);
  if (!hits.length) { console.log(G('  \u2713 no obvious secret-storage sites')); return; }
  console.log(R(`  \u26a0 ${hits.length} secret-storage site(s):`));
  hits.forEach(h => console.log('    ' + h));
  console.log(D('\n  ADVISORY: a browser-only app cannot hold a key any running script can read. TT/CSP\n  (L2-L4) reduce rogue-script risk; they do NOT isolate the secret. Options, strongest first:\n    1. Keep the secret server-side; the browser holds only a short-lived scoped token.\n    2. Web-Crypto-wrap the key with a user passphrase (never plaintext at rest).\n    3. sessionStorage (cleared on tab close) if a durable secret is not required.\n  See THREAT-MODEL.md \u00a76b N7.'));
}

// ── SRI audit ────────────────────────────────────────────────────────────────
// Only these are SRI algorithms. A browser rejects anything else outright, so
// "verifying" an md5- or sha1- pin would certify a resource the browser will
// refuse to load; an unknown name used to reach crypto.createHash() and abort
// the whole audit mid-run with an OpenSSL error (and exit 0).
const SRI_ALGOS = ['sha256', 'sha384', 'sha512'];
const SRI_STRENGTH = { sha256: 1, sha384: 2, sha512: 3 };
function parseIntegrity(v) {
  const good = [], bad = [];
  for (const tk of String(v).trim().split(/\s+/).filter(Boolean)) {
    const m = /^(sha256|sha384|sha512)-([A-Za-z0-9+/\-_]+={0,2})(?:\?[\x21-\x7e]*)?$/.exec(tk);
    if (m) good.push({ algo: m[1], b64: m[2].replace(/-/g, '+').replace(/_/g, '/') });
    else bad.push(tk);
  }
  return { good, bad };
}
const isRemoteSrc = (s) => /^https?:\/\//i.test(s) || /^\/\//.test(s);   // "//host" is remote too

// Find external subresources with the same masking tag scanner the handler
// converter uses. The old pair of regexes required QUOTED attribute values and
// could not cross a '>' inside an earlier attribute, so
//   <script src=https://cdn/x.js>
//   <script data-n="a > b" src="https://cdn/y.js">
//   <link rel=stylesheet href=https://cdn/z.css>
// were all invisible — and a page whose only external resource was one of them
// audited as "✓ fully self-contained". It also matched <script src> written
// inside comments and JS strings, which the mask now excludes.
function externalSubresources(html) {
  const masked = maskNonMarkup(html);
  const out = [];
  for (const t of scanTags(masked)) {
    const name = t.tag.toLowerCase();
    if (name !== 'script' && name !== 'link') continue;
    const at = (n) => {
      const a = t.attrs.find((x) => x.name.toLowerCase() === n);
      if (!a) return null;
      return a.valStart >= 0 ? html.slice(a.valStart, a.valEnd) : '';
    };
    const common = { integrity: at('integrity'), crossorigin: at('crossorigin'), tagText: html.slice(t.index, t.end) };
    if (name === 'script') {
      const src = at('src');
      if (src) out.push(Object.assign({ kind: 'script', src }, common));
    } else {
      const rel = (at('rel') || '').toLowerCase().split(/\s+/).filter(Boolean);
      const href = at('href');
      if (!href) continue;
      if (rel.includes('stylesheet')) out.push(Object.assign({ kind: 'stylesheet', src: href }, common));
      else if (rel.includes('modulepreload') || (rel.includes('preload') && /\bas\s*=\s*["']?(script|style)/i.test(common.tagText))) {
        out.push(Object.assign({ kind: 'preload(' + rel.join(' ') + ')', src: href }, common));
      }
    }
  }
  return out;
}

function cmdAuditSri(file) {
  const html = fs.readFileSync(file, 'utf8');
  const dir = path.dirname(file);
  const tags = externalSubresources(html);
  console.log("\n  0html SUBRESOURCE INTEGRITY AUDIT - " + path.basename(file));
  if (!tags.length) { console.log(G("  \u2713 no external <script>/<link> \u2014 fully self-contained (nothing to SRI-pin)")); return; }
  let gaps = 0;
  for (const t of tags) {
    const remote = isRemoteSrc(t.src);
    if (t.integrity == null || t.integrity === '') {
      gaps++;
      console.log(R("  \u26a0 " + t.kind + "  " + t.src + "  \u2014 NO integrity (a tampered " + (remote ? "CDN resource" : "file") + " runs with full privileges, even under a strict CSP)"));
      continue;
    }
    const { good, bad } = parseIntegrity(t.integrity);
    if (bad.length) {
      gaps++;
      console.log(R("  \u2717 " + t.kind + "  " + t.src + "  \u2014 NOT a valid SRI hash: " + bad.join(' ') + "  (browsers accept only " + SRI_ALGOS.join('/') + " \u2014 this resource will be BLOCKED)"));
      if (!good.length) continue;
    }
    // A cross-origin fetch carrying integrity but no crossorigin attribute is
    // made in no-cors mode; the response is opaque, the check cannot run, and
    // the browser blocks the resource. Present-but-useless, so say so.
    if (remote && t.crossorigin == null) {
      gaps++;
      console.log(R("  \u2717 " + t.kind + "  " + t.src + "  \u2014 integrity present but no crossorigin attribute; the fetch is no-cors, so SRI cannot be checked and the browser BLOCKS it. Add crossorigin=\"anonymous\"."));
    }
    // Browsers use the strongest algorithm present and require a match against
    // one of that algorithm's hashes. Multiple hashes are valid SRI — the old
    // whole-string compare reported a correctly pinned file as a MISMATCH.
    const strongest = good.reduce((a, g) => (SRI_STRENGTH[g.algo] > SRI_STRENGTH[a] ? g.algo : a), 'sha256');
    const candidates = good.filter((g) => g.algo === strongest);
    const local = path.join(dir, t.src.replace(/^\.\//, ''));
    if (!remote && fs.existsSync(local) && fs.statSync(local).isFile()) {
      const actual = crypto.createHash(strongest).update(fs.readFileSync(local)).digest('base64');
      if (candidates.some((c) => c.b64 === actual)) {
        console.log(G("  \u2713 " + t.kind + "  " + t.src + "  \u2014 SRI verified (" + strongest + (candidates.length > 1 ? ", " + candidates.length + " hashes declared" : "") + ")"));
      } else {
        gaps++;
        console.log(R("  \u2717 " + t.kind + "  " + t.src + "  \u2014 SRI MISMATCH: declared " + candidates.map((c) => c.b64.slice(0, 12) + "\u2026").join(' ') + "  actual " + actual.slice(0, 12) + "\u2026"));
      }
    } else if (!bad.length && !(remote && t.crossorigin == null)) {
      console.log(D("  \u2022 " + t.kind + "  " + t.src + "  \u2014 SRI present, " + strongest + " (" + (remote ? "remote" : "file not alongside") + "; not verifiable here)"));
    }
  }
  if (gaps) console.log(D("\n  Add integrity to external <script>/<link>. Local file hash:  openssl dgst -sha384 -binary FILE | openssl base64 -A"));
  process.exitCode = gaps ? 1 : 0;
}

// ── main ─────────────────────────────────────────────────────────────────────
function parseArgs(argv) {
  const a = { _: [] };
  for (const t of argv) {
    const m = t.match(/^--([^=]+)=(.*)$/);
    if (m) a[m[1]] = m[2]; else if (t.startsWith('--')) a[t.slice(2)] = true; else a._.push(t);
  }
  return a;
}
(function main() {
  const [cmd, ...rest] = process.argv.slice(2);
  const arg = parseArgs(rest);
  const file = arg._[0];
  try {
    if (cmd === 'layers' && file) return cmdLayers(file);
    if (cmd === 'apply' && file) return cmdApply(file, arg);
    if (cmd === 'unapply' && file) return cmdUnapply(file, arg);
    if (cmd === 'verify' && file) return cmdVerify(file);
    if (cmd === 'conformance' && file) return cmdConformance(file, arg);
    if (cmd === 'update' && file) return cmdUpdate(file);
    if (cmd === 'audit-secrets' && file) return cmdAuditSecrets(file);
    if (cmd === 'audit-sri' && file) return cmdAuditSri(file);
    if (cmd === 'convert-handlers' && file) return cmdConvertHandlers(file);
    if (cmd === 'restore-handlers' && file) return cmdRestoreHandlers(file);
    console.log('usage: 0html-layers.cjs <layers|apply|unapply|verify|conformance|update|audit-secrets|audit-sri> <file.html> [--layers=1,3 | --tier=recommended | --layer=1 | --json]');
    process.exit(2);
  } catch (e) { console.error(R('  error: ' + e.message)); process.exit(1); }
})();
