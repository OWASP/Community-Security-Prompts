# 0ui — Security Review: Before vs. After 0html

A concrete, honest comparison of the 0ui app's security posture before and after the
0html layered hardening (recommended tier: L1 + L2 + L3, plus handler conversion),
grounded in the actual built artifacts.

---

## 1. The concrete change (CSP diff)

**Before** (`0ui.html` template CSP):
```
default-src 'none'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline';
connect-src *; img-src 'self' data: blob:; font-src 'self'; manifest-src 'self';
frame-src 'none'; object-src 'none'; base-uri 'self'; form-action 'none'
```

**After** (built, hardened `dist/0ui.html`):
```
default-src 'none';
script-src 'self' 'sha256-…'×4          ← 'unsafe-inline' REMOVED, 4 script hashes added
style-src 'self' 'unsafe-inline'; connect-src *; img-src 'self' data: blob:;
font-src 'self'; manifest-src 'self'; frame-src 'none'; object-src 'none';
base-uri 'self'; form-action 'none';
frame-ancestors 'none'                   ← ADDED
+ Content-Security-Policy-Report-Only: require-trusted-types-for 'script'   ← ADDED
```
Plus: **9 inline `onsubmit="return false"` handlers → `addEventListener`** (with
`return false` → `preventDefault`, faithful).

Four concrete deltas: `'unsafe-inline'` gone from `script-src` (4 hashes instead);
`frame-ancestors 'none'` added; a Trusted-Types **report-only** meta added; inline
handlers converted.

---

## 2. Baseline — the app was already well-defended

Before 0html, 0ui already had `default-src 'none'`, `object-src 'none'`, `base-uri
'self'`, `form-action 'none'`, `frame-src 'none'`, `htmlEsc` escaping across 12 modules,
an input shield, and **zero genuine unescaped `innerHTML` sinks** (all 41 escaped or
numeric — the single flagged one, `${targets.length}`/`${turnId}`, is a numeric false
positive). This is a **HARDEN-ONLY** case: 0html adds defense-in-depth; it does **not**
patch a live hole, because there wasn't an obvious one.

---

## 3. Per-threat analysis

| # | Threat | Before | After | Δ |
|---|---|---|---|---|
| T1 | **Clickjacking** (app framed by a hostile page) | possible — no `frame-ancestors` | **blocked** — `frame-ancestors 'none'` | ✅ real |
| T2 | **Injected inline `<script>` executing** (if a sink regressed) | would run — `'unsafe-inline'` | **blocked** — hash-pinned `script-src`; a non-matching inline script is refused | ✅ real |
| T3 | **Injected inline `on*` handler** | would run — `'unsafe-inline'` | **blocked** — no `'unsafe-inline'`; handlers converted | ✅ real |
| T4 | **DOM XSS via `innerHTML`** | mitigated by escaping; a *future* unescaped sink + `'unsafe-inline'` = XSS | same escaping **+** `'unsafe-inline'` removed (injected script won't run) **+** TT report-only surfaces sinks | ✅ defense-in-depth |
| T5 | **App/bundle tampering** (own integrity) | `combine.sh` builds; no integrity gate | **conformance gate** — hash-pin + tamper-evident `sha256`; build fails on drift | ✅ real |
| T6 | **Data exfiltration to arbitrary host** | `connect-src *` | `connect-src *` — unchanged | ⬜ residual |
| T7 | **Secret exposure** (provider keys) | `localStorage`, readable by any script | `localStorage` — unchanged (advisory) | ⬜ residual |
| T8 | **CSS injection / CSS exfil** | `style-src 'unsafe-inline'` | `style-src 'unsafe-inline'` — L8 blocked by 84 inline `style=` attrs | ⬜ residual |
| T9 | **Plugin / base-tag / form exfil** | already blocked (`object-src`/`base-uri`/`form-action`) | same | = already covered |
| T10 | **Platform DOM-XSS block (TT enforce)** | none | report-only only (diagnostic) — **not enforce yet** | ◐ staged |

---

## 4. What 0html changed, honestly

**Real improvements (3):**
- **T1 clickjacking closed** — `frame-ancestors 'none'`.
- **T2/T3 inline injection blocked** — `'unsafe-inline'` removed, scripts hash-pinned,
  handlers converted. This is the one *genuine CSP weakness* 0ui had, now closed.
- **T5 build-time integrity** — the security posture is a gated, tamper-evident build
  invariant; a drift (or a forgotten re-pin) fails the build.

**Defense-in-depth (1):**
- **T4 DOM XSS** — the escaping was already solid; 0html adds the platform-level backstop
  for a *future* escaping regression (an injected script can't run) plus a TT diagnostic.

**Unchanged residuals (3) — architectural, out of a CSP's reach here:**
- **T6 exfiltration** — `connect-src *` stays, because 0ui reaches user-configured LLM
  endpoints (can't be statically scoped). This is 0ui's largest residual.
- **T7 secret exposure** — keys in `localStorage`; a browser-only app can't isolate a key
  any script can read.
- **T8 CSS injection** — `style-src 'unsafe-inline'` stays until the 84 inline `style=`
  attributes move to `<style>`/classes.

**Staged (1):**
- **T10** — Trusted Types is report-only (a diagnostic that surfaces sinks), not enforce;
  a platform DOM-XSS block would need sink routing + a browser verification pass.

---

## 5. The honest bottom line

0ui was already strongly defended by its escaping, shield, and CSP. 0html's *measurable*
value here is: **(1)** it closes the one real CSP weakness — `'unsafe-inline'`; **(2)** it
adds clickjacking protection; **(3)** it turns the security posture into a maintainable,
tamper-evident, gated build invariant; and **(4)** it stages Trusted Types.

It does **not** move the app's biggest residuals — exfiltration (`connect-src *`) and
secret storage — which are architectural and largely outside what a CSP can do for an app
that talks to arbitrary user endpoints and holds keys client-side.

Net: a real **defense-in-depth upgrade and a security floor you can maintain**, not a
transformation from insecure to secure — because it wasn't insecure to begin with. The
honest framing matters: over-claiming "now hardened with Trusted Types" would invite
misplaced trust, when the accurate statement is "the injectable-inline weakness is closed,
clickjacking is blocked, the posture is gated, and the exfil/secret residuals remain."

**Before shipping:** the hardening is structurally verified (valid wiring, valid CSP,
matching hashes, green conformance) but **runtime behaviour needs a browser pass** — the
converted forms cancelling submission, the app loading clean without `'unsafe-inline'`, and
TT report-only surfacing correctly.
