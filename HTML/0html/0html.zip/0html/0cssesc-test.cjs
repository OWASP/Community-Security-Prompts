// 0cssesc-test.cjs — regression locks for the v1.8.1 review findings.
//   I5a  CSS escapes inside url()          (\2f\2f evil → //evil, exfil)
//   I5b  CSS escapes around the url token  (\75 rl( → url()
//   J14  preset + partial policy override must not drop the preset's mode
//   J15  advise() must see the top-level `id` shorthand build() honours
//   I6b  className must obey the single-value length cap
// Zero-dep, in-file DOM shim (same shape as the other suites).
// Run: node 0cssesc-test.cjs
'use strict';

// ── DOM shim ───────────────────────────────────────────────────
class Node {
  constructor() { this.childNodes = []; this.nodeType = 1; }
  appendChild(c) {
    if (c instanceof DocumentFragment) { for (const k of c.childNodes.slice()) this.appendChild(k); return c; }
    c.parentNode = this; this.childNodes.push(c); return c;
  }
  get textContent() { return this.childNodes.map(c => c.textContent ?? '').join(''); }
  set textContent(v) { this.childNodes = []; if (v !== '') this.appendChild(new TextNode(String(v))); }
}
class TextNode { constructor(d) { this.data = String(d); this.nodeType = 3; } get textContent() { return this.data; } }
class Element extends Node {
  constructor(tag, ns) { super(); this.tagName = String(tag).toLowerCase(); this.namespaceURI = ns || null; this._attrs = {}; this.dataset = {}; }
  setAttribute(k, v) { this._attrs[k] = String(v); }
  setAttributeNS(ns, k, v) { this._attrs[`${ns}|${k}`] = String(v); }
  getAttribute(k) { return this._attrs[k]; }
  hasAttribute(k) { return Object.prototype.hasOwnProperty.call(this._attrs, k); }
  set id(v) { this._attrs.id = v; } get id() { return this._attrs.id; }
  set className(v) { this._attrs.class = v; } get className() { return this._attrs.class || ''; }
  addEventListener() {}
}
class Template extends Element {
  constructor() { super('template'); this.content = new DocumentFragment(); }
  set innerHTML(h) { const s = new Element('span'); s.appendChild(new TextNode('[[RAW]]')); this.content.appendChild(s); }
}
class DocumentFragment extends Node { constructor() { super(); this.nodeType = 11; } }
global.document = {
  createElement: (t) => t === 'template' ? new Template() : new Element(t),
  createElementNS: (ns, t) => new Element(t, ns),
  createTextNode: (d) => new TextNode(d),
  createDocumentFragment: () => new DocumentFragment(),
  body: new Element('body'), addEventListener: () => {},
};
global.Node = Node;
global.window = { addEventListener: () => {} };

const fs = require('fs'), os = require('os'), pathm = require('path');
const toCjs = (n) => { const p = pathm.join(os.tmpdir(), `cssesc-${n}-${process.pid}.cjs`); fs.writeFileSync(p, fs.readFileSync(pathm.join(__dirname, `${n}.js`), 'utf8')); return p; };
global.OUI_BIND = require(toCjs('0bind'));
const html0 = require(toCjs('0html'));
const bind = global.OUI_BIND;

let pass = 0, fail = 0;
const ok = (n, c) => { const g = !!c; console.log(`${g ? '✓' : '✗ FAIL'} ${n}`); g ? pass++ : fail++; };
const quiet = (fn) => { const o = console.warn; console.warn = () => {}; try { return fn(); } finally { console.warn = o; } };
const styleOf = (css) => quiet(() => bind.el('div', { style: css })._attrs.style);

// ═══ I5a — CSS escapes inside url() ═════════════════════════════
// The CSS parser unescapes \2f to "/", so these resolve to //evil.example.
// The old fold ("\" → "/") made them read as innocent rooted paths.
console.log('\n── I5a: escaped URL characters inside url() ──');
ok('url(\\2f\\2f host) refused',        styleOf('background-image:url(\\2f\\2f evil.example/beacon)') === undefined);
ok('url("\\2f\\2f host") refused',      styleOf('background:url("\\2f\\2f evil.example/b")') === undefined);
ok("url('\\2f\\2f host') refused",      styleOf("background:url('\\2f\\2f evil.example/b')") === undefined);
ok('url(\\6a avascript:) refused',      styleOf('background-image:url(\\6a avascript:alert(1))') === undefined);
ok('uppercase \\2F refused',            styleOf('background:url(\\2F\\2F evil.example/b)') === undefined);
ok('6-digit \\00002f refused',          styleOf('background:url(\\00002f\\00002f evil.example/b)') === undefined);
ok('isCssUrlSafe rejects any backslash', bind.isCssUrlSafe ? bind.isCssUrlSafe('\\2f\\2f evil.example') === false : true);

// ═══ I5b — escapes around the url token itself ══════════════════
// "\75 rl(" tokenizes as url( — the raw-text scan found no url() to gate.
console.log('\n── I5b: escaped url-token ──');
ok('\\75 rl(//host) refused',           styleOf('background-image:\\75 rl(//evil.example/beacon)') === undefined);
ok('UR\\4C ( refused',                  styleOf('background-image:UR\\4C (//evil.example/b)') === undefined);
ok('\\75\\72\\6c( refused',             styleOf('background-image:\\75\\72\\6c(//evil.example/b)') === undefined);
ok('escaped expression() refused',      styleOf('width:expr\\65 ssion(alert(1))') === undefined);

// ═══ positive controls — benign CSS still survives ══════════════
console.log('\n── positive controls ──');
ok('plain declaration kept',            styleOf('color:red;font-weight:bold') === 'color:red;font-weight:bold');
ok('relative url() kept',               styleOf('background-image:url(/img/a.png)') !== undefined);
ok('fragment url() kept',               styleOf('clip-path:url(#c)') !== undefined);
ok('data:image/png kept',               styleOf('background:url(data:image/png;base64,iVBORw0KGgo=)') !== undefined);
ok('escaped content string kept',       styleOf('content:"\\201C"') === 'content:"\\201C"');
ok('comment-only style kept',           styleOf('color:red/*x*/') !== undefined);

// ═══ SVG paint refs use the same gate ═══════════════════════════
console.log('\n── SVG paint refs ──');
{
  const bad = quiet(() => html0.compile({ tag: 'circle', attrs: { fill: 'url(\\2f\\2f evil.example/x.svg#g)' } }, { svg: true }));
  ok('svg fill escaped url() refused',  bad._attrs.fill === undefined);
  const good = quiet(() => html0.compile({ tag: 'circle', attrs: { fill: 'url(#grad)' } }, { svg: true }));
  ok('svg fill url(#grad) kept',        good._attrs.fill === 'url(#grad)');

  // I5c: svgPaintSafe carried its OWN, weaker scanner — a literal /url\(/ test
  // that returned "safe" whenever it found no match, and no hard-ban check at
  // all. So the I5b hardening of sanitizeStyle did not reach the paint path.
  // Found by the extended fuzzer, not by hand.
  const paint = (v, attr = 'fill') => quiet(() =>
    html0.compile({ tag: 'circle', attrs: { [attr]: v } }, { svg: true }))._attrs[attr];
  ok('svg fill escaped url-token refused',  paint('background-image:\\75 rl(//evil.example/b)') === undefined);
  ok('svg fill UR\\4C ( refused',           paint('background-image:UR\\4C (//evil.example/b)') === undefined);
  ok('svg fill plain //host refused',       paint('url(//evil.example/b)') === undefined);
  ok('svg fill javascript: refused',        paint('url(javascript:alert(1))') === undefined);
  ok('svg fill escaped expression refused', paint('width:expr\\65 ssion(alert(1))') === undefined);
  ok('svg filter escaped url refused',      paint('\\75 rl(//evil.example/f)', 'filter') === undefined);
  ok('svg clip-path escaped url refused',   paint('\\75 rl(//evil.example/c)', 'clip-path') === undefined);
  ok('svg stroke plain colour kept',        paint('#333', 'stroke') === '#333');
  ok('svg fill named colour kept',          paint('rebeccapurple') === 'rebeccapurple');
  ok('svg filter url(#f) kept',             paint('url(#blur)', 'filter') === 'url(#blur)');
}

// ═══ J14 — preset must not be weakened by a partial override ════
console.log('\n── J14: preset + partial policy override ──');
{
  const spec = { tag: 'img', attrs: { src: 'https://evil.example/track.gif' } };
  const o = { preset: 'strict', urlPolicy: { base: 'https://app.example/', allowedOrigins: ['https://cdn.example'] } };
  const n = quiet(() => html0.compile(spec, o));
  ok('off-origin src still refused',    n._attrs.src === undefined);

  const cdn = { tag: 'img', attrs: { src: 'https://cdn.example/logo.png' } };
  const n2 = quiet(() => html0.compile(cdn, o));
  ok('allow-listed origin still kept',  n2._attrs.src === 'https://cdn.example/logo.png');

  const n3 = quiet(() => html0.compile({ tag: 'div', attrs: { id: 'location' } }, { preset: 'strict', idPolicy: { prefix: 'app-' } }));
  ok('strict id refusal survives prefix override', n3._attrs.id === undefined);

  const n4 = quiet(() => html0.compile({ tag: 'div', attrs: { id: 'panel' } }, { preset: 'strict', idPolicy: { prefix: 'app-' } }));
  ok('custom prefix still applied',     n4._attrs.id === 'app-panel');

  const n5 = quiet(() => html0.compile({ tag: 'div', attrs: { id: 'location' } }, { preset: 'strict', idPolicy: { mode: 'off' } }));
  ok('explicit mode override still wins', n5._attrs.id === 'location');
}

// ═══ J15 — advise() sees the `id` shorthand ═════════════════════
console.log('\n── J15: advise() vs the id shorthand ──');
{
  const r = html0.advise({ tag: 'div', id: 'location' });
  ok('shorthand id flagged high',       r.findings.some(f => f.policy === 'idPolicy' && f.severity === 'high'));
  const r2 = html0.advise({ tag: 'div', id: 'panel' });
  ok('benign shorthand id → namespace',  r2.findings.some(f => f.policy === 'idPolicy' && f.severity === 'low'));
  const r3 = html0.advise({ tag: 'div', children: [{ tag: 'span', id: 'cookie' }] });
  ok('nested shorthand id flagged',     r3.findings.some(f => f.severity === 'high'));
  const r4 = html0.advise({ tag: 'div', attrs: { id: 'panel' } }, { idPolicy: { mode: 'strict' } });
  ok('active policy still suppresses',  !r4.findings.some(f => f.policy === 'idPolicy'));
}

// ═══ I6b — className obeys the value cap ════════════════════════
console.log('\n── I6b: className value cap ──');
{
  const big = 'x'.repeat(600 * 1024);
  ok('over-long className dropped',     quiet(() => bind.el('div', { className: big })).className === '');
  ok('normal className kept',           quiet(() => bind.el('div', { className: 'a b' })).className === 'a b');
}

console.log('\n' + '─'.repeat(40));
console.log(`  ${pass} passed, ${fail} failed  (v1.8.1 review fixes)`);
console.log('─'.repeat(40));
process.exit(fail ? 1 : 0);
