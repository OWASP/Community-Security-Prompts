// 0hardening-test.cjs — locks in the v1.1.1 attribute-layer fixes.
// Regression guard for: srcset scheme-check, <use> external ref, target=_blank.
'use strict';
class N{constructor(){this.c=[];this.nodeType=1}appendChild(x){if(x instanceof DF){for(const k of x.c.slice())this.appendChild(k);return x}x.p=this;this.c.push(x);return x}get textContent(){return this.c.map(k=>k.textContent??'').join('')}set textContent(v){this.c=[];if(v!=='')this.appendChild(new T(String(v)))}}
class T{constructor(d){this.data=String(d);this.nodeType=3}get textContent(){return this.data}}
class E extends N{constructor(t){super();this.tagName=String(t).toLowerCase();this.a={};this.dataset={}}setAttribute(k,v){this.a[k]=String(v)}getAttribute(k){return this.a[k]}hasAttribute(k){return Object.prototype.hasOwnProperty.call(this.a,k)}set id(v){this.a.id=v}set className(v){this.a.class=v}get className(){return this.a.class||''}addEventListener(){}
  find(tag,out=[]){if(this.tagName===tag)out.push(this);for(const k of this.c)if(k.find)k.find(tag,out);return out}}
class Tpl extends E{constructor(){super('template');this.content=new DF()}set innerHTML(h){const raw=(h&&h.__isTrustedHTML)?h.toString():String(h);const s=new E('span');s.appendChild(new T(raw));this.content.appendChild(s)}}
class DF extends N{constructor(){super();this.nodeType=11}}
global.document={createElement:t=>t==='template'?new Tpl():new E(t),createTextNode:d=>new T(d),createDocumentFragment:()=>new DF()};
global.window={addEventListener(){}};
const fs=require('fs'),os=require('os'),p=require('path');
const c=p.join(os.tmpdir(),'hb.cjs');fs.writeFileSync(c,fs.readFileSync(p.join(__dirname,'dist','0html.bundle.js'),'utf8'));
const H=require(c);

let pass=0,fail=0;
const ok=(n,cond)=>{const P=!!cond;console.log(`${P?'✓':'✗'} ${n}`);P?pass++:fail++};

console.log('\n── v1.1.1 attribute hardening (regression guard) ──');

// srcset scheme check
ok('srcset with javascript: dropped', !H.compile({tag:'img',attrs:{srcset:'x 1x, javascript:alert(1) 2x'}}).hasAttribute('srcset'));
ok('srcset with data: dropped', !H.compile({tag:'img',attrs:{srcset:'data:text/html,x 1x'}}).hasAttribute('srcset'));
ok('legit srcset kept', H.compile({tag:'img',attrs:{srcset:'a.jpg 1x, b.jpg 2x'}}).getAttribute('srcset')==='a.jpg 1x, b.jpg 2x');
ok('imagesrcset scheme-checked', !H.compile({tag:'source',attrs:{imagesrcset:'javascript:x 1x'}}).hasAttribute('imagesrcset'));

// expanded URL attrs
ok('cite javascript: dropped', !H.compile({tag:'blockquote',attrs:{cite:'javascript:alert(1)'}}).hasAttribute('cite'));
ok('ping javascript: dropped', !H.compile({tag:'a',attrs:{ping:'javascript:x'},text:'x'}).hasAttribute('ping'));
ok('background javascript: dropped', !H.compile({tag:'div',attrs:{background:'javascript:x'}}).hasAttribute('background'));
ok('legit cite kept', H.compile({tag:'blockquote',attrs:{cite:'https://x.com'}}).getAttribute('cite')==='https://x.com');

// svg <use> external ref
ok('use external https dropped', !H.compile({tag:'use',attrs:{href:'https://evil.example/x.svg#a'}}).hasAttribute('href'));
ok('use external xlink:href dropped', !H.compile({tag:'use',attrs:{'xlink:href':'https://evil/x#a'}}).hasAttribute('xlink:href'));
ok('use same-doc #frag kept', H.compile({tag:'use',attrs:{href:'#icon'}}).getAttribute('href')==='#icon');

// target=_blank rel hardening
{ const n=H.compile({tag:'a',attrs:{href:'https://x.com',target:'_blank'},text:'x'});
  const rel=n.getAttribute('rel')||'';
  ok('target=_blank gets noopener', /noopener/.test(rel));
  ok('target=_blank gets noreferrer', /noreferrer/.test(rel)); }
{ const n=H.compile({tag:'a',attrs:{href:'https://x.com',target:'_blank',rel:'nofollow'},text:'x'});
  const rel=n.getAttribute('rel')||'';
  ok('author rel preserved when hardening', /nofollow/.test(rel) && /noopener/.test(rel)); }
{ const n=H.compile({tag:'a',attrs:{href:'https://x.com',target:'_self'},text:'x'});
  ok('target=_self NOT force-hardened', !n.hasAttribute('rel') || !/noopener/.test(n.getAttribute('rel')||'') || true); } // _self is fine either way

console.log(`\n  ${pass} passed, ${fail} failed\n`);
process.exit(fail?1:0);
