// 0svg-test.cjs — safe SVG rendering (I9 / J13, opt-in).
// Namespaced DOM shim + heavy adversarial section. Run: node 0svg-test.cjs
'use strict';
const SVG_NS = 'http://www.w3.org/2000/svg';

class Node { constructor(){ this.childNodes=[]; this.nodeType=1; }
  appendChild(c){ if(c instanceof DocumentFragment){for(const k of c.childNodes.slice())this.appendChild(k);return c;} c.parentNode=this; this.childNodes.push(c); return c; }
  get textContent(){ return this.childNodes.map(c=>c.textContent??'').join(''); }
  set textContent(v){ this.childNodes=[]; if(v!=='')this.appendChild(new TextNode(String(v))); } }
class TextNode{ constructor(d){ this.data=String(d); this.nodeType=3; } get textContent(){ return this.data; } }
class Element extends Node { constructor(tag, ns){ super(); this.tagName=String(tag).toLowerCase(); this.namespaceURI=ns||null; this._attrs={}; this._attrsNS={}; this.dataset={}; }
  setAttribute(k,v){ this._attrs[k]=String(v); if(k.startsWith('data-')){const c=k.slice(5).replace(/-([a-z])/g,(_,x)=>x.toUpperCase());this.dataset[c]=String(v);} }
  setAttributeNS(ns,k,v){ this._attrs[k]=String(v); this._attrsNS[k]=ns; }
  getAttribute(k){ return this._attrs[k]; } hasAttribute(k){ return Object.prototype.hasOwnProperty.call(this._attrs,k); }
  set id(v){ this._attrs.id=v; } get id(){ return this._attrs.id; }
  set className(v){ this._attrs.class=v; } get className(){ return this._attrs.class||''; } addEventListener(){} }
class Template extends Element { constructor(){ super('template'); this.content=new DocumentFragment(); } set innerHTML(h){ const s=new Element('span'); s.appendChild(new TextNode('[[RAW]]')); this.content.appendChild(s); } }
class DocumentFragment extends Node { constructor(){ super(); this.nodeType=11; } }
const document={
  createElement:(t)=>t==='template'?new Template():new Element(t, null),
  createElementNS:(ns,t)=> new Element(t, ns),
  createTextNode:(d)=>new TextNode(d), createDocumentFragment:()=>new DocumentFragment(),
  body:new Element('body'), addEventListener:()=>{} };
global.document=document; global.Node=Node; global.window={ addEventListener:()=>{} };

const fs=require('fs'), os=require('os'), pathm=require('path');
const toCjs=(n)=>{const p=pathm.join(os.tmpdir(),`svg-${n}-${process.pid}.cjs`); fs.writeFileSync(p, fs.readFileSync(pathm.join(__dirname,`${n}.js`),'utf8')); return p;};
global.OUI_BIND=require(toCjs('0bind'));
const html0=require(toCjs('0html'));

let pass=0, fail=0;
const ok=(n,c)=>{const g=!!c; console.log(`${g?'✓':'✗ FAIL'} ${n}`); g?pass++:fail++;};
const SVG={ svg:true };
// walk helper: collect all element nodes (incl. root)
const walk=(n,out=[])=>{ if(n&&n.nodeType===1){out.push(n); (n.childNodes||[]).forEach(c=>walk(c,out));} return out; };
const kid=(n,tag)=> (n.childNodes||[]).find(c=>c.tagName===tag);

// ═══════════════════════════════════════════════════════════════
console.log('\n── svg OFF (default): tags stay inert, extras refused ──');
{
  const off = html0.compile({ tag:'svg', attrs:{viewBox:'0 0 10 10'}, children:[{tag:'circle',attrs:{cx:'5'}}] });
  ok('svg root NOT in SVG namespace when off', off.namespaceURI !== SVG_NS);
  const ell = html0.compile({ tag:'ellipse', attrs:{cx:'5'} });   // not in ALLOWED_TAGS
  ok('new svg-only tag (ellipse) refused when off', ell.tagName==='span' && ell._attrs['data-0html-refused']==='ellipse');
}

console.log('\n── svg ON: renders in the SVG namespace ──');
{
  const s = html0.compile({ tag:'svg', attrs:{ viewBox:'0 0 100 100', width:'100', height:'100' }, children:[
    { tag:'circle', attrs:{ cx:'50', cy:'50', r:'40', fill:'red', stroke:'blue' } },
    { tag:'path', attrs:{ d:'M10 10 H 90 V 90 H 10 Z' } },
    { tag:'g', attrs:{ transform:'translate(5,5)' }, children:[{ tag:'rect', attrs:{ x:'0', y:'0', width:'10', height:'10' } }] },
    { tag:'ellipse', attrs:{ cx:'50', cy:'50', rx:'20', ry:'10' } },
    { tag:'text', attrs:{ x:'10', y:'20', 'text-anchor':'middle' }, children:[{ tag:'tspan', attrs:{ dx:'2' }, text:'hi' }] },
    { tag:'use', attrs:{ href:'#icon' } },
  ]}, SVG);
  ok('svg root in SVG namespace', s.namespaceURI === SVG_NS);
  ok('viewBox case preserved', s._attrs.viewBox === '0 0 100 100');
  const c = kid(s,'circle');
  ok('circle in SVG namespace with geometry+paint', c.namespaceURI===SVG_NS && c._attrs.cx==='50' && c._attrs.fill==='red' && c._attrs.stroke==='blue');
  ok('path d set', kid(s,'path')._attrs.d.startsWith('M10 10'));
  const g = kid(s,'g');
  ok('g transform set and nested rect namespaced', g._attrs.transform==='translate(5,5)' && kid(g,'rect').namespaceURI===SVG_NS);
  ok('ellipse renders when svg on', kid(s,'ellipse').namespaceURI===SVG_NS);
  const t = kid(s,'text');
  ok('text + nested tspan namespaced', t.namespaceURI===SVG_NS && kid(t,'tspan').namespaceURI===SVG_NS && kid(t,'tspan').textContent==='hi');
  ok('use href="#icon" kept', kid(s,'use')._attrs.href==='#icon');
}

console.log('\n── attribute allowlist ──');
{
  const c = html0.compile({ tag:'circle', attrs:{ cx:'5', foobar:'x', 'data-evil':'y' } }, SVG);
  ok('allowlisted attr (cx) kept', c._attrs.cx==='5');
  ok('non-allowlisted SVG attr (foobar) dropped', c._attrs.foobar===undefined);
  ok('data-* dropped in SVG (not on allowlist)', c._attrs['data-evil']===undefined);
}

console.log('\n══ ADVERSARIAL (svg ON) ══');
{
  // dangerous ELEMENTS must be refused (not in the SVG allowlist)
  for (const t of ['animate','animateTransform','set','foreignObject','script','style','image']) {
    const n = html0.compile({ tag:'svg', children:[{ tag:t, attrs:{} }] }, SVG);
    const bad = walk(n).some(e => e.tagName===t.toLowerCase() && e.namespaceURI===SVG_NS);
    ok(`<${t}> not rendered as an SVG element`, !bad);
  }
  // animate trying SMIL mXSS: attributeName=href to=javascript: — element refused outright
  const anim = html0.compile({ tag:'svg', children:[{ tag:'animate', attrs:{ attributeName:'href', to:'javascript:alert(1)' } }] }, SVG);
  ok('SMIL <animate> href→javascript refused', !walk(anim).some(e=>e.tagName==='animate' && e.namespaceURI===SVG_NS));

  // on* handlers refused
  const onl = html0.compile({ tag:'circle', attrs:{ onload:'alert(1)', onclick:'x' } }, SVG);
  ok('onload refused on SVG element', onl._attrs.onload===undefined && onl._attrs.onclick===undefined);

  // <use> href restrictions
  ok('<use> external svg document refused', html0.compile({tag:'use',attrs:{href:'https://evil.example/s.svg#i'}}, SVG)._attrs.href===undefined);
  ok('<use> protocol-relative refused', html0.compile({tag:'use',attrs:{href:'//evil.example/s.svg#i'}}, SVG)._attrs.href===undefined);
  ok('<use> same-doc fragment allowed', html0.compile({tag:'use',attrs:{href:'#local'}}, SVG)._attrs.href==='#local');

  // xlink:href
  ok('xlink:href javascript refused', html0.compile({tag:'use',attrs:{'xlink:href':'javascript:alert(1)'}}, SVG)._attrs.href===undefined);
  {
    const u = html0.compile({tag:'use',attrs:{'xlink:href':'#icon'}}, SVG);
    ok('xlink:href="#icon" set via XLINK namespace', u._attrs.href==='#icon' && u._attrsNS.href==='http://www.w3.org/1999/xlink');
  }

  // paint url() references — same-origin/fragment only
  ok('fill=url(#grad) allowed', html0.compile({tag:'circle',attrs:{fill:'url(#grad)'}}, SVG)._attrs.fill==='url(#grad)');
  ok('fill=url(external) refused', html0.compile({tag:'circle',attrs:{fill:'url(https://evil.example/x)'}}, SVG)._attrs.fill===undefined);
  ok('fill=url(//host) refused', html0.compile({tag:'circle',attrs:{fill:'url(//evil.example/x)'}}, SVG)._attrs.fill===undefined);
  ok('filter=url(external) refused', html0.compile({tag:'rect',attrs:{filter:'url(https://evil.example/f)'}}, SVG)._attrs.filter===undefined);
  ok('plain fill color kept', html0.compile({tag:'rect',attrs:{fill:'#ff0000'}}, SVG)._attrs.fill==='#ff0000');

  // inline style on SVG still sanitized
  ok('style with external url refused on SVG', html0.compile({tag:'rect',attrs:{style:'fill:url(https://evil.example/x)'}}, SVG)._attrs.style===undefined);
  ok('benign style kept on SVG', html0.compile({tag:'rect',attrs:{style:'fill:blue;opacity:0.5'}}, SVG)._attrs.style==='fill:blue;opacity:0.5');

  // SVG <a> is NOT supported → falls through to HTML <a>, still scheme-gated
  const a = html0.compile({ tag:'svg', children:[{ tag:'a', attrs:{ href:'javascript:alert(1)' } }] }, SVG);
  const anchor = walk(a).find(e=>e.tagName==='a');
  ok('SVG <a> becomes HTML <a> (not SVG-namespaced)', anchor && anchor.namespaceURI!==SVG_NS);
  ok('that <a> still drops javascript: href', anchor && anchor._attrs.href===undefined);

  // global invariant: no script element anywhere, ever
  const nested = html0.compile({ tag:'svg', children:[
    { tag:'g', children:[ { tag:'script', text:'alert(1)' }, { tag:'foreignObject', children:[{tag:'div'}] } ] },
  ]}, SVG);
  ok('no <script> element rendered anywhere in the tree', !walk(nested).some(e=>e.tagName==='script'));
}

console.log('\n── composition with idPolicy + same-origin ──');
{
  const opts={ svg:true, idPolicy:{ mode:'namespace' }, urlPolicy:{ mode:'same-origin', base:'https://app.example.com/x' } };
  const s = html0.compile({ tag:'svg', attrs:{ id:'chart' }, children:[{ tag:'use', attrs:{ href:'#icon' } }] }, opts);
  ok('svg id prefixed by idPolicy', s._attrs.id==='0h-chart');
  ok('use href fragment prefixed + kept (same-origin)', kid(s,'use')._attrs.href==='#0h-icon');
}

console.log('\n══ FUZZ: random hostile SVG specs, no dangerous output ══');
{
  const DANGER_TAGS=['animate','animateTransform','set','foreignObject','script','style','image','iframe'];
  const DANGER_ATTRS=[['onload','x'],['onclick','x'],['href','javascript:alert(1)'],['xlink:href','javascript:alert(1)'],['fill','url(https://evil/x)'],['style','fill:url(https://evil/x)'],['foobar','x']];
  const OKTAGS=['svg','g','circle','rect','path','ellipse','use','text','tspan','defs','symbol'];
  const rnd=(a)=>a[Math.floor(Math.random()*a.length)];
  let violations=0;
  for (let i=0;i<600;i++){
    const useDanger = Math.random()<0.6;
    const tag = useDanger ? rnd(DANGER_TAGS) : rnd(OKTAGS);
    const attrs={}; const [ak,av]=rnd(DANGER_ATTRS); attrs[ak]=av; attrs.cx='5';
    const spec={ tag:'svg', children:[{ tag, attrs }] };
    const out = html0.compile(spec, SVG);
    for (const e of walk(out)){
      if (DANGER_TAGS.includes(e.tagName) && e.namespaceURI===SVG_NS) violations++;
      for (const [k,val] of Object.entries(e._attrs||{})){
        if (/^on/i.test(k)) violations++;
        if (/javascript:/i.test(val)) violations++;
        if (/url\(\s*['"]?\s*(https?:|\/\/)/i.test(val)) violations++;
      }
    }
  }
  ok('600 hostile SVG specs → zero dangerous elements/attrs/urls', violations===0);
}

console.log(`\n────────────────────────────────────────`);
console.log(`  ${pass} passed, ${fail} failed  (safe SVG, I9/J13)`);
console.log(`────────────────────────────────────────`);
process.exit(fail ? 1 : 0);
