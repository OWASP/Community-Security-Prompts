#!/usr/bin/env node
/*
  0tt-test.cjs — L3 / L4 Trusted Types detection.

  Both detectors did substring tests against raw text:

    detectTT        /require-trusted-types-for/i.test(reportOnly.content)
    detectTTEnforce /require-trusted-types-for/i.test(csp.content)
                    && /0html: default Trusted Types policy/.test(html)

  So a CSP carrying a bare `require-trusted-types-for` — invalid, ignored by
  every browser, since the directive takes exactly one value, 'script' — plus
  the shim marker sitting in an HTML COMMENT certified L3 ✓ and L4 ✓ with no
  policy registered anywhere in the document, and `--require=L3,L4` exited 0.
  L4 is the strongest layer in the stack.

  NOTE the default policy's `createHTML` passthrough is NOT a defect: it is a
  documented, deliberate choke-point design (WHAT-IT-DOES.md §5, THREAT-MODEL
  N7), which is why the fixed note says so rather than promising DOM-XSS
  immunity.
*/
'use strict';
const { execFileSync } = require('child_process');
const fs = require('fs'), os = require('os'), path = require('path');
const ENGINE = path.join(__dirname, '0html-layers.cjs');
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), '0tt-'));
let pass = 0, fail = 0;
const ck = (n, c) => c ? (pass++, console.log('  \u2713 ' + n)) : (fail++, console.log('  \u2717 FAIL ' + n));
function run(args) {
  try { return { out: execFileSync('node', [ENGINE, ...args], { encoding: 'utf8' }), code: 0 }; }
  catch (e) { return { out: (e.stdout || '') + (e.stderr || ''), code: e.status || 1 }; }
}
let n = 0;
const fx = (h) => { const p = path.join(TMP, 'f' + (++n) + '.html'); fs.writeFileSync(p, h); return p; };
const read = (p) => fs.readFileSync(p, 'utf8');
const CLAIM = `<!-- 0html-layers: {"L3":{"added":[]},"L4":{"added":[]}} -->`;
const doc = (head) => `<!doctype html><html><head>\n${head}\n</head><body><p>app</p></body></html>`;

console.log('\n-- a valueless directive is ignored by the browser --');
for (const [label, val] of [['bare', ''], ["'none'", " 'none'"], ["'style'", " 'style'"]]) {
  const f = fx(doc(
    `<meta http-equiv="Content-Security-Policy" content="default-src 'self'; require-trusted-types-for${val}">\n` +
    `<meta http-equiv="Content-Security-Policy-Report-Only" content="require-trusted-types-for${val}">\n` +
    `<script>/* 0html: default Trusted Types policy */window.trustedTypes&&window.trustedTypes.createPolicy('default',{createHTML:function(s){return s}});</script>\n` + CLAIM));
  ck(`require-trusted-types-for ${label} → L3 not satisfied`, /DRIFT|NON-CONFORMANT/.test(run(['conformance', f]).out));
  ck(`require-trusted-types-for ${label} → --require fails`, run(['conformance', f, '--require=L3,L4']).code !== 0);
}

console.log('\n-- the enforce shim must be a real <script>, not a mention --');
{
  const f = fx(doc(
    `<meta http-equiv="Content-Security-Policy" content="default-src 'self'; require-trusted-types-for 'script'">\n` +
    `<!-- 0html: default Trusted Types policy — just a comment -->\n` + CLAIM));
  ck('marker in a comment does not certify L4', /DRIFT/.test(run(['conformance', f]).out));
  ck('--require=L4 fails', run(['conformance', f, '--require=L4']).code !== 0);
  ck('no policy is actually registered', !/createPolicy/.test(read(f)));
}
{
  const f = fx(doc(
    `<meta http-equiv="Content-Security-Policy" content="default-src 'self'; require-trusted-types-for 'script'">\n` +
    `<script>var s = "0html: default Trusted Types policy";</script>\n` + CLAIM));
  ck('marker in a JS string does not certify L4', /DRIFT/.test(run(['conformance', f]).out));
}
{
  // directive without shim: every TT sink throws — that is a broken app, not conformance
  const f = fx(doc(`<meta http-equiv="Content-Security-Policy" content="default-src 'self'; require-trusted-types-for 'script'">\n` + CLAIM));
  const r = run(['layers', f]);
  ck('directive without a policy is reported, not "done"', /no default-policy|will throw/i.test(r.out));
}

console.log('\n-- apply repairs rather than rubber-stamps --');
{
  const f = fx(doc(`<meta http-equiv="Content-Security-Policy" content="default-src 'self'; require-trusted-types-for">`));
  const r = run(['apply', f, '--layers=4']);
  ck('valueless directive is repaired', /require-trusted-types-for 'script'/.test(read(f)));
  ck('and reported as repaired', /value repaired/.test(r.out));
  ck('shim registered', /createPolicy\('default'/.test(read(f)));
}

console.log('\n-- the real path --');
{
  const f = fx(doc(`<meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self' 'unsafe-inline'">`));
  run(['apply', f, '--layers=3,4']);
  const h = read(f);
  ck("enforce CSP carries 'script'", /Content-Security-Policy" content="[^"]*require-trusted-types-for 'script'/.test(h));
  ck('report-only meta added', /Content-Security-Policy-Report-Only/.test(h));
  ck('default policy registered', /createPolicy\('default'/.test(h));
  ck('conformance passes', run(['conformance', f]).code === 0);
  ck('--require=L3,L4 passes', run(['conformance', f, '--require=L3,L4']).code === 0);
  ck('note does not promise DOM-XSS immunity', /choke point, not sanitiser|choke point/i.test(run(['layers', f]).out));

  // remove the shim behind the tool's back → drift
  fs.writeFileSync(f, h.replace(/<script>\/\* 0html: default Trusted Types policy[\s\S]*?<\/script>/, ''));
  ck('stripping the shim is detected as drift', run(['conformance', f]).code !== 0);
}
{
  const f = fx(doc(`<meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self' 'unsafe-inline'">`));
  run(['apply', f, '--layers=4']);
  run(['unapply', f, '--layer=4']);
  const h = read(f);
  ck('unapply removes the shim', !/createPolicy\('default'/.test(h));
  // --layers=4 expands to L3,L4, so L3's report-only meta legitimately survives
  // an L4 reversal; what must go is the directive on the ENFORCE policy.
  const enforce = (h.match(/http-equiv="Content-Security-Policy"\s+content="([^"]*)"/) || [])[1] || '';
  ck('unapply removes the ENFORCE directive', !/require-trusted-types-for/.test(enforce));
  ck('and leaves L3 report-only intact', /Content-Security-Policy-Report-Only" content="[^"]*require-trusted-types-for 'script'/.test(h));
}

console.log('\n' + '-'.repeat(40));
console.log(`  ${pass} passed, ${fail} failed  (Trusted Types L3/L4)`);
console.log('-'.repeat(40));
try { fs.rmSync(TMP, { recursive: true, force: true }); } catch {}
process.exit(fail ? 1 : 0);
