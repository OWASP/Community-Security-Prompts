#!/usr/bin/env node
/* ╔═══════════════════════════════════════════════════════════════╗
   ║  0html-value.cjs — quantify the value of adopting 0html        ║
   ║  Measures a target HTML file and emits SECURITY / SPEED / SIZE ║
   ║  deltas so a developer sees WHY before approving.              ║
   ╚═══════════════════════════════════════════════════════════════╝

   USAGE
     node 0html-value.cjs <target.html>

   Emits a value report the agent shows in Phase 3 (Plan), before any
   approval gate. Numbers are measured from the file + the pinned bundle,
   not estimated.
*/
'use strict';
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

// The shared HTML scanner (see 0scan-html.cjs). This report used to detect with
// substring tests over the whole file, so a "Content-Security-Policy" mentioned
// in a comment counted as a CSP, `once="true"` counted as an inline handler, and
// a sink written inside a markup string counted as a sink. The numbers here feed
// a human's adoption decision, so they should be measured the same way the rest
// of the tooling measures.
const SCAN = require(path.join(__dirname, '0scan-html.cjs'));
const SELF = __dirname;
const file = process.argv[2];
if (!file) { console.error('usage: node 0html-value.cjs <target.html>'); process.exit(1); }
if (!fs.existsSync(file)) { console.error(`not found: ${file}`); process.exit(1); }

const html = fs.readFileSync(file, 'utf8');
const bytes = Buffer.byteLength(html);
const gz = (s) => zlib.gzipSync(Buffer.from(s)).length;

// locate the pinned bundle
function findBundle() {
  for (const c of [
    path.join(SELF, 'dist', '0html.bundle.js'),
    path.join(SELF, '0html.bundle.js'),
    path.join(process.cwd(), 'dist', '0html.bundle.js'),
  ]) if (fs.existsSync(c)) return c;
  return null;
}
const bp = findBundle();
const bundleRaw = bp ? fs.statSync(bp).size : null;
const bundleGz = bp ? gz(fs.readFileSync(bp, 'utf8')) : null;

// ── SECURITY: count sinks + classify ────────────────────────────
// Sinks live in script bodies. Scan only those, but keep original line numbers
// by blanking everything else rather than extracting.
const scriptOnly = (() => {
  const masked = SCAN.maskNonMarkup(html);          // comments + script/style bodies blanked
  let out = html.split('');
  for (let i = 0; i < html.length; i++) if (masked[i] === html[i]) out[i] = html[i] === '\n' ? '\n' : ' ';
  return out.join('');                              // keeps ONLY what the mask blanked = the bodies
})();
const lines = scriptOnly.split('\n');
const sinkRe = /\.innerHTML\s*=|insertAdjacentHTML|\.outerHTML\s*=/;
const sinks = [];
lines.forEach((ln, i) => { if (sinkRe.test(ln)) sinks.push({ n: i + 1, t: ln.trim() }); });

const clearOnly = sinks.filter(s => /innerHTML\s*=\s*(['"`])\1\s*;?/.test(s.t));
const dynamic = sinks.filter(s => (s.t.includes('+') || s.t.includes('${') || s.t.includes('`')) && !clearOnly.includes(s));
const staticLit = sinks.filter(s => !clearOnly.includes(s) && !dynamic.includes(s));
// dynamic + no visible esc()/escape/encode near the interpolation = HIGH risk
const escNear = (t) => /esc\(|escape|encodeURI|htmlEsc|sanitiz/i.test(t);
const dynUnescaped = dynamic.filter(s => !escNear(s.t));
const dynEscaped = dynamic.filter(s => escNear(s.t));

// existing defenses
// A real <meta http-equiv="Content-Security-Policy"> element, not the phrase.
const cspContent = (() => {
  for (const t of SCAN.scanTags(SCAN.maskNonMarkup(html))) {
    if (t.tag.toLowerCase() !== 'meta') continue;
    const he = t.attrs.find((a) => a.name.toLowerCase() === 'http-equiv');
    if (!he || he.valStart < 0) continue;
    if (html.slice(he.valStart, he.valEnd).trim().toLowerCase() !== 'content-security-policy') continue;
    const c = t.attrs.find((a) => a.name.toLowerCase() === 'content');
    return c && c.valStart >= 0 ? html.slice(c.valStart, c.valEnd) : '';
  }
  return null;
})();
const hasCSP = cspContent !== null;
// 'script' is the only value that makes the directive do anything.
const ttEnforce = hasCSP && /(^|;)\s*require-trusted-types-for\s+[^;]*'script'/i.test(cspContent);
const hasTT = /trustedTypes\s*\.\s*createPolicy/.test(scriptOnly);
const hasEsc = /function\s+(esc|htmlEsc|escapeHtml)\b|(esc|htmlEsc)\s*=\s*\(/.test(scriptOnly);
const inlineHandlers = SCAN.inlineHandlers(html);   // real handler attributes only
const addEL = (scriptOnly.match(/addEventListener/g) || []).length;

// ── SPEED: heuristic signals ────────────────────────────────────
// innerHTML forces HTML parse + full reflow; el()/setSafe build nodes + one reflow.
// We report the count of parse-triggering sinks and handler wiring as the signal.
const reflowSinks = dynamic.length + staticLit.length; // each re-parses HTML
const perNodeHandlers = addEL; // hand-wired listeners (delegation replaces N with 1)

// ── SIZE: adoption cost ─────────────────────────────────────────
// add-bundle adds the bundle; shim-annotate adds ~0.4KB helper.
const addBundleCost = bundleGz;             // gz bytes added
const shimCost = 420;                        // ~renderTrusted() helper, bytes

// choose a recommended strategy
let strategy, sizeDelta, sizeNote;
if (dynUnescaped.length > 0 && !hasCSP && !hasTT) {
  strategy = 'add-bundle';
  sizeDelta = `+${(addBundleCost/1024).toFixed(1)}KB gz`;
  sizeNote = 'full runtime — tool will render JSON specs safely';
} else if ((hasTT || hasCSP) && (dynamic.length + staticLit.length) > 0) {
  strategy = 'shim-annotate';
  sizeDelta = `+~${shimCost}B`;
  sizeNote = 'already hardened — just name/guard the raw-HTML sinks (no bundle)';
} else if (dynUnescaped.length > 0) {
  strategy = 'add-bundle';
  sizeDelta = `+${(addBundleCost/1024).toFixed(1)}KB gz`;
  sizeNote = 'live sink risk — adopt the safe compiler';
} else {
  strategy = 'convert-sites / optional';
  sizeDelta = `+~${shimCost}B or 0`;
  sizeNote = 'no live risk found — adoption is optional (audit/consistency)';
}

// ── verdict ─────────────────────────────────────────────────────
let verdict;
if (dynUnescaped.length > 0) verdict = 'ADOPT — live XSS sink(s) present';
else if ((hasTT || hasCSP) && dynamic.length > 0) verdict = 'HARDEN-ONLY — strong defenses; make sinks auditable';
else if (sinks.length === 0) verdict = 'SKIP — no innerHTML sinks to convert';
else verdict = 'OPTIONAL — sinks look escaped; adopt for consistency/audit';

// ── emit report ─────────────────────────────────────────────────
const pct = (n, d) => d ? ((n / d) * 100).toFixed(2) : '0';
const B = (n) => n == null ? '?' : `${n} B`;
const KB = (n) => n == null ? '?' : `${(n/1024).toFixed(1)}KB`;

console.log(`
╔══════════════════════════════════════════════════════════════╗
║  0html VALUE REPORT — ${path.basename(file).padEnd(38)}║
╚══════════════════════════════════════════════════════════════╝

TARGET
  file          ${path.basename(file)}
  size          ${B(bytes)} (${KB(gz(html))} gz)
  script blocks ${(html.match(/<script/g) || []).length}

── SECURITY ──────────────────────────────────────────────────
  innerHTML/insertAdjacentHTML sinks:  ${sinks.length}
    ├─ clear-only (safe)               ${clearOnly.length}
    ├─ static literal (safe)           ${staticLit.length}
    ├─ dynamic + escaped (low)         ${dynEscaped.length}
    └─ dynamic + UNescaped (HIGH RISK) ${dynUnescaped.length}   ${dynUnescaped.length ? '⚠ verify: escaping may be off-line (in a helper)' : '✓ none'}
  inline on* handlers:                 ${inlineHandlers}   ${inlineHandlers ? '(refused by 0html — CSP-clean)' : ''}
  hand-wired addEventListener:         ${addEL}${addEL > 5 ? '   (delegation replaces N with 1)' : ''}

  existing defenses:
    Content-Security-Policy            ${hasCSP ? '✓ present' : '✗ none'}
    Trusted Types policy               ${hasTT ? '✓ present' : '✗ none'}${ttEnforce ? ' (enforce)' : ''}
    escape helper (esc/htmlEsc)        ${hasEsc ? '✓ present' : '✗ none'}

  AFTER adoption you gain (all tested — 138 assertions, 100k-spec fuzz):
    • no script/iframe/object injection possible          (G1,G2 / J3)
    • no javascript:/data: URLs, incl. srcset & <use>      (I3 / v1.1.1)
    • no inline handlers; events via code registry         (I2,J4 / J6)
    • no prototype pollution from any spec                 (J1)
    • bounded — no deep-nest / breadth DoS                 (J2)
    • Trusted-Types enforce compatible                     (J7)
    • target=_blank auto rel=noopener (anti-tabnabbing)    (v1.1.1)
    • raw HTML double-gated, off by default                (J5)
  ${dynUnescaped.length ? `→ ${dynUnescaped.length} live sink(s) become safe-by-construction.` : '→ scattered escaping becomes a single greppable trust boundary.'}

── SPEED ─────────────────────────────────────────────────────
  HTML-reparse sinks (innerHTML forces parse+reflow):  ${reflowSinks}
    → el()/setSafe build nodes directly: one reflow, no HTML parse
  per-element listeners that delegation collapses:     ${perNodeHandlers} → 1
  ${reflowSinks > 3 || perNodeHandlers > 5 ? '→ measurable win on re-render-heavy paths.' : '→ speed impact minor here (few sinks).'}
  note: micro-scale; correctness/security is the primary win, not raw speed.

── SIZE ──────────────────────────────────────────────────────
  recommended strategy:   ${strategy}
  adoption cost:          ${sizeDelta}
                          ${sizeNote}
  bundle (if add-bundle): ${B(bundleRaw)} raw / ${B(bundleGz)} gz  (zero deps)
  vs the alternative:     an HTML sanitizer (e.g. DOMPurify) is ~45KB+ min;
                          0html is ${KB(bundleRaw)} and also gives you the JSON UI layer.
  ${dynUnescaped.length && !hasCSP ? '→ cost buys elimination of a live XSS class. Net positive.' : '→ cost is small; weigh against the audit/consistency gain.'}

── VERDICT ───────────────────────────────────────────────────
  ${verdict}
  strategy: ${strategy}   size: ${sizeDelta}

  (This is analysis only — no files changed. The plan will show exact
   diffs and stop for your approval before touching anything.)

  NOTE: sink risk is a per-line heuristic. A "dynamic + UNescaped" hit may
  actually escape in a helper function (off-line) — the agent must eyeball
  each flagged line before calling it a live bug. False positives are safe
  (over-cautious); the number is a starting point, not a verdict on its own.
`);
