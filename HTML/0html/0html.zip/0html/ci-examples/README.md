# 0html — CI / deployment recipes

Gate a build on the 0html security posture so a regression (or a forgotten
re-pin after a rebuild) fails the pipeline instead of shipping.

## The mechanism (plan §9.1)

A rebuild changes the inline-script bytes → the L2 hash-pin goes stale → an
enforce CSP that pins the old hash would block the app's own script. So every
build must:

1. **re-pin** — `node 0html/0html-layers.cjs update <dist>` (refreshes L2's
   hashes for the freshly built scripts; leaves exactly one hash, no accumulation), then
2. **gate** — `node 0html/0html-layers.cjs conformance <dist> --require=<your tiers> --json`
   (non-zero exit on any drift; tamper-evident sha256 in the report).

## Files here

- `.github/workflows/0html-conformance.yml` — GitHub Actions: verify integrity →
  build → re-pin → conformance gate.
- `Makefile` — `make harden` (build + re-pin + gate) and `make verify`.

## combine.sh hook (make re-pin impossible to forget)

Add the re-pin as the **last step** of your build so it can't be skipped:

```sh
# ... existing combine.sh that writes dist/app.html ...
node 0html/0html-layers.cjs update dist/app.html   # refresh the L2 hash-pin
```

Projects with no build step (hand-edited HTML) skip the re-pin; the conformance
gate still runs.
