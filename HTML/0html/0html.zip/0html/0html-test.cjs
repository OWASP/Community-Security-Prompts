// 0html-test.cjs — zero-dependency security + behavior tests
// Proves J1–J6 against hostile JSON specs. Run: node 0html-test.cjs

'use strict';

// ── Minimal DOM shim (same shape as 0bind-test) ────────────────
let SCRIPT_EXECUTIONS = 0;
class Node {
  constructor() { this.childNodes = []; this.nodeType = 1; }
  appendChild(c) {
    if (c instanceof DocumentFragment) {
      for (const k of c.childNodes.slice()) this.appendChild(k); return c;
    }
    c.parentNode = this; this.childNodes.push(c); return c;
  }
  get textContent() { return this.childNodes.map(c => c.textContent ?? '').join(''); }
  set textContent(v) { this.childNodes = []; if (v !== '') this.appendChild(new TextNode(String(v))); }
}
class TextNode {
  constructor(d) { this.data = String(d); this.nodeType = 3; }
  get textContent() { return this.data; }
}
class Element extends Node {
  constructor(tag) { super(); this.tagName = String(tag).toLowerCase(); this._attrs = {}; this.dataset = {}; }
  setAttribute(k, v) {
    this._attrs[k] = String(v);
    if (k.startsWith('data-')) {
      const c = k.slice(5).replace(/-([a-z])/g, (_, x) => x.toUpperCase());
      this.dataset[c] = String(v);
    }
    if (k.toLowerCase().startsWith('on')) this._hadInlineHandler = true;
  }
  getAttribute(k) { return this._attrs[k]; }
  hasAttribute(k) { return Object.prototype.hasOwnProperty.call(this._attrs, k); }
  set id(v) { this._attrs.id = v; } get id() { return this._attrs.id; }
  set className(v) { this._attrs.class = v; } get className() { return this._attrs.class || ''; }
  // count element descendants (for node-bound tests)
  countEls() {
    let n = 1;
    for (const c of this.childNodes) if (c.countEls) n += c.countEls();
    return n;
  }
  // find refused placeholders
  findRefused(out = []) {
    if (this._attrs['data-0html-refused']) out.push(this._attrs['data-0html-refused']);
    for (const c of this.childNodes) if (c.findRefused) c.findRefused(out);
    return out;
  }
  addEventListener() {}
}
class Template extends Element {
  constructor() { super('template'); this.content = new DocumentFragment(); }
  set innerHTML(html) {
    if (/<script[\s>]/i.test(html)) { const s = new Element('script'); s.appendChild(new TextNode(html)); this.content.appendChild(s); }
    else { const h = new Element('span'); h.appendChild(new TextNode('[[HTML]]')); this.content.appendChild(h); }
  }
}
class DocumentFragment extends Node { constructor() { super(); this.nodeType = 11; } }
const document = {
  createElement: (t) => t === 'template' ? new Template() : new Element(t),
  createTextNode: (d) => new TextNode(d),
  createDocumentFragment: () => new DocumentFragment(),
  body: new Element('body'), addEventListener: () => {},
};
global.document = document; global.Node = Node;
global.window = { addEventListener: () => {} };

// ── Load 0bind then 0html, both as .cjs (repo is type:module) ──
const fs = require('fs'), os = require('os'), pathm = require('path');
const toCjs = (name) => {
  const p = pathm.join(os.tmpdir(), `${name}-${process.pid}.cjs`);
  fs.writeFileSync(p, fs.readFileSync(pathm.join(__dirname, `${name}.js`), 'utf8'));
  return p;
};
// 0bind must load first and register OUI_BIND on global for 0html to find.
global.OUI_BIND = require(toCjs('0bind'));
const html0 = require(toCjs('0html'));

// ── runner ─────────────────────────────────────────────────────
let pass = 0, fail = 0;
const eq = (n, g, w) => { const ok = g === w; console.log(`${ok ? '✓' : '✗'} ${n}`); if (!ok) { console.log(`    got:  ${JSON.stringify(g)}`); console.log(`    want: ${JSON.stringify(w)}`); fail++; } else pass++; };
const ok = (n, c) => eq(n, !!c, true);

console.log('\n── basic compile: string → text ──');
{
  const t = html0.compile('hello <b>world</b>');
  eq('string becomes text, markup inert', t.textContent, 'hello <b>world</b>');
  ok('no element child from string', t.nodeType === 3);
}

console.log('\n── basic compile: node tree ──');
{
  const n = html0.compile({ tag: 'div', class: 'card', children: [
    { tag: 'h3', text: 'Title' },
    { tag: 'p', text: 'Body' },
  ]});
  eq('root tag', n.tagName, 'div');
  eq('root class', n.className, 'card');
  eq('child count', n.childNodes.length, 2);
  eq('h3 text', n.childNodes[0].textContent, 'Title');
}

console.log('\n── J1: prototype pollution refused ──');
{
  // classic __proto__ injection in a spec
  const before = ({}).polluted;
  const spec = JSON.parse('{"tag":"div","__proto__":{"polluted":"yes"},"attrs":{"__proto__":{"x":1}}}');
  html0.compile(spec);
  eq('Object.prototype not polluted', ({}).polluted, before);
  // constructor / prototype keys as attrs
  const n = html0.compile({ tag: 'div', attrs: { constructor: 'x', prototype: 'y', __proto__: 'z', title: 'ok' } });
  ok('constructor attr dropped', !n.hasAttribute('constructor'));
  ok('prototype attr dropped', !n.hasAttribute('prototype'));
  eq('legit attr kept', n.getAttribute('title'), 'ok');
}

console.log('\n── J1: fromJSON reviver strips dangerous keys ──');
{
  const before = ({}).evil;
  html0.fromJSON('{"tag":"span","__proto__":{"evil":"1"}}');
  eq('no pollution via fromJSON', ({}).evil, before);
}

console.log('\n── J2: depth bound (deep-nest bomb) ──');
{
  // build a 200-deep spec
  let deep = { tag: 'div', text: 'x' };
  for (let i = 0; i < 200; i++) deep = { tag: 'div', children: [deep] };
  let threw = false;
  try { html0.compile(deep, { maxDepth: 64 }); } catch (e) { threw = e instanceof RangeError; }
  ok('deep nesting past maxDepth throws RangeError', threw);
  // within bound is fine
  let okDeep = { tag: 'div', text: 'x' };
  for (let i = 0; i < 10; i++) okDeep = { tag: 'div', children: [okDeep] };
  let threw2 = false;
  try { html0.compile(okDeep, { maxDepth: 64 }); } catch { threw2 = true; }
  ok('shallow nesting within bound OK', !threw2);
}

console.log('\n── J2: node-count bound (breadth bomb) ──');
{
  const kids = [];
  for (let i = 0; i < 50; i++) kids.push({ tag: 'span', text: String(i) });
  let threw = false;
  try { html0.compile({ tag: 'div', children: kids }, { maxNodes: 20 }); } catch (e) { threw = e instanceof RangeError; }
  ok('too many nodes past maxNodes throws', threw);
}

console.log('\n── J3: dangerous tags refused → inert placeholder ──');
{
  for (const bad of ['script', 'iframe', 'object', 'embed', 'link', 'meta', 'base', 'style']) {
    const n = html0.compile({ tag: bad, text: 'x' });
    eq(`<${bad}> not rendered as itself`, n.tagName, 'span');
    eq(`  marked refused`, n.getAttribute('data-0html-refused'), bad);
  }
  // unknown tag too
  const u = html0.compile({ tag: 'blink-marquee-x', text: 'x' });
  eq('unknown tag refused', u.getAttribute('data-0html-refused'), 'blink-marquee-x');
  // children survive under a refused parent
  const withKids = html0.compile({ tag: 'script', children: [{ tag: 'span', text: 'safe' }] });
  ok('safe children preserved under refused tag', withKids.textContent.includes('safe'));
}

console.log('\n── J3: allowed tags render normally ──');
{
  for (const good of ['div', 'a', 'button', 'input', 'table', 'svg', 'p', 'form']) {
    const n = html0.compile({ tag: good });
    eq(`<${good}> renders`, n.tagName, good);
  }
}

console.log('\n── J4: event handlers are opaque data-on-* strings ──');
{
  const n = html0.compile({ tag: 'button', text: 'Save', on: { click: 'saveHandler' }, arg: 'rows' });
  eq('data-on-click set to name', n.getAttribute('data-on-click'), 'saveHandler');
  eq('data-arg passthrough', n.getAttribute('data-arg'), 'rows');
  // a handler value that is NOT a string is refused
  const bad = html0.compile({ tag: 'button', on: { click: { $fn: 'alert(1)' } } });
  ok('non-string handler refused', !bad.hasAttribute('data-on-click'));
  // eventish attr in attrs{} is refused here too (defense in depth)
  const evt = html0.compile({ tag: 'div', attrs: { onclick: 'alert(1)', onmouseover: 'x()' } });
  ok('onclick via attrs refused', !evt.hasAttribute('onclick'));
  ok('onmouseover via attrs refused', !evt.hasAttribute('onmouseover'));
}

console.log('\n── J4/I3: URL schemes still enforced through JSON ──');
{
  const bad = html0.compile({ tag: 'a', text: 'x', attrs: { href: 'javascript:alert(1)' } });
  ok('javascript: href dropped via JSON', !bad.hasAttribute('href'));
  const data = html0.compile({ tag: 'img', attrs: { src: 'data:text/html,<script>x</script>' } });
  ok('data: src dropped via JSON', !data.hasAttribute('src'));
  const good = html0.compile({ tag: 'a', text: 'x', attrs: { href: 'https://0ui.ai' } });
  eq('https href kept via JSON', good.getAttribute('href'), 'https://0ui.ai');
}

console.log('\n── J5: raw html DOUBLE-GATED (default OFF) ──');
{
  SCRIPT_EXECUTIONS = 0; delete global.__PWNED;
  // 1) default: refused even with correct shape
  const off = html0.compile({ tag: 'div', html: { $trust: '<b>x</b>', from: 'markdown' } });
  eq('raw html refused by default (empty)', off.textContent, '');
  // 2) allowTrustedHTML but generator NOT allowlisted → refused
  const notAllowed = html0.compile(
    { tag: 'div', html: { $trust: '<b>x</b>', from: 'evilgen' } },
    { allowTrustedHTML: true, trustedGenerators: ['markdown'] });
  eq('raw html refused when generator not allowlisted', notAllowed.textContent, '');
  // 3) fully gated open → renders (represented as [[HTML]] by shim)
  const okHtml = html0.compile(
    { tag: 'div', html: { $trust: '<b>bold</b>', from: 'markdown' } },
    { allowTrustedHTML: true, trustedGenerators: ['markdown'] });
  ok('raw html renders when both gates pass', okHtml.childNodes.length > 0);
  // 4) even fully gated, a <script> does NOT execute (template parse)
  const scriptHtml = html0.compile(
    { tag: 'div', html: { $trust: '<script>global.__PWNED=1</script>', from: 'markdown' } },
    { allowTrustedHTML: true, trustedGenerators: ['markdown'] });
  ok('script in gated html did not execute', global.__PWNED === undefined);
  // 5) malformed html shape refused
  const malformed = html0.compile({ tag: 'div', html: '<b>raw string</b>' }, { allowTrustedHTML: true });
  eq('bare-string html refused', malformed.textContent, '');
}

console.log('\n── XSS payload suite through full JSON path ──');
{
  const payloads = [
    { tag: 'div', text: '<img src=x onerror=alert(1)>' },
    { tag: 'span', text: '"><svg/onload=alert(1)>' },
    { tag: 'p', children: ['<script>alert(1)</script>'] },
  ];
  for (const p of payloads) {
    const n = html0.compile(p);
    const refused = n.findRefused();
    ok(`payload stays inert text (no script/img element): ${JSON.stringify(p).slice(0,40)}…`,
       refused.length === 0 && n.textContent.includes('<') === true);
  }
}

console.log('\n── validate(): dry-run lint ──');
{
  const r = html0.validate({ tag: 'script', children: [{ tag: 'iframe' }] });
  ok('validate returns ok=true for refusable-but-safe spec', r.ok === true);
  ok('validate collects warnings', r.warnings.length >= 2);
  ok('validate returns a node', r.node && r.node.nodeType === 1);
  // bound violation surfaces as ok=false
  let deep = { tag: 'div', text: 'x' };
  for (let i = 0; i < 100; i++) deep = { tag: 'div', children: [deep] };
  const rd = html0.validate(deep, { maxDepth: 32 });
  ok('validate flags depth bomb as ok=false', rd.ok === false);
}

console.log('\n── render(): mount clears + appends ──');
{
  const target = new Element('div');
  target.appendChild(new TextNode('old'));
  html0.render({ tag: 'p', text: 'new' }, target);
  eq('target cleared of old content', target.textContent, 'new');
  eq('mounted element present', target.childNodes[0].tagName, 'p');
}

console.log('\n── text vs children precedence ──');
{
  // children wins over text if both present (documented priority)
  const n = html0.compile({ tag: 'div', text: 'ignored', children: [{ tag: 'span', text: 'kept' }] });
  ok('children take precedence over text', n.textContent === 'kept');
}

console.log('\n────────────────────────────────────────');
console.log(`  ${pass} passed, ${fail} failed`);
console.log('────────────────────────────────────────\n');
process.exit(fail ? 1 : 0);
