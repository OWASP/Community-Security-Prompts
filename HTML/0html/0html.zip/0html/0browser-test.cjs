#!/usr/bin/env node
/*
  0browser-test.cjs — load the SHIPPED dist/ tools in a real browser.

  Everything else in this repo tests source modules under a DOM shim, or checks
  artifacts with `node --check`. Neither can see the two failure modes that
  actually shipped:

    * v1.2.0-v1.8.0 dist tools threw "SyntaxError: missing ) after argument
      list" and never defined html0 — the whole library absent, while
      `0html verify` reported the artifact healthy (SECURITY-IMPROVEMENTS #15);

    * the CSP hash covered only the LAST inline module, so the Trusted Types
      bootstrap and the clickjacking frame-buster were REFUSED by the very
      policy meant to harden the page, while `verify` said "loads under
      enforce" (#35).

  Requires playwright with a browser available. Skips cleanly (exit 0) when it
  is not installed, so it can sit in build.sh without becoming a hard dependency.

  Run: node 0browser-test.cjs
*/
'use strict';
const fs = require('fs'), path = require('path');

let chromium;
try { ({ chromium } = require('playwright')); }
catch (_) {
  console.log('\n  0browser-test: playwright not installed — SKIPPED');
  console.log('  (install it to verify the shipped tools actually load under their own CSP)\n');
  process.exit(0);
}

const TOOLS = ['dist/0html-starter.html', 'dist/0scan.html', 'dist/0html-playground.html']
  .map((p) => path.join(__dirname, p)).filter((p) => fs.existsSync(p));

let pass = 0, fail = 0;
const ck = (n, c) => c ? (pass++, console.log('  \u2713 ' + n)) : (fail++, console.log('  \u2717 FAIL ' + n));

(async () => {
  let browser;
  try { browser = await chromium.launch(); }
  catch (e) {
    console.log(`\n  0browser-test: no browser binary (${String(e).split('\n')[0].slice(0, 60)}) — SKIPPED\n`);
    process.exit(0);
  }

  for (const tool of TOOLS) {
    const base = path.basename(tool);
    console.log(`\n-- ${base} --`);
    const page = await browser.newPage();
    const pageErrors = [], cspRefusals = [];
    page.on('pageerror', (e) => pageErrors.push(String(e).split('\n')[0]));
    page.on('console', (m) => { if (m.type() === 'error' && /Content Security Policy/i.test(m.text())) cspRefusals.push(m.text()); });
    await page.goto('file://' + tool, { waitUntil: 'load' });

    ck('no uncaught page error', pageErrors.length === 0 || (console.log('      ' + pageErrors[0]), false));
    ck('no CSP refusal', cspRefusals.length === 0 || (console.log('      ' + cspRefusals[0].slice(0, 120)), false));

    const env = await page.evaluate(() => ({
      html0: typeof window.html0, bind: typeof window.OUI_BIND,
      version: window.html0 && window.html0.version,
      sameVersion: window.html0 && window.OUI_BIND && window.html0.version === window.OUI_BIND.version,
    }));
    ck('html0 is defined', env.html0 === 'object');
    ck('0bind runtime is defined', env.bind === 'object');
    ck('versions agree', env.sameVersion === true);

    // the runtime gates, exercised against a REAL DOM rather than the shim
    const gates = await page.evaluate(() => {
      const h = window.html0, out = {};
      const a = h.compile({ tag: 'a', attrs: { href: 'javascript:alert(1)', onclick: 'x()' }, text: 'x' });
      out.jsHref = a.getAttribute('href');
      out.onclick = a.getAttribute('onclick');
      const s = h.compile({ tag: 'div', attrs: { style: 'background:url(\\2f\\2f evil.example/x)' } });
      out.escapedCssUrl = s.getAttribute('style');
      const t = h.compile({ tag: 'div', text: '<img src=x onerror=alert(1)>' });
      out.textEscaped = t.querySelector('img') === null && t.textContent.indexOf('<img') === 0;
      const svg = h.compile({ tag: 'svg', children: [{ tag: 'circle', attrs: { cx: 1, cy: 1, r: 1 } }] }, { svg: true });
      out.svgNS = svg.namespaceURI;
      out.svgChildNS = svg.firstChild && svg.firstChild.namespaceURI;
      out.svgRenders = typeof svg.getBBox === 'function';
      const bad = h.compile({ tag: 'script', text: 'window.__pwned = 1;' });
      document.body.appendChild(bad);
      out.scriptRefused = window.__pwned === undefined;
      return out;
    });
    ck('javascript: href dropped', gates.jsHref === null);
    ck('on* attribute refused', gates.onclick === null);
    ck('CSS-escaped off-origin url() dropped', gates.escapedCssUrl === null);
    ck('text child cannot inject markup', gates.textEscaped === true);
    ck('svg:true builds in the SVG namespace', gates.svgNS === 'http://www.w3.org/2000/svg');
    ck('svg children too', gates.svgChildNS === 'http://www.w3.org/2000/svg');
    ck('and they are real rendered SVG (getBBox)', gates.svgRenders === true);
    ck('<script> tag refused by the compiler', gates.scriptRefused === true);

    await page.close();
  }

  await browser.close();
  console.log('\n' + '-'.repeat(40));
  console.log(`  ${pass} passed, ${fail} failed  (shipped tools, in-browser)`);
  console.log('-'.repeat(40));
  process.exit(fail ? 1 : 0);
})();
