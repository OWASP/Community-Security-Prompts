#!/usr/bin/env node
/* ╔═══════════════════════════════════════════════════════════════╗
   ║  0html — the standard's adoption CLI                           ║
   ║  Zero deps. Node stdlib only. Drop-in for any single-file tool.║
   ║  v1.5.0 — sbom (CycloneDX 1.6) + SBOM verify; unchanged this rev║
   ╚═══════════════════════════════════════════════════════════════╝

   COMMANDS
     0html add <file.html>       Inline the pinned bundle into <file> at the
                                 __BUNDLE__ marker (or before </head> if none),
                                 recompute the CSP hash, write a .lock entry.
     0html verify [<file.html>]  Check bundle integrity (SHA-256) against the
                                 lockfile. With a file: also verify its CSP
                                 hash matches its inline script. Exit 1 on drift.
     0html update <file.html>    Re-inline the current bundle, refresh CSP hash
                                 + lock. Use after upgrading the standard.
     0html pin                   Write/refresh 0html.lock with the SHA-256 of
                                 the current dist/0html.bundle.js + versions.
     0html hash <file.html>      Print the SHA-256 CSP hash of a file's last
                                 inline <script type="module"> (for manual CSP).

   THE LOCKFILE (0html.lock, JSON)
     Pins the exact bundle bytes a project adopted, so `verify` is
     tamper-evident: if the vendored bundle changes by one byte, verify fails.
     This is the integrity spine of the standard.

   PATHS
     Looks for the bundle at (first hit):
       ./dist/0html.bundle.js  |  ./0html.bundle.js  |  alongside this script.
*/

'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const CWD = process.cwd();
const SELF_DIR = __dirname;

// Lock lives next to the bundle. Resolve like the bundle: prefer CWD (project
// root adoption), fall back to the script's own dir (running from inside 0html/).
// This makes both `node 0html-cli.cjs` and `node 0html/0html-cli.cjs` work.
function findLock() {
  const cands = [path.join(CWD, '0html.lock'), path.join(SELF_DIR, '0html.lock')];
  for (const c of cands) if (fs.existsSync(c)) return c;
  return path.join(SELF_DIR, '0html.lock'); // default write target = beside script
}
const LOCK = findLock();

// ── helpers ─────────────────────────────────────────────────────
const sha256 = (buf) => crypto.createHash('sha256').update(buf).digest('base64');
// CycloneDX hashes are hex-encoded (distinct from the lock's base64 digests).
const sha256hex = (buf) => crypto.createHash('sha256').update(buf).digest('hex');
const die = (m) => { console.error(`0html: ${m}`); process.exit(1); };
const ok  = (m) => console.log(`✓ ${m}`);

function findBundle() {
  const cands = [
    path.join(CWD, 'dist', '0html.bundle.js'),
    path.join(CWD, '0html.bundle.js'),
    path.join(SELF_DIR, 'dist', '0html.bundle.js'),
    path.join(SELF_DIR, '0html.bundle.js'),
  ];
  for (const c of cands) if (fs.existsSync(c)) return c;
  die('0html.bundle.js not found (looked in ./dist, ., and script dir). Run build.sh first.');
}

// read the version strings the bundle advertises
function bundleVersions(src) {
  const html = /version:\s*'([\d.]+)'[\s\S]*?spec:\s*'([^']+)'/.exec(src);
  // bundle contains both bind (first version) and html (second, with spec)
  const all = [...src.matchAll(/version:\s*'([\d.]+)'/g)].map(m => m[1]);
  const spec = /spec:\s*'([^']+)'/.exec(src);
  return {
    bind: all[0] || '?',
    html: all[1] || all[0] || '?',
    spec: spec ? spec[1] : '?',
  };
}

// extract the LAST inline module script body from an HTML string
function lastModuleScript(html) {
  const m = allModuleScripts(html);
  return m.length ? m[m.length - 1] : null;
}
// EVERY inline module script, terminated the way the HTML tokenizer terminates
// one: at the first "</script", regardless of JS string context. Under CSP
// `script-src 'sha256-…'` each inline script needs its own hash, so checking
// only the last one let a second script ship unhashed (and blocked).
function allModuleScripts(html) {
  return [...html.matchAll(/<script\s+type="module"\s*>([\s\S]*?)<\/script/g)].map((m) => m[1]);
}
// EVERY inline script — classic ones too. A hash source in script-src removes
// 'unsafe-inline', so a script with no hash is refused. Only module scripts were
// checked, which is why the shipped starter and 0scan passed `verify` while
// Chromium refused their Trusted Types bootstrap AND their clickjacking
// frame-buster. Shares the project's one scanner.
function allInlineScripts(html) {
  try {
    return require(path.join(SELF_DIR, '0csp-hashes.cjs')).inlineScriptBodies(html);
  } catch (e) {
    // S2-01. This used to degrade silently to allModuleScripts(), which is the
    // EXACT check that let the Trusted Types bootstrap and the frame-buster ship
    // unhashed (#35) — a fallback that reinstates the bug it replaced. It is not
    // reachable today: 0csp-hashes.cjs is integrity-pinned, so a missing file
    // fails the toolchain check first (verified: verify exits 1). But a silent
    // downgrade to a known-defective check is the wrong shape regardless, so it
    // now says what it did and why the result is weaker.
    console.log('  \u26a0 0csp-hashes.cjs unavailable (' + (e && e.message ? e.message.slice(0, 60) : 'unknown') +
                ') — falling back to MODULE-ONLY script checking.');
    console.log('    Classic inline scripts will not be hash-checked; this is the pre-#35 behaviour.');
    return allModuleScripts(html);
  }
}
// Does this tool actually CARRY the code we just verified? `verify <file>` is
// sold as attesting a vendored single-file tool, but every check above runs
// against files sitting next to the CLI — the tool's own CSP hash is computed
// from its own script, so it is self-consistent by construction. Nothing tied
// the two together: a tool with the library gutted out and the hash recomputed
// passed. (That is also why a build that mangled the inlined source shipped
// undetected.) Both build paths — __BUNDLE__ and __BIND__/__HTML__ — end up
// containing these two module bodies verbatim, so that is what we look for.
function toolCarriesLibrary(scripts) {
  const bindSrc = fs.readFileSync(path.join(SELF_DIR, '0bind.js'), 'utf8').trim();
  const htmlRaw = fs.readFileSync(path.join(SELF_DIR, '0html.js'), 'utf8');
  const htmlSrc = htmlRaw.replace(/^(?:\/\/[^\n]*\n|[ \t]*\n)+/, '').trim();
  const missing = [];
  if (!scripts.some((s) => s.includes(bindSrc))) missing.push('0bind.js');
  if (!scripts.some((s) => s.includes(htmlSrc))) missing.push('0html.js');
  return missing;
}

// ── commands ────────────────────────────────────────────────────
// Toolchain files whose integrity the lock also pins. Prefer the set already
// recorded in an existing lock (so a project can extend it); otherwise the
// default engine + registry. Re-pinning here is what stops `build.sh` from
// silently DROPPING the toolchain pins on every build (verify skips a missing
// `toolchain`, so losing it would quietly weaken the supply-chain guarantee).
const DEFAULT_TOOLCHAIN = ['0html-layers.cjs', '0scan-html.cjs', '0csp-hashes.cjs', '0build.cjs', 'layers.json'];
function pinToolchain() {
  // UNION of the defaults with whatever a project has added, not the recorded
  // set alone. Preferring the prior lock meant the toolchain set could only ever
  // shrink or stay the same: a file added to DEFAULT_TOOLCHAIN by an upgrade
  // would never be pinned on any install that already had a lock, and `verify`
  // only checks what the lock lists — so it would pass while shipping an
  // unpinned toolchain file. Project additions are still preserved.
  const files = [...DEFAULT_TOOLCHAIN];
  try {
    if (fs.existsSync(LOCK)) {
      const prev = JSON.parse(fs.readFileSync(LOCK, 'utf8'));
      if (Array.isArray(prev.toolchain)) {
        for (const t of prev.toolchain) if (t && t.file && !files.includes(t.file)) files.push(t.file);
      }
    }
  } catch (_) { /* malformed prior lock → defaults only */ }
  const out = [];
  for (const f of files) {
    const p = path.join(SELF_DIR, f);
    if (!fs.existsSync(p)) { console.error(`  ! toolchain file missing, not pinned: ${f}`); continue; }
    out.push({ file: f, sha256: sha256(fs.readFileSync(p)) });
  }
  return out;
}

function cmdPin() {
  const bp = findBundle();
  const src = fs.readFileSync(bp);
  const v = bundleVersions(src.toString());
  const toolchain = pinToolchain();
  const lock = {
    standard: '0html',
    spec: v.spec,
    bundle: { file: 'dist/0html.bundle.js', sha256: sha256(src), bytes: src.length },
    versions: { runtime: v.bind, compiler: v.html },
    pinnedAt: new Date().toISOString(),
    toolchain,
  };
  fs.writeFileSync(LOCK, JSON.stringify(lock, null, 2) + '\n');
  ok(`pinned ${v.spec}  runtime ${v.bind} / compiler ${v.html}`);
  ok(`bundle sha256-${lock.bundle.sha256.slice(0, 24)}…  (${src.length} B)`);
  ok(`toolchain pinned: ${toolchain.map((t) => t.file).join(', ') || '(none)'}`);
  console.log(`  → ${LOCK}`);
}

// ── CycloneDX 1.6 SBOM (A03 supply-chain interop) ───────────────
// 0html has ZERO external dependencies, so this BOM's value is twofold:
//   (1) it makes that claim machine-verifiable (no pkg:npm/… nodes; the whole
//       dependency graph is internal 0html components), and
//   (2) it carries the same integrity hashes as the lock in a standard,
//       tool-ingestible shape (Dependency-Track, grype, trivy, OSV-Scanner…).
// Hashes are HEX per the CycloneDX spec (the lock uses base64). No license is
// asserted — the package declares none, and inventing one would be worse.
function cmdSbom() {
  const bp = findBundle();
  const distDir = path.dirname(bp);
  const src = fs.readFileSync(bp);
  const v = bundleVersions(src.toString());
  const hx = (p) => sha256hex(fs.readFileSync(p));
  const bindPath = path.join(SELF_DIR, '0bind.js');
  const htmlPath = path.join(SELF_DIR, '0html.js');

  const refLib = '0html', refBind = '0bind', refHtml = '0html-compiler', refBundle = '0html.bundle.js';
  const components = [
    { 'bom-ref': refBind, type: 'library', name: '0bind', version: v.bind,
      description: 'safe-DOM runtime (el/frag/setSafe/trust/on)',
      purl: `pkg:generic/0bind@${v.bind}`, hashes: [{ alg: 'SHA-256', content: hx(bindPath) }] },
    { 'bom-ref': refHtml, type: 'library', name: '0html-compiler', version: v.html,
      description: 'JSON → safe-DOM compiler',
      purl: `pkg:generic/0html-compiler@${v.html}`, hashes: [{ alg: 'SHA-256', content: hx(htmlPath) }] },
    { 'bom-ref': refBundle, type: 'file', name: '0html.bundle.js', version: v.html,
      description: 'combined shipped bundle (0bind + 0html)',
      hashes: [{ alg: 'SHA-256', content: hx(bp) }] },
  ];
  const dependencies = [
    { ref: refLib, dependsOn: [refBundle] },
    { ref: refBundle, dependsOn: [refBind, refHtml] },
    { ref: refBind, dependsOn: [] },
    { ref: refHtml, dependsOn: [] },
  ];
  // pinned toolchain (mirror the lock's file set), as components + graph nodes.
  for (const t of pinToolchain()) {
    const p = path.join(SELF_DIR, t.file);
    components.push({ 'bom-ref': `toolchain:${t.file}`, type: 'file', name: t.file, version: v.html,
      description: 'pinned build toolchain', hashes: [{ alg: 'SHA-256', content: hx(p) }] });
    dependencies.push({ ref: `toolchain:${t.file}`, dependsOn: [] });
  }

  const bom = {
    bomFormat: 'CycloneDX',
    specVersion: '1.6',
    serialNumber: `urn:uuid:${crypto.randomUUID()}`,
    version: 1,
    metadata: {
      timestamp: new Date().toISOString(),
      tools: { components: [{ type: 'application', name: '0html-cli', version: v.html }] },
      component: {
        'bom-ref': refLib, type: 'library', name: '0html', version: v.html,
        purl: `pkg:generic/0html@${v.html}`,
        description: 'JSON-first declarative safe-DOM UI compiler for single-file tools (zero-dependency)',
      },
      properties: [
        { name: '0html:externalRuntimeDependencies', value: '0' },
        { name: '0html:spec', value: v.spec },
      ],
    },
    components,
    dependencies,
  };

  const out = path.join(distDir, '0html.cdx.json');
  fs.writeFileSync(out, JSON.stringify(bom, null, 2) + '\n');
  ok(`SBOM written — CycloneDX 1.6, ${components.length + 1} components, 0 external deps`);
  console.log(`  → ${out}`);
}

function readLock() {
  if (!fs.existsSync(LOCK)) die('no 0html.lock — run `0html pin` first');
  try { return JSON.parse(fs.readFileSync(LOCK, 'utf8')); }
  catch { die('0html.lock is corrupt'); }
}

function cmdVerify(file) {
  const lock = readLock();
  const bp = findBundle();
  const src = fs.readFileSync(bp);
  const got = sha256(src);
  let bad = false;

  if (got === lock.bundle.sha256) {
    ok(`bundle integrity OK  (sha256-${got.slice(0, 24)}…)`);
  } else {
    console.error(`✗ BUNDLE DRIFT`);
    console.error(`    locked: sha256-${lock.bundle.sha256.slice(0, 32)}…`);
    console.error(`    actual: sha256-${got.slice(0, 32)}…`);
    console.error(`    → the vendored bundle changed. Run \`0html update\` intentionally, or restore it.`);
    bad = true;
  }

  const v = bundleVersions(src.toString());
  if (v.html !== lock.versions.compiler || v.bind !== lock.versions.runtime) {
    console.error(`✗ VERSION DRIFT  locked ${lock.versions.runtime}/${lock.versions.compiler}  actual ${v.bind}/${v.html}`);
    bad = true;
  }

  if (lock.toolchain) {
    for (const t of lock.toolchain) {
      const tp = path.join(SELF_DIR, t.file);
      if (!fs.existsSync(tp)) { console.error(` TOOLCHAIN MISSING  ${t.file}`); bad = true; continue; }
      const th = sha256(fs.readFileSync(tp));
      if (th === t.sha256) ok(`toolchain ${t.file} integrity OK`);
      else { console.error(` TOOLCHAIN DRIFT  ${t.file}  locked ${t.sha256.slice(0, 16)}  actual ${th.slice(0, 16)}`); bad = true; }
    }
  }

  // CycloneDX SBOM (if present): re-hash each component's file and confirm the
  // BOM isn't stale. A stale SBOM is a supply-chain lie — it would attest to
  // bytes that no longer ship. Catches "rebuilt bundle, forgot to regen SBOM."
  const sbomPath = path.join(path.dirname(bp), '0html.cdx.json');
  if (fs.existsSync(sbomPath)) {
    try {
      const bom = JSON.parse(fs.readFileSync(sbomPath, 'utf8'));
      const fileFor = {
        '0html.bundle.js': bp,
        '0bind': path.join(SELF_DIR, '0bind.js'),
        '0html-compiler': path.join(SELF_DIR, '0html.js'),
      };
      let ext = (bom.components || []).filter(c => typeof c.purl === 'string' && /^pkg:(npm|pypi|maven|gem|cargo|composer)\//i.test(c.purl));
      if (ext.length) { console.error(` SBOM: ${ext.length} external dependency component(s) present — expected 0`); bad = true; }
      for (const c of (bom.components || [])) {
        const fp = fileFor[c.name] || (c.type === 'file' ? path.join(SELF_DIR, c.name) : null);
        if (!fp || !fs.existsSync(fp)) continue;
        const want = (c.hashes || []).find(h => h.alg === 'SHA-256');
        if (!want) continue;
        const got = sha256hex(fs.readFileSync(fp));
        if (got === want.content) ok(`SBOM ${c.name} hash matches`);
        else { console.error(` SBOM STALE  ${c.name}  bom ${want.content.slice(0, 16)}  actual ${got.slice(0, 16)}`); bad = true; }
      }
    } catch (e) { console.error(` SBOM UNREADABLE  ${e.message}`); bad = true; }
  }

  if (file) {
    if (!fs.existsSync(file)) die(`file not found: ${file}`);
    const html = fs.readFileSync(file, 'utf8');
    const scripts = allModuleScripts(html);
    const base = path.basename(file);
    if (!scripts.length) {
      console.error(`✗ ${base}: no <script type="module"> found`);
      bad = true;
    } else {
      // 1. the tool must CARRY the code the checks above just verified
      const missing = toolCarriesLibrary(scripts);
      if (missing.length) {
        console.error(`✗ ${base}: TOOL DRIFT — inlined copy of ${missing.join(' + ')} is absent or altered`);
        console.error(`    the CSP hash only proves the script matches ITSELF; this proves it is the pinned library.`);
        console.error(`    → rebuild with ./build.sh, or run \`0html update ${file}\`.`);
        bad = true;
      } else {
        ok(`${base}: carries the pinned 0bind + 0html verbatim`);
      }
      // 2. EVERY inline script needs its own hash present — classic included
      const allScripts = allInlineScripts(html);
      if (!/'sha256-([A-Za-z0-9+/=]+)'/.test(html)) {
        console.error(`✗ ${base}: no CSP sha256 hash present`);
        bad = true;
      } else {
        let n = 0;
        for (const body of allScripts) {
          n++;
          const cspHash = sha256(Buffer.from(body, 'utf8'));
          if (!html.includes(`'sha256-${cspHash}'`)) {
            console.error(`✗ ${base}: CSP HASH MISSING/MISMATCH for inline script #${n} of ${allScripts.length}`);
            console.error(`    expected sha256-${cspHash.slice(0, 32)}…`);
            console.error(`    → enforce-mode CSP would BLOCK this script. Run \`0html update ${file}\`.`);
            bad = true;
          }
        }
        if (!bad) ok(`${base}: CSP hash matches all ${scripts.length} inline script(s) (loads under enforce)`);
      }
    }
  }

  if (bad) process.exit(1);
  ok('verify passed');
}

function injectBundle(html, bundle) {
  if (html.includes('/* __BUNDLE__ */')) {
    return html.replace('/* __BUNDLE__ */', () => bundle);
  }
  // no marker: insert a module script just before </head>
  const inject = `<script type="module">\n${bundle}\n</script>\n`;
  if (html.includes('</head>')) return html.replace('</head>', inject + '</head>');
  return inject + html; // last resort
}

function refreshCspHash(html) {
  const body = lastModuleScript(html);
  if (!body) return { html, hash: null };
  const hash = sha256(Buffer.from(body, 'utf8'));
  // replace an existing sha256 in a script-src, or a placeholder
  if (html.includes("'SHA256-PLACEHOLDER'")) {
    html = html.replace("'SHA256-PLACEHOLDER'", `'sha256-${hash}'`);
  } else {
    // swap the first sha256 that is NOT already our hash (best-effort for single-script tools)
    html = html.replace(/'sha256-[A-Za-z0-9+/=]+'/, `'sha256-${hash}'`);
  }
  return { html, hash };
}

function cmdAdd(file) {
  if (!file) die('usage: 0html add <file.html>');
  if (!fs.existsSync(file)) die(`file not found: ${file}`);
  const bp = findBundle();
  const bundle = fs.readFileSync(bp, 'utf8');
  let html = fs.readFileSync(file, 'utf8');

  html = injectBundle(html, bundle);
  const r = refreshCspHash(html);
  html = r.html;
  fs.writeFileSync(file, html);

  cmdPin(); // (re)write lock to the bundle we just vendored
  ok(`added 0html bundle to ${path.basename(file)}`);
  if (r.hash) ok(`CSP hash set: sha256-${r.hash.slice(0, 24)}…`);
  else console.log('  (no <script type="module"> to hash — add your tool code, then `0html update`)');
}

function cmdUpdate(file) {
  if (!file) die('usage: 0html update <file.html>');
  if (!fs.existsSync(file)) die(`file not found: ${file}`);
  // update = refresh CSP hash of whatever inline script is there now, refresh lock.
  let html = fs.readFileSync(file, 'utf8');
  const r = refreshCspHash(html);
  fs.writeFileSync(file, r.html);
  cmdPin();
  if (r.hash) ok(`${path.basename(file)}: CSP hash refreshed → sha256-${r.hash.slice(0, 24)}…`);
  else die('no <script type="module"> found to hash');
}

function cmdHash(file) {
  if (!file) die('usage: 0html hash <file.html>');
  const html = fs.readFileSync(file, 'utf8');
  const body = lastModuleScript(html);
  if (!body) die('no <script type="module"> found');
  console.log(`sha256-${sha256(Buffer.from(body, 'utf8'))}`);
}

// ── dispatch ────────────────────────────────────────────────────
const [cmd, arg] = process.argv.slice(2);
switch (cmd) {
  case 'pin':    cmdPin(); break;
  case 'sbom':   cmdSbom(); break;
  case 'verify': cmdVerify(arg); break;
  case 'add':    cmdAdd(arg); break;
  case 'update': cmdUpdate(arg); break;
  case 'hash':   cmdHash(arg); break;
  default:
    console.log(`0html v1.8.0 — the standard's adoption CLI

  0html add <file.html>      inline pinned bundle + set CSP hash + write lock
  0html verify [<file>]      check bundle + toolchain + SBOM integrity (and file CSP hash)
  0html update <file.html>   refresh CSP hash + lock after edits/upgrade
  0html pin                  write 0html.lock with bundle sha256 + versions + toolchain
  0html sbom                 write dist/0html.cdx.json (CycloneDX 1.6 SBOM)
  0html hash <file.html>     print the CSP sha256 of a file's module script
`);
    process.exit(cmd ? 1 : 0);
}
