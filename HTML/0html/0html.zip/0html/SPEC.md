# 0html Specification v1.0

**Status:** Stable
**Runtime:** 0bind v1.0
**License:** same as host project
**Design axis:** single-file, zero-dependency tools that treat UI as data.

---

## 0. Abstract

0html is a **JSON-first declarative UI format** and its reference compiler.
A user interface is expressed as a JSON value (the *spec*), compiled to real
DOM nodes through a hardened, allowlist-based compiler. No template strings,
no `innerHTML` of untrusted data, no code in the document. The format is
designed so a spec loaded from disk, a URL, or an LLM can be rendered under a
**hard security contract** without trusting its author.

Two layers:

- **0bind** — the runtime. Safe element builder (`el`), safe DOM sink
  (`setSafe`), delegated events (`on` / `data-on-*`), the single audited
  raw-HTML door (`trust`).
- **0html** — the JSON compiler on top. Turns spec objects into `el` calls,
  enforcing JSON-surface security (prototype safety, bounds, tag allowlist,
  handler opacity, double-gated HTML).

---

## 1. Why JSON is first-class

| Property | Consequence |
|---|---|
| UI is **serializable** | store layouts, ship themes, diff views, undo/redo |
| UI is **transmittable** | server or peer sends a view without sending code |
| UI is **inspectable** | lint/validate before mount; static analysis is trivial |
| UI is **untrusted-safe** | the format *assumes* the author is hostile |

That last row is the design center. A string-template UI (`innerHTML = \`...\``)
is only as safe as the author's discipline. A JSON spec compiled through an
allowlist is safe **by construction** — the compiler is the trust boundary,
not the author.

`el()` is the **runtime/compile target**. You *can* call `el()` directly, but
the canonical authoring surface is JSON.

---

## 2. The node grammar

A **node** is one of:

```
node       := string | number | boolean | null | element
element    := {
                "tag":      TagName,          // optional, default "div"
                "class":    string,           // optional (alias: "className")
                "id":       string,           // optional
                "attrs":    { AttrName: Scalar },   // optional
                "on":       { EventName: HandlerName },  // optional
                "arg":      Scalar,           // optional → ctx.arg
                // exactly one content form (priority: children > text > html):
                "children": [ node, ... ],    // optional
                "text":     string,           // optional
                "html":     TrustedHTML       // optional, DOUBLE-GATED
              }

TrustedHTML := { "$trust": string, "from": GeneratorName }
Scalar      := string | number | boolean
TagName     := one of ALLOWED_TAGS (§4)
AttrName    := /^[a-zA-Z_][a-zA-Z0-9_:-]*$/ , not matching /^on/i
EventName   := /^[a-zA-Z][a-zA-Z0-9_-]*$/
HandlerName := string   // looked up in 0bind registry; never eval'd
```

### 2.1 Content precedence

If multiple content forms appear, exactly one is used, in order:
**`children`** → **`text`** → **`html`**. Others are ignored. Authors SHOULD
supply only one. Conformant compilers MUST follow this precedence.

### 2.2 Scalars as text

`string`, `number`, `boolean` nodes become **text nodes**. `null` /
`undefined` become empty text. Text can never become markup (§3, I1).

---

## 3. Security contract (normative)

A conformant 0html compiler MUST enforce all invariants below. These extend
the 0bind runtime invariants I1–I4.

### Runtime invariants (0bind, inherited)

- **I1** — No caller/spec string is ever routed to `innerHTML`, `outerHTML`,
  `insertAdjacentHTML`, or a `javascript:` / `data:` sink.
- **I2** — Inline event-handler attributes (`on*`) are refused. Events flow
  only through the registry.
- **I3** — URL-bearing attributes (`href`, `src`, `action`, `poster`,
  `formaction`, `xlink:href`) are scheme-checked: `http`, `https`, `mailto`,
  `tel`, `ftp`, relative, and fragment URLs pass; all else is dropped.
  Control-character obfuscation (e.g. `java\tscript:`) is stripped before the
  check.
- **I4** — Raw HTML enters only through `trust()`, so `grep 'trust('`
  enumerates every raw-HTML write.

### JSON-surface invariants (0html)

- **J1 — Prototype safety.** Keys `__proto__`, `prototype`, `constructor` are
  dropped everywhere they appear in a spec (node keys, `attrs`, `on`). No spec
  can pollute `Object.prototype`. `fromJSON` additionally strips these during
  `JSON.parse` via a reviver (belt and suspenders).
- **J2 — Bounds.** `maxDepth` (default **64**) and `maxNodes` (default
  **10000**) are enforced. Exceeding either throws `RangeError` — a hostile
  deep-nest or breadth bomb is refused, never stack-overflowed or hung. Both
  tunable per `compile()`.
- **J3 — Tag allowlist.** Only tags in `ALLOWED_TAGS` (§4) render. `script`,
  `style`, `iframe`, `object`, `embed`, `link`, `meta`, `base`, and any
  unknown tag render as an **inert `<span data-0html-refused="...">`**
  placeholder (preserving layout position and safe children) plus a warning.
- **J4 — Handler names are opaque strings.** `on` values are exact-match
  looked up in the 0bind registry. A non-string handler is refused. A name
  with no registered handler renders inert (warns at dispatch). **Nothing
  from a spec is turned into code.**
- **J5 — Raw HTML is double-gated.** `html` renders only if **all** hold:
  1. it is shaped `{ "$trust": "...", "from": "<gen>" }`, **and**
  2. the caller passed `{ allowTrustedHTML: true }`, **and**
  3. `<gen>` is in the caller's `trustedGenerators` allowlist.

  Default is **OFF** — raw HTML from a JSON file is impossible unless the
  *tool author* explicitly opts in, per compile, naming which generators they
  vouch for. Even when fully gated, content is parsed via `<template>` so
  scripts do not execute.
- **J6 — Attribute namespace guard.** Attribute names are validated against a
  conservative charset and `on*` is refused at the JSON layer too (defense in
  depth over I2).
- **J7 — Trusted Types enforce compatibility.** The runtime operates under
  `require-trusted-types-for 'script'` without exception. It registers its own
  namespaced Trusted Types policy (`'0html'`, not `'default'`, so it coexists
  with a host page's default policy) whose `createHTML` is a passthrough — the
  only value reaching it is already escaped by the generator the author vouched
  for via `trust()` / `{$trust, from}`. The runtime registers **no**
  `createScript`/`createScriptURL` (it emits zero dynamic script), so those
  sinks stay closed. On browsers without Trusted Types the policy is absent and
  the sink falls back to a plain assignment — identical behavior either way.
  `bind.ttActive` reports whether a policy is active.

### 3.1 Threat model

| Threat | Defense |
|---|---|
| Stored/reflected XSS via UI data | I1, J3 — data is text or allowlisted tags only |
| Inline handler injection | I2, J4, J6 |
| `javascript:`/`data:` URL | I3 |
| Prototype pollution via crafted JSON | J1 + reviver |
| DoS via deep nesting / huge spec | J2 |
| Smuggled `<script>`/`<iframe>` | J3 |
| Raw-HTML injection from loaded file | J5 (off by default) |
| Handler-name → code execution | J4 (registry lookup, never eval) |
| Regressed sink under a hostile page | J7 + host CSP (`require-trusted-types-for`) |

**Defense in depth.** J1–J6 are *library* guarantees — they hold even with no
platform support. J7 lets those guarantees run **under** the platform's
strongest sink control (Trusted Types enforce mode) rather than being bypassed
by it. A tool that pairs 0html with the hardened starter (§10) gets both: the
compiler refuses unsafe specs, and the platform refuses unsafe sinks even if
the compiler ever regressed.

**Non-goals.** 0html does not sanitize *inside* trusted HTML — that is the
named generator's job (e.g. a markdown renderer that `_esc()`s). 0html does
not sandbox CSS; `style` is accepted only as a plain string, and authors must
not route untrusted values into it. 0html is not a permissions system for
what handlers *do* — it guarantees only that a spec cannot introduce new code
or new handlers, just reference existing ones by name.

---

## 4. ALLOWED_TAGS (normative)

Structure: `div span section article header footer main aside nav ul ol li dl
dt dd figure figcaption details summary`

Text: `p h1 h2 h3 h4 h5 h6 blockquote pre code em strong b i u s small sub sup
mark abbr time kbd samp var br hr a q cite`

Tables: `table thead tbody tfoot tr td th caption colgroup col`

Media (URLs scheme-checked): `img picture source video audio track svg path g
circle rect line polyline polygon text use`

Form controls: `form label input textarea select option optgroup button
fieldset legend datalist output progress meter`

> `form` is allowed but its `action` is scheme-checked and `submit` is
> auto-`preventDefault`ed by the delegation layer, so it cannot trigger a
> full-page navigation on its own.

Tags **not** in this set render inert. Extending the allowlist is a
compile-time decision for the tool author (fork the set); it is deliberately
**not** runtime-configurable from a spec.

---

## 5. Compiler API

```js
// Compile a spec → DOM Node. Never throws on bad specs (refuses + warns);
// throws RangeError only on J2 bound violations (those are attacks).
html0.compile(spec, opts?) → Node

// Compile + mount: safe-clear target, append compiled node.
html0.render(spec, targetEl, opts?) → targetEl

// Parse JSON text (pollution-safe reviver) then compile. For untrusted
// sources: files, URLs, LLM output.
html0.fromJSON(jsonText, opts?) → Node

// Dry run: compile detached, collect warnings without mounting.
html0.validate(spec, opts?) → { ok: boolean, warnings: string[], node: Node|null }
```

### 5.1 Options

| Option | Default | Meaning |
|---|---|---|
| `maxDepth` | `64` | J2 nesting bound |
| `maxNodes` | `10000` | J2 total-node bound |
| `allowTrustedHTML` | `false` | J5 master switch |
| `trustedGenerators` | `[]` | J5 generator-name allowlist |
| `onWarn` | `console.warn` | warning sink (used by `validate`) |

---

## 6. Events

```json
{ "tag": "button", "text": "Save", "on": { "click": "saveHandler" }, "arg": "rows" }
```

compiles to `<button data-on-click="saveHandler" data-arg="rows">Save</button>`.

```js
bind.init(document.body);            // once, at startup
bind.on('saveHandler', (e, el, ctx) => {
  // ctx = { arg: "rows", name: "saveHandler", type: "click", target, root }
});
```

One delegated listener per event type on the root handles the whole tree.
Handlers are registered in code; specs only *reference* them by name. This is
the security seam: a spec can wire a button to `"saveHandler"`, but cannot
*define* what `"saveHandler"` does, and cannot invoke anything not already
registered.

---

## 7. Trusted HTML (the one escape hatch)

For content produced by a **self-escaping generator** (a markdown renderer, a
syntax highlighter) the author may opt in per compile:

```js
html0.compile(spec, {
  allowTrustedHTML: true,
  trustedGenerators: ['markdown', 'syntaxHighlight'],
});
```

Spec:

```json
{ "tag": "div", "class": "md",
  "html": { "$trust": "<p>rendered <em>markdown</em></p>", "from": "markdown" } }
```

Rules the author MUST uphold:

1. The string in `$trust` MUST come from a generator that escapes user input
   before emitting HTML. 0html does not verify this — it verifies only that
   the author *named* an allowlisted generator.
2. Never place raw model output or user text directly in `$trust`.
3. Prefer `children`/`text` for everything that isn't generator output.

`grep '"$trust"'` in specs and `grep 'trust('` in code together enumerate
every raw-HTML surface in a tool.

---

## 8. Conformance

An implementation is **0html v1.1 conformant** iff:

- It accepts the §2 grammar and applies §2.1 precedence.
- It enforces every invariant in §3 (I1–I4, J1–J7).
- It renders exactly the §4 tag set (or a documented superset chosen at
  compile time, never spec-configurable).
- It exposes the §5 API surface and honors §5.1 defaults.
- It operates under Trusted Types enforce mode per J7.
- It passes the bundled suites: `0bind-test.cjs` (43, runtime),
  `0html-test.cjs` (63, compiler), `0bind-tt-test.cjs` (9, TT enforce) —
  **115 assertions total**.

---

## 9. Versioning

`major.minor.patch`. Security-invariant changes (adding/removing a J-rule,
tightening the tag allowlist) are **major**. New optional node keys or options
that default to prior behavior are **minor**. Bug fixes are **patch**. The
compiler exposes `version` and `runtime`.

> J7 was added in **1.1** as **minor** rather than major: it strictly widens
> where the runtime can operate (now including TT-enforced pages) without
> changing any existing behavior on non-TT pages, and adds no new spec surface.

Current: **0html 1.1.0** / runtime **0bind 1.1.0**.

---

## 10. Hardening (platform-level, from 0pdf-editor)

J1–J7 are the *library* contract. For a production single-file tool, pair them
with three platform defenses so a regressed sink can't become an exploit. The
bundled `0html-starter.html` ships all three pre-wired.

### 10.1 Trusted Types 'default' policy

Register **first**, before any other script, so it precedes every sink. Its
`createHTML` is a passthrough (0html and your generators already escape);
`createScript`/`createScriptURL` **throw**, closing dynamic-script sinks
platform-wide. 0html's own `'0html'` policy (J7) coexists — list both in the
`trusted-types` CSP directive.

```html
<script>
(function(){ try{ if(window.trustedTypes&&window.trustedTypes.createPolicy){
  window.trustedTypes.createPolicy('default',{
    createHTML:function(s){return s;},
    createScript:function(){throw new TypeError('TT: dynamic script blocked');},
    createScriptURL:function(){throw new TypeError('TT: dynamic script URL blocked');}
  });}}catch(e){} })();
</script>
```

### 10.2 Content-Security-Policy

Belt-and-suspenders. Even if a sink regressed, this blocks execution. Key
directives for a 0html tool:

```
default-src 'none';
script-src 'sha256-<hash-of-your-inline-script>' 'wasm-unsafe-eval';
style-src 'unsafe-inline';
img-src data: blob:;
connect-src 'self' https://your-gateway;
object-src 'none';
base-uri 'none';
form-action 'none';
worker-src 'none';
require-trusted-types-for 'script';
trusted-types default 0html;
```

- Keep **all** JS in one inline `<script type="module">` so exactly one hash is
  needed. `build.sh` computes and substitutes it automatically.
- `base-uri 'none'` + `object-src 'none'` + `form-action 'none'` close the
  tag-injection escape routes J3's allowlist also blocks — at the platform.
- Develop with `Content-Security-Policy-Report-Only` to see violations without
  breaking the page; switch to enforcing once the hash is set.

### 10.3 Frame protection

Meta CSP can't set `frame-ancestors`, so add a frame-buster script **and**
serve response headers:

```
Content-Security-Policy: frame-ancestors 'none'
X-Frame-Options: DENY
```

### 10.4 The combined guarantee

| Layer | Stops |
|---|---|
| 0html compiler (J1–J6) | unsafe *specs* — bad tags, handlers, URLs, pollution |
| Trusted Types (J7 + default policy) | unsafe *sinks* — any string→HTML/script path |
| CSP | *execution* — if a sink ever regressed anyway |
| Frame-bust + headers | *clickjacking* / UI redress |

A tool built on the starter refuses unsafe input at the compiler, refuses
unsafe sinks at the platform, and refuses execution at the CSP — three
independent layers, each sufficient alone for its class.
