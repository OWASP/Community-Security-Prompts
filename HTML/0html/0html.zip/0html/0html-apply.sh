#!/usr/bin/env sh
# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  0html-apply.sh — apply the review patch, build, test, verify            ║
# ╚══════════════════════════════════════════════════════════════════════════╝
#
#   ./0html-apply.sh [--patch FILE] [--no-test] [--yes]
#
# Run from a 0html package root. Idempotent: if the patch is already applied it
# skips straight to build + verify. Everything that produces bytes is done by
# 0build.cjs, which 0html-apply.ps1 also calls — one implementation, two entry
# points, no drift.
#
# Exit 0 only if the build, the suites and `verify` all pass.
set -eu

PATCH="0html-1.9.1-consolidated.patch"
RUN_TESTS=1
ASSUME_YES=0
while [ $# -gt 0 ]; do
  case "$1" in
    --patch) PATCH="$2"; shift 2 ;;
    --no-test) RUN_TESTS=0; shift ;;
    --yes|-y) ASSUME_YES=1; shift ;;
    -h|--help) sed -n '2,14p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "unknown option: $1" >&2; exit 2 ;;
  esac
done

say()  { printf '%s\n' "$*"; }
ok()   { printf '  \033[32m✓\033[0m %s\n' "$*"; }
warn() { printf '  \033[33m!\033[0m %s\n' "$*"; }
die()  { printf '  \033[31m✗\033[0m %s\n' "$*" >&2; exit 1; }

say ""
say "  0html — apply + build + verify"
say "  ────────────────────────────────────────────"

# ── preconditions ───────────────────────────────────────────────
[ -f 0bind.js ] && [ -f 0html.js ] || die "run this from a 0html package root (0bind.js not found)"

command -v node >/dev/null 2>&1 || die "node is required and was not found on PATH"
NODE_MAJOR=$(node -p "process.versions.node.split('.')[0]")
[ "$NODE_MAJOR" -ge 18 ] || die "node 18+ required (found $(node -v))"
ok "node $(node -v)"

if command -v python3 >/dev/null 2>&1; then
  ok "python3 — scanner differential enabled"
else
  warn "python3 not found — the differential vs html.parser will be SKIPPED"
fi

if node -e "require('playwright')" >/dev/null 2>&1; then
  ok "playwright — in-browser verification enabled"
else
  warn "playwright not found — 0browser-test will SKIP."
  warn "  that suite is what caught #35 (two security controls refused by the"
  warn "  page's own CSP). Consider making it a hard requirement in CI."
fi

# ── apply, if needed ────────────────────────────────────────────
CURRENT=$(node -p "(require('fs').readFileSync('0bind.js','utf8').match(/version: *'([0-9.]+)'/)||[])[1]||'?'" 2>/dev/null || echo '?')
if [ -f 0scan-html.cjs ] && [ -f 0csp-hashes.cjs ]; then
  ok "patch already applied (version $CURRENT) — rebuilding"
else
  [ -f "$PATCH" ] || die "patch not found: $PATCH   (use --patch FILE)"
  if [ "$ASSUME_YES" -ne 1 ]; then
    say ""
    say "  About to patch this tree (currently $CURRENT) with:"
    say "    $PATCH"
    printf "  Continue? [y/N] "
    read -r reply || reply=n
    case "$reply" in y|Y|yes|YES) : ;; *) die "aborted" ;; esac
  fi
  if command -v patch >/dev/null 2>&1; then
    patch -p1 --forward < "$PATCH" >/dev/null || die "patch failed to apply cleanly"
  elif command -v git >/dev/null 2>&1; then
    git apply "$PATCH" || die "git apply failed"
  else
    die "neither 'patch' nor 'git' found — cannot apply the patch"
  fi
  ok "patch applied"
  [ -f scanner-harness.cjs ] && { rm -f scanner-harness.cjs; ok "removed obsolete scanner-harness.cjs"; }
fi

# ── build ───────────────────────────────────────────────────────
say ""
say "  building"
# build.sh uses bash features ([[ ]]), so invoke bash explicitly rather than
# whatever /bin/sh happens to be — on Debian-likes that is dash, which fails.
if [ -f build.sh ]; then
  if command -v bash >/dev/null 2>&1; then SHELL_BIN=bash; else
    warn "bash not found — running 0build.cjs directly (build.sh needs bash)"
    node 0build.cjs || die "build failed"
    SHELL_BIN=""
  fi
  if [ -n "$SHELL_BIN" ]; then
    if [ "$RUN_TESTS" -eq 1 ]; then
      "$SHELL_BIN" build.sh --test || die "build/tests failed"
    else
      "$SHELL_BIN" build.sh || die "build failed"
    fi
  fi
else
  node 0build.cjs || die "build failed"
fi

# ── verify ──────────────────────────────────────────────────────
say ""
say "  verifying"
node 0html-cli.cjs verify >/dev/null || die "integrity verify failed"
ok "bundle + toolchain + SBOM integrity"
for t in dist/0html-starter.html dist/0scan.html; do
  [ -f "$t" ] || continue
  node 0html-cli.cjs verify "$t" >/dev/null || die "$t failed verification"
  ok "$t"
done

VER=$(node -p "(require('fs').readFileSync('0bind.js','utf8').match(/version: *'([0-9.]+)'/)||[])[1]" )
say ""
say "  ────────────────────────────────────────────"
ok "0html $VER — built, tested, verified"
say ""
say "  The shipped v1.8.0 dist/ artifacts did not execute at all (#15), so"
say "  rebuilding is mandatory, not optional. dist/ is now regenerated."
say ""
