#!/usr/bin/env node
/*
  0layers-test.cjs — regression suite for the layer engine (0html-layers.cjs).
  Runs the CLI end-to-end against generated fixtures. Covers L1, L2, L3, the
  handler converter, conformance/attestation, tiers, and multi-inline-script.
*/
'use strict';
const { execFileSync } = require('child_process');
const fs = require('fs'), os = require('os'), path = require('path');
const ENGINE = path.join(__dirname, '0html-layers.cjs');
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), '0layers-'));
let pass = 0, fail = 0;
const ck = (n, c) => c ? (pass++, console.log('  \u2713 ' + n)) : (fail++, console.log('  \u2717 ' + n));
function run(args) { try { return { out: execFileSync('node', [ENGINE, ...args], { encoding: 'utf8' }), code: 0 }; } catch (e) { return { out: (e.stdout || '') + (e.stderr || ''), code: e.status || 1 }; } }
let n = 0;
const fx = html => { const p = path.join(TMP, 'f' + (++n) + '.html'); fs.writeFileSync(p, html); return p; };
const read = p => fs.readFileSync(p, 'utf8');
const scriptSrc = h => (h.match(/script-src[^;"]*/) || [''])[0];
const CSP_STRONG = `<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'self' 'unsafe-inline'; object-src 'none'; base-uri 'self'; form-action 'none'">`;
const CSP_MIN = `<meta http-equiv="Content-Security-Policy" content="script-src 'self' 'unsafe-inline'">`;
const wrap = (head, body) => `<!doctype html><html><head>${head}</head><body>${body}</body></html>`;

console.log('-- L1: CSP baseline directives --');
{ const f = fx(wrap(CSP_STRONG, '')); run(['apply', f, '--layers=1']); const h = read(f);
  ck('adds frame-ancestors', /frame-ancestors 'none'/.test(h));
  ck('preserves pre-existing object-src', /object-src 'none'/.test(h));
  run(['apply', f, '--layers=1']); ck('idempotent re-apply is safe', run(['conformance', f]).code === 0);
  run(['unapply', f, '--layer=1']); const h2 = read(f);
  ck('unapply removes ONLY the added directive', !/frame-ancestors/.test(h2) && /object-src 'none'/.test(h2) && /base-uri 'self'/.test(h2)); }
{ const f = fx(wrap(CSP_MIN, '')); run(['apply', f, '--layers=1']); const dirs = (scriptSrc(read(f)), read(f));
  const has = d => new RegExp(d).test(dirs);
  ck('weak CSP gets all 4 baseline directives', ['frame-ancestors', 'base-uri', 'object-src', 'form-action'].every(has)); }
{ const f = fx('<!doctype html><head></head><body></body>'); ck('no-CSP target is blocked (nonzero exit)', run(['apply', f, '--layers=1']).code !== 0); }

console.log('-- L2: hash-pin + drop unsafe-inline --');
{ const f = fx(wrap(CSP_STRONG, '<script type="module">boot(1);</script>')); run(['apply', f, '--layers=2']); const ss = scriptSrc(read(f));
  ck("removes 'unsafe-inline'", !/unsafe-inline/.test(ss));
  ck('adds a sha256 hash', /'sha256-[A-Za-z0-9+/=]+'/.test(ss));
  ck("keeps 'self'", /'self'/.test(ss));
  ck('conformant right after pin', run(['conformance', f]).code === 0);
  const h = read(f).replace('boot(1)', 'boot(2)'); fs.writeFileSync(f, h);   // simulate a rebuild
  ck('STALE HASH after script change → DRIFT (exit 1)', run(['conformance', f]).code !== 0); }
{ const f = fx(wrap(CSP_MIN, '<script>x=1;</script>')); run(['apply', f, '--layers=2']); run(['unapply', f, '--layer=2']); const ss = scriptSrc(read(f));
  ck("unapply restores 'unsafe-inline' + drops the hash", /unsafe-inline/.test(ss) && !/sha256-/.test(ss)); }
{ const f = fx(wrap(CSP_MIN, '<button onclick="go()">x</button><script>function go(){}</script>')); const r = run(['apply', f, '--layers=2']);
  ck('L2 blocks on inline handler (safety gate)', /inline on. handler|blocked/.test(r.out) && /unsafe-inline/.test(scriptSrc(read(f)))); }

console.log('-- L2 multi-inline-script (robustness) --');
{ const f = fx(wrap(CSP_MIN, '<script>a();</script><script type="module">b();</script><script>c();</script>')); run(['apply', f, '--layers=2']);
  const ss = scriptSrc(read(f)); const hashes = (ss.match(/'sha256-[A-Za-z0-9+/=]+'/g) || []);
  ck('hash-pins ALL 3 inline scripts (3 hashes in script-src)', hashes.length === 3);
  ck('multi-script: unsafe-inline removed', !/unsafe-inline/.test(ss));
  ck('multi-script conformant', run(['conformance', f]).code === 0);
  const h = read(f).replace('b();', 'b();b2();'); fs.writeFileSync(f, h);
  ck('multi-script: changing ONE script → drift', run(['conformance', f]).code !== 0); }

console.log('-- L3: Trusted Types report-only + L2 composition --');
{ const f = fx(wrap(CSP_STRONG, '<script>go();</script>')); run(['apply', f, '--layers=3']); const h = read(f);
  ck('adds a Report-Only meta with require-trusted-types-for', /Content-Security-Policy-Report-Only/.test(h) && /require-trusted-types-for/.test(h));
  ck('does NOT touch the enforcing CSP', /script-src 'self' 'unsafe-inline'/.test(h));
  run(['unapply', f, '--layer=3']); ck('unapply removes the Report-Only meta', !/Report-Only/.test(read(f))); }
{ const f = fx(wrap(CSP_STRONG.replace(" 'unsafe-inline'", ''), '<script>run(9);</script>'));
  // pin then add L3, assert L2 hash unchanged (composition)
  run(['apply', f, '--layers=2']); const h1 = (read(f).match(/'sha256-[A-Za-z0-9+/=]+'/) || [''])[0];
  run(['apply', f, '--layers=3']); const h2 = (read(f).match(/'sha256-[A-Za-z0-9+/=]+'/) || [''])[0];
  ck('L2 hash UNCHANGED after L3 (layers compose, no re-hash)', h1 === h2 && h1 !== '');
  ck('L2+L3 both conformant', run(['conformance', f]).code === 0); }

console.log('-- handler converter (L2 prerequisite) --');
{ const f = fx(wrap(CSP_MIN, '<button onclick="save()">S</button><div onmouseover="h(this)" onclick="p()">d</div><a onclick="go(\'x &amp;&amp; y\')">l</a>'));
  const r = run(['convert-handlers', f]); const h = read(f);
  ck('removes inline on* attributes', !/ on(click|mouseover)=/.test(h));
  ck('adds data-0h hooks', /data-0h="1"/.test(h) && /data-0h="2"/.test(h));
  ck('injects a wiring script', /inline handlers converted to addEventListener/.test(h));
  ck('decodes HTML entities in the wiring (&& not &amp;&amp;)', /go\('x && y'\)/.test(h));
  ck('multi-handler element gets both listeners', (h.match(/q\('2'\)/g) || []).length === 2);
  // wiring script is valid JS
  const m = h.match(/\/\* 0html: inline[\s\S]*?<\/script>/); fs.writeFileSync(path.join(TMP, 'wire.js'), m[0].replace('</script>', ''));
  let wireValid = false; try { execFileSync('node', ['--check', path.join(TMP, 'wire.js')]); wireValid = true; } catch {}
  ck('wiring script is valid JS', wireValid);
  // the payoff: L2 now applies
  ck('L2 succeeds after conversion (was blocked)', run(['apply', f, '--layers=2']).code === 0 && !/unsafe-inline/.test(scriptSrc(read(f)))); }
{ const orig = wrap(CSP_MIN, '<button onclick="save()">S</button>'); const f = fx(orig);
  run(['convert-handlers', f]); run(['restore-handlers', f]); const h = read(f);
  ck('restore re-adds on* handlers', / onclick="save\(\)"/.test(h));
  ck('restore removes data-0h + wiring', !/data-0h/.test(h) && !/inline handlers converted/.test(h)); }

console.log('-- conformance / attestation --');
{ const f = fx(wrap(CSP_STRONG, '')); run(['apply', f, '--layers=1']); const r = run(['conformance', f, '--json']);
  const rep = JSON.parse(r.out);
  ck('report lists adopted layers', rep.adopted.includes('L1'));
  ck('report has a sha256 attestation', /^[0-9a-f]{64}$/.test(rep.sha256));
  ck('report is conformant + exit 0', rep.conformant === true && r.code === 0);
  fs.writeFileSync(f, read(f).replace(/;?\s*frame-ancestors 'none'/, '')); // tamper
  ck('tamper → NON-conformant + exit 1', run(['conformance', f, '--json']).code !== 0); }

console.log('-- update (build-hook re-pin) --');
{ const f = fx(wrap(CSP_MIN, '<script>build(1);</script>')); run(['apply', f, '--layers=2']);
  fs.writeFileSync(f, read(f).replace('build(1)', 'build(2)'));   // simulate a rebuild
  ck('stale hash after rebuild → drift', run(['conformance', f]).code !== 0);
  run(['update', f]);
  ck('update re-pins → conformant again', run(['conformance', f]).code === 0);
  ck('re-pin leaves exactly one hash (no accumulation)', (scriptSrc(read(f)).match(/'sha256-[A-Za-z0-9+/=]+'/g) || []).length === 1); }

console.log('-- L4: Trusted Types enforce (default policy) --');
{ const CSPu = `<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'self' 'unsafe-inline'; object-src 'none'">`;
  const f = fx(wrap(CSPu, '<script type="module">app();</script>'));
  run(['apply', f, '--layers=4']);
  ck('L4 adds default TT policy shim', read(f).includes('0html: default Trusted Types policy'));
  ck('L4 pulls in L3 prereq (report-only)', read(f).includes('Content-Security-Policy-Report-Only'));
  ck('L4 conformant (detect done)', run(['conformance', f]).code === 0); }
{ const CSPu = `<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'self' 'unsafe-inline'; object-src 'none'">`;
  const f = fx(wrap(CSPu, '<script type="module">app();</script>'));
  run(['apply', f, '--layers=2,4']);
  ck('L4 re-pins L2: app script + shim both hashed (2)', (scriptSrc(read(f)).match(/'sha256-[A-Za-z0-9+/=]+'/g) || []).length === 2);
  ck('L2+L3+L4 all conformant', run(['conformance', f]).code === 0);
  run(['unapply', f, '--layer=4']);
  ck('unapply L4 removes shim + re-pins to 1 hash', !read(f).includes('default Trusted Types') && (scriptSrc(read(f)).match(/'sha256-[A-Za-z0-9+/=]+'/g) || []).length === 1); }

console.log('-- L5: connect-src allowlist (app-aware) --');
{ const CSP_OPEN = `<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'self'; connect-src *; object-src 'none'">`;
  const f = fx(wrap(CSP_OPEN, ''));
  ck('L5 blocks without --origins', run(['apply', f, '--layers=5']).code !== 0 && read(f).includes('connect-src *'));
  run(['apply', f, '--layers=5', '--origins=https://api.example.com']);
  const cs = (read(f).match(/connect-src[^;"]*/) || [''])[0];
  ck('L5 scopes connect-src (drops *, adds origin + self)', !cs.includes('*') && cs.includes('https://api.example.com') && cs.includes("'self'"));
  ck('L5 conformant after scoping', run(['conformance', f]).code === 0);
  run(['unapply', f, '--layer=5']);
  ck('L5 unapply restores connect-src *', read(f).includes('connect-src *')); }

console.log('-- tiers --');
{ const f = fx(wrap(CSP_STRONG, '<script>go();</script>')); run(['apply', f, '--tier=recommended']);
  const rep = JSON.parse(run(['conformance', f, '--json']).out);
  ck('recommended tier adopts L1, L2, L3', ['L1', 'L2', 'L3'].every(x => rep.adopted.includes(x))); }

console.log('-- converter: return-false idiom (from 0ui dogfood) --');
{ const f = fx(wrap(CSP_MIN, '<form onsubmit="return false"><button>go</button></form><script>x=1;</script>'));
  run(['convert-handlers', f]); const h = read(f);
  ck('return false -> event.preventDefault() in wiring', h.includes('if(_r===false)event.preventDefault()'));
  ck('onsubmit attribute removed', !h.includes('onsubmit=')); }

console.log('-- L8: style-src hardening --');
{ const CSPs = `<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; object-src 'none'">`;
  const f = fx(`<!doctype html><html><head>${CSPs}<style>.a{color:red}</style></head><body>ok</body></html>`);
  run(['apply', f, '--layers=8']);
  const ss = (read(f).match(/style-src[^;"]*/) || [''])[0];
  ck('L8 drops style-src unsafe-inline + pins <style>', !ss.includes('unsafe-inline') && ss.includes('sha256-'));
  ck('L8 conformant after pin', run(['conformance', f]).code === 0);
  fs.writeFileSync(f, read(f).replace('color:red', 'color:blue'));
  ck('L8 changed <style> → drift', run(['conformance', f]).code !== 0); }
{ const CSPs = `<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'self' 'unsafe-inline'">`;
  const f = fx(`<!doctype html><html><head>${CSPs}<style>.a{x:y}</style></head><body><div style="color:red">x</div></body></html>`);
  ck('L8 blocks on inline style= attr', run(['apply', f, '--layers=8']).code !== 0 && read(f).includes("'unsafe-inline'")); }

console.log('-- survey security notes --');
{ const weak = fx('<!doctype html><head><meta http-equiv=\"Content-Security-Policy\" content=\"default-src *; script-src \'self\' \'unsafe-eval\'; img-src *\"><script src=\"https://cdn.x/a.js\"></script></head><body>x</body>');
  const out = run(['layers', weak]).out;
  ck('notes flag unsafe-eval (HIGH)', /unsafe-eval/.test(out));
  ck('notes flag external without SRI', /without SRI/.test(out));
  ck('notes flag missing frame-ancestors', /missing frame-ancestors/.test(out)); }

console.log('-- audit-sri (external resource integrity) --');
{ const f = fx('<!doctype html><head><script src=\"https://cdn.x/a.js\"></script></head><body>x</body>');
  const r = run(['audit-sri', f]);
  ck('audit-sri flags external script without SRI (exit 1)', /NO integrity/.test(r.out) && r.code === 1); }
{ const f = fx('<!doctype html><head></head><body><script>a()</script></body>');
  ck('audit-sri: self-contained is clean', /self-contained/.test(run(['audit-sri', f]).out)); }
{ const f = fx('<!doctype html><head><script src=\"./x.js\" integrity=\"sha384-BADbadBADbadBADbadBADbadBADbadBADbadBADbadBADbadBADbadBADbadBADba\"></script></head><body>x</body>');
  require('fs').writeFileSync(require('path').join(require('path').dirname(f),'x.js'),'console.log(1)');
  ck('audit-sri detects SRI mismatch (tampered)', /MISMATCH/.test(run(['audit-sri', f]).out)); }

console.log('-- L6 audit-secrets (advisory) --');
{ const f = fx(wrap('', '<script>localStorage.setItem(\"apiKey\", k); localStorage.setItem(\"theme\",\"x\");</script>'));
  ck('L6 flags secret-storage sites', /secret-storage site/.test(run(['audit-secrets', f]).out));
  const f2 = fx(wrap('', '<script>localStorage.setItem(\"theme\",\"x\");</script>'));
  ck('L6 clean on benign storage', /no obvious/.test(run(['audit-secrets', f2]).out)); }

console.log('-- security-review fixes --');
{ const CSPu = `<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'self' 'unsafe-inline'; object-src 'none'">`;
  const f = fx(wrap(CSPu, '<script>a();</script>'));
  run(['apply', f, '--layers=4']);
  ck('L4 default policy BLOCKS string->script (createScript throws)', read(f).includes('string-to-script blocked')); }
{ const CSPo = `<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'self'; connect-src *; object-src 'none'">`;
  const f = fx(wrap(CSPo, ''));
  ck('L5 rejects wildcard origin', run(['apply', f, '--layers=5', '--origins=https://*.evil.com']).code !== 0);
  ck('L5 accepts a valid origin', run(['apply', f, '--layers=5', '--origins=https://api.ok.com']).code === 0); }
{ const f = fx(wrap(CSP_STRONG, ''));
  ck('conformance --require fails when minimum not met', run(['conformance', f, '--require=1,2,3']).code !== 0);
  run(['apply', f, '--layers=1']);
  ck('conformance --require passes when required layer adopted', run(['conformance', f, '--require=1']).code === 0); }

try { fs.rmSync(TMP, { recursive: true, force: true }); } catch {}
console.log(`\n  ${pass} passed, ${fail} failed`);
process.exit(fail > 0 ? 1 : 0);
