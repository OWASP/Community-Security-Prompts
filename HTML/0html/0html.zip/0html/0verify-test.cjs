// 0verify-test.cjs — what `0html verify <file>` actually attests.
//
// Every other check in verify runs against files sitting NEXT TO THE CLI
// (dist/0html.bundle.js, the toolchain, the SBOM). The tool's own CSP hash is
// computed from the tool's own inline script, so it is self-consistent by
// construction. Nothing bound the two together — a single-file tool with the
// library gutted out and the hash recomputed passed with "verify passed", and
// a build that mangled the inlined source shipped undetected for six releases.
//
// These lock the binding down. Drives the REAL CLI via execFile, so it tests
// the shipped code path. Requires a prior build. Run: node 0verify-test.cjs
'use strict';
const fs = require('fs'), path = require('path'), os = require('os'), crypto = require('crypto');
const { execFileSync } = require('child_process');

const DIR = __dirname;
const CLI = path.join(DIR, '0html-cli.cjs');
const STARTER = path.join(DIR, 'dist', '0html-starter.html');

let pass = 0, fail = 0;
const ok = (n, c) => { const g = !!c; console.log(`${g ? '✓' : '✗ FAIL'} ${n}`); g ? pass++ : fail++; };

const b64 = (s) => crypto.createHash('sha256').update(Buffer.from(s, 'utf8')).digest('base64');
const scripts = (html) => [...html.matchAll(/<script\s+type="module"\s*>([\s\S]*?)<\/script/g)].map((m) => m[1]);

// run verify, return { code, out }
const verify = (file) => {
  try {
    const out = execFileSync('node', [CLI, 'verify', file], { cwd: DIR, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] });
    return { code: 0, out };
  } catch (e) {
    return { code: e.status, out: (e.stdout || '') + (e.stderr || '') };
  }
};

// Write a variant of the starter into a temp file, re-hashing the CSP so the
// self-consistency check still passes — isolating the binding check.
const variant = (mutate) => {
  const src = fs.readFileSync(STARTER, 'utf8');
  const html = mutate(src);
  const p = path.join(os.tmpdir(), `verify-${process.pid}-${Math.random().toString(36).slice(2)}.html`);
  fs.writeFileSync(p, rehash(html));
  return p;
};

// Rebuild the WHOLE script-src hash set from the document. Re-hashing by
// replacing the first 'sha256-…' worked only while modules were the only thing
// hashed; since #35 the classic TT bootstrap and frame-buster are hashed too, so
// that clobbered a legitimate hash and every variant failed for the wrong
// reason. Uses the shared emitter, i.e. the same rule build.sh and verify use.
const allHashes = require(path.join(DIR, '0csp-hashes.cjs')).hashesFor;
function rehash(html) {
  const list = allHashes(html).join(' ');
  return html.replace(/'sha256-[A-Za-z0-9+/=]+'(?:\s+'sha256-[A-Za-z0-9+/=]+')*/, list);
}

if (!fs.existsSync(STARTER)) {
  console.error('0verify-test: dist/0html-starter.html missing — run ./build.sh first');
  process.exit(1);
}

console.log('── baseline ──');
{
  const r = verify(STARTER);
  ok('a real built tool passes', r.code === 0);
  ok('and says so explicitly', /carries the pinned 0bind \+ 0html verbatim/.test(r.out));
}

console.log('\n── the tool must carry the pinned library ──');
{
  // library gutted, replaced with a stub that sanitizes nothing
  const p = variant((h) => {
    const m = /(<script\s+type="module"\s*>)([\s\S]*?)(<\/script)/.exec(h);
    const stub = "\nwindow.html0 = { compile: (s) => s, render: () => {}, version: '1.8.1' };\n";
    return h.slice(0, m.index + m[1].length) + stub + h.slice(m.index + m[1].length + m[2].length);
  });
  const r = verify(p);
  ok('gutted library → verify FAILS', r.code === 1);
  ok('and names it TOOL DRIFT', /TOOL DRIFT/.test(r.out));
  fs.unlinkSync(p);
}
{
  // one byte changed inside the inlined library — the escape-mangling case
  const p = variant((h) => h.replace("const MAX_STYLE_LEN = 4096;", "const MAX_STYLE_LEN = 4096000;"));
  const r = verify(p);
  ok('altered inlined library → verify FAILS', r.code === 1);
  ok('and names it TOOL DRIFT', /TOOL DRIFT/.test(r.out));
  fs.unlinkSync(p);
}
{
  // cosmetic edit OUTSIDE the inline script must still pass
  const p = variant((h) => h.replace('</body>', '<!-- vendored 2026-07 -->\n</body>'));
  const r = verify(p);
  ok('edit outside the script still passes', r.code === 0);
  fs.unlinkSync(p);
}

console.log('\n── EVERY inline script is hashed — classic ones too (#35) ──');
{
  // add a script AND remove its hash — variant() now rehashes correctly, so the
  // unhashed condition has to be constructed rather than fallen into.
  const extra = 'console.log("second script");';
  let html = fs.readFileSync(STARTER, 'utf8').replace('</body>', `<script type="module">${extra}</script>\n</body>`);
  html = rehash(html).replace(` 'sha256-${b64(extra)}'`, '');
  const p = path.join(os.tmpdir(), `verify-unhashed-${process.pid}.html`);
  fs.writeFileSync(p, html);
  const r = verify(p);
  ok('an unhashed inline script → verify FAILS', r.code === 1);
  ok('and reports which script', /inline script #\d+ of \d+/.test(r.out));
  fs.unlinkSync(p);
}
{
  // both scripts hashed → passes
  const src = fs.readFileSync(STARTER, 'utf8');
  const extra = 'console.log("second script");';
  let html = src.replace('</body>', `<script type="module">${extra}</script>\n</body>`);
  html = rehash(html);
  const p = path.join(os.tmpdir(), `verify-both-${process.pid}.html`);
  fs.writeFileSync(p, html);
  const r = verify(p);
  ok('both scripts hashed → passes', r.code === 0);
  ok('and counts them', /all \d+ inline script\(s\)/.test(r.out));
  fs.unlinkSync(p);
}

console.log('\n── a stale CSP hash is still caught ──');
{
  const src = fs.readFileSync(STARTER, 'utf8');
  const p = path.join(os.tmpdir(), `verify-stale-${process.pid}.html`);
  fs.writeFileSync(p, src.replace(/'sha256-[A-Za-z0-9+/=]+'/, "'sha256-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA='"));
  const r = verify(p);
  ok('stale hash → verify FAILS', r.code === 1);
  ok('and says CSP HASH MISMATCH', /CSP HASH (MISSING\/)?MISMATCH/.test(r.out));
  fs.unlinkSync(p);
}

console.log('\n' + '─'.repeat(40));
console.log(`  ${pass} passed, ${fail} failed  (verify ↔ tool binding)`);
console.log('─'.repeat(40));
process.exit(fail ? 1 : 0);
