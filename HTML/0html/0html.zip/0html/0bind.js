// ╔═══════════════════════════════════════════════════════════════╗
// ║  0bind.js — Declarative binding + safe-DOM layer for 0ui       ║
// ║  Zero-dependency. Shares module scope (concat build).          ║
// ║  v1.8.0 — advise()/presets (detect-and-ask); safe SVG (I9);    ║
// ║           CycloneDX SBOM tooling; log-injection guard (I7)     ║
// ║           input/attr DoS caps (J9/J10), SVG-namespace note;    ║
// ║           style/CSS-injection guard, URL backslash-fold,       ║
// ║           value-length cap, frozen API (I5/I6/I3e)             ║
// ╚═══════════════════════════════════════════════════════════════╝
//
// WHY THIS EXISTS
// ---------------
// 0ui has 45 innerHTML sites and 173 hand-wired addEventListener calls.
// Escaping today is correct but scattered — one forgotten htmlEsc() is
// an XSS. 173 listeners is boilerplate and a CSP-adjacent surface.
//
// 0bind fixes the *structure*, not just the symptoms:
//   1. A SAFE DOM SINK (el / frag / setSafe) that makes the correct
//      path the easy path — text is text, never markup, by construction.
//   2. ONE delegated event dispatcher (data-on-* attributes) so new UI
//      needs zero addEventListener calls and zero inline handlers.
//   3. This is the "htmx feeling" WITHOUT htmx's swap-untrusted-HTML
//      trust model. Nothing here ever assigns attacker-influenced HTML.
//
// SECURITY INVARIANTS (do not break these):
//   I1. No function here ever routes a caller string into innerHTML,
//       outerHTML, insertAdjacentHTML, or a javascript:/data: URL sink.
//   I2. Attribute names/values from data are set via setAttribute only,
//       and event-handler attributes (on*) are refused outright.
//   I3. href/src/action values are scheme-checked; only http(s), mailto,
//       tel, and relative URLs pass. Everything else is dropped.
//   I4. Trusted HTML (your own syntaxHighlight/renderMarkdown output,
//       which self-escape) enters ONLY through the explicit `trust()`
//       wrapper, so every raw-HTML sink is greppable as trust(...).
//   I5. Inline `style` strings are sanitized: expression()/behavior/-moz-
//       binding/@import and url(javascript:) are refused, and every url()
//       must be same-origin/relative or a safe data:image (never data:svg,
//       and never an off-origin beacon). Prevents CSS-based script + exfil.
//   I6. Single attribute values are length-capped (memory-abuse backstop that
//       structural node-count bounds don't cover).
//   I7. Warning/log messages run untrusted values through logSafe() first:
//       CR/LF + control chars are neutralized so a rejected URL/tag/attr can't
//       forge extra log lines (CWE-117 log injection) in a downstream SIEM.
//   I8. Same-origin URL policy (opt-in): in 'same-origin' mode, href/src/srcset
//       values must resolve to the base origin (or an allow-listed origin);
//       protocol-relative and cross-origin URLs are refused. Off by default.
//   I9. Safe SVG (opt-in): SVG tags render in the SVG namespace ONLY when the
//       compiler marks them, through a dedicated allowlist of safe elements +
//       attributes with a url() paint-ref gate. foreignObject/animate/script/
//       image/<a>/<style> are excluded. Off by default (tags stay inert).

'use strict';

const OUI_BIND = (() => {

  // ── I7: log-injection guard (CWE-117) ──────────────────────────
  // Every warning below interpolates ATTACKER-CONTROLLED text (a rejected URL,
  // tag, attr name, style, handler/generator name). Those values can carry
  // CR/LF + control chars that forge extra log lines once console output is
  // shipped to a SIEM/aggregator. logSafe() neutralizes the interpolated value:
  // control chars (incl. CR/LF/tab) → '·', collapse to one line, cap length.
  // Purely a logging-hygiene control — it never affects what is rendered.
  const logSafe = (v, max = 120) => {
    let s = String(v).replace(/[\u0000-\u001F\u007F-\u009F]/g, '·');
    return s.length > max ? s.slice(0, max) + '…' : s;
  };

  // ── Scheme allowlist for URL-bearing attributes ────────────────
  // Matches markdown.js's posture: block javascript:, data:, vbscript:,
  // and control-char-obfuscated variants. Relative URLs pass.
  const SAFE_URL_RE = /^(?:https?:|mailto:|tel:|ftp:)/i;
  const isSafeUrl = (v) => {
    if (v == null) return false;
    // Strip ASCII control chars (incl. tab/newline) used to smuggle
    // "java\tscript:" past naive checks, then trim leading space.
    // I3e: also fold backslashes to forward slashes BEFORE any check. Browsers
    // treat "\" as "/" in the authority, so "/\evil.com" and "\\evil.com"
    // resolve to the protocol-relative "//evil.com". Folding first stops a
    // backslash from disguising a cross-origin host as an innocent relative path.
    const s = String(v)
      .replace(/[\u0000-\u001F\u007F-\u009F]/g, '')
      .replace(/\\/g, '/')
      .trim();
    if (s === '') return false;
    // Relative or fragment/anchor URLs are safe (no scheme). Note: "//host" is
    // protocol-relative (cross-origin) but non-executable; it passes here as it
    // always has. CSS url() is held to the stricter isCssUrlSafe() below, since
    // a background load is a silent GET and thus an exfil channel.
    if (/^[#/?.]/.test(s) || !/^[a-z][a-z0-9+.-]*:/i.test(s)) return true;
    return SAFE_URL_RE.test(s);
  };

  // ── I5 helper: is a URL safe INSIDE a CSS url(...) ? ────────────
  // Stricter than isSafeUrl: in CSS a url() fetch happens with no user action,
  // so an off-origin URL is a silent beacon (data-exfil / tracking). Allow only
  // relative / same-document refs and safe raster data:image (NEVER data:svg,
  // which can carry script). Any explicit scheme or protocol-relative → refuse.
  const CSS_DATA_IMG_RE = /^data:image\/(?:png|jpe?g|gif|webp);base64,[a-z0-9+/=\s]+$/i;
  const isCssUrlSafe = (u) => {
    const raw = String(u == null ? '' : u);
    // I5a: in CSS a backslash is an ESCAPE INTRODUCER, not a path separator.
    // The I3e fold ("\" → "/") is correct for URL *attributes* (browsers treat
    // "\" as "/" in an authority) but inverted here: it turns "\2f\2f evil.com"
    // — which the CSS parser unescapes to "//evil.com" — into "/2f/2f evil.com",
    // i.e. an innocent-looking rooted path. No legitimate same-origin url() or
    // base64 data:image needs a backslash, so refuse outright (fail closed).
    if (/\\/.test(raw)) return false;
    const s = raw
      .replace(/[\u0000-\u001F\u007F-\u009F]/g, '')
      .trim();
    if (s === '') return false;
    if (CSS_DATA_IMG_RE.test(s)) return true;   // inline raster, no script
    if (/^\/\//.test(s)) return false;          // protocol-relative = off-origin
    // relative / same-document only; reject anything carrying a scheme.
    return /^[#/?.]/.test(s) || !/^[a-z][a-z0-9+.-]*:/i.test(s);
  };

  // ── I5: inline-style CSS-injection guard ───────────────────────
  // A style STRING from an untrusted spec can still carry ACTIVE CSS:
  //   expression(…) / url(javascript:…)         → script (legacy engines)
  //   -moz-binding:url(…) / behavior:url(…)      → script (legacy FF/IE)
  //   @import url(…)                             → pulls remote CSS
  //   url(//evil/beacon?leak)                    → silent off-origin GET = exfil
  // The hard-banned constructs have no legitimate use in a hostile-author tool
  // and are refused outright; every url() must pass isCssUrlSafe(). Overlay
  // redressing (position:fixed;inset:0) can't be judged by value and is left as
  // a documented residual. Returns the (unchanged) safe string, or null to drop.
  const MAX_STYLE_LEN = 4096;
  const CSS_HARD_BAN =
    /(?:expression\s*\(|javascript\s*:|vbscript\s*:|-moz-binding|behaviou?r\s*:|@import|[<>])/i;
  // I5b: CSS escape de-obfuscation. The comment strip below stops
  // "expr/**/ession(" — but escapes are the same class of dodge and were not
  // covered: "\75 rl(" tokenizes as url( and "\6a avascript:" as javascript:,
  // so a scan of the RAW text finds neither the banned token nor any url() to
  // gate. Decode into the scanning copy only; the returned value is untouched.
  const decomment = (s) => s.replace(/\/\*[\s\S]*?\*\//g, '');
  const cssUnescape = (s) => s
    .replace(/\\(?:\r\n|[\n\r\f])/g, '')                       // line continuation
    .replace(/\\([0-9a-fA-F]{1,6})[ \t\r\n\f]?/g, (_, h) => {
      const cp = parseInt(h, 16);
      return (!cp || cp > 0x10FFFF) ? '\uFFFD' : String.fromCodePoint(cp);
    })
    .replace(/\\([\s\S])/g, '$1');                             // \" \) \: literal
  // Scan several de-obfuscated views; a hit in ANY of them refuses. Comments
  // and escapes can nest either way round, so we don't guess an order —
  // over-refusing an exotic-but-benign value is the safe direction here.
  // SHARED by sanitizeStyle and svgPaintSafe: the SVG paint path used to carry
  // its own, weaker scanner (a literal /url\(/ test that returned "safe" when
  // it found no match), so `fill="\75 rl(//evil/x)"` and
  // `filter="expr\65 ssion(…)"` sailed straight through the I5b hardening.
  const cssViews = (s) => [decomment(s), cssUnescape(decomment(s)), decomment(cssUnescape(s))];
  const cssBanned = (s) => cssViews(s).some((p) => CSS_HARD_BAN.test(p));
  const cssUrlsSafe = (s) => {
    for (const probe of cssViews(s)) {
      const urlRe = /url\(\s*(['"]?)([^'")]*)\1\s*\)/gi;
      let m;
      while ((m = urlRe.exec(probe)) !== null) {
        if (!isCssUrlSafe(m[2])) return false;
      }
    }
    return true;
  };
  const sanitizeStyle = (v) => {
    const s = String(v);
    if (s.length > MAX_STYLE_LEN) return null;           // bound CSS-based DoS/obfuscation
    if (cssBanned(s)) return null;
    return cssUrlsSafe(s) ? s : null;
  };

  // I6: cap any single attribute VALUE. maxNodes bounds structure but not a
  // lone multi-megabyte attribute value (memory abuse). 512 KB is far above any
  // legitimate attribute yet closes the amplification.
  const MAX_ATTR_VALUE_LEN = 512 * 1024;

  // Single-URL attributes: value is one URL → scheme-checked by isSafeUrl.
  // Expanded beyond the original 6 to cover every URL-bearing attribute that
  // could otherwise slip a javascript:/data: past the gate: cite (blockquote/
  // q/del/ins), ping (<a> beacons), background (legacy), data (<object>).
  const URL_ATTRS = new Set([
    'href', 'src', 'action', 'formaction', 'xlink:href', 'poster',
    'cite', 'ping', 'background', 'data', 'longdesc', 'manifest',
  ]);

  // srcset-style attributes: value is a comma-separated list of
  // "url [descriptor]" candidates. EACH url is scheme-checked.
  const SRCSET_ATTRS = new Set(['srcset', 'imagesrcset']);

  // Validate a srcset value: split on commas, take the first token of each
  // candidate as the URL, require every one to pass isSafeUrl. Empty → false.
  const srcsetUrls = (v) => {
    const s = String(v == null ? '' : v).trim();
    if (s === '') return [];
    // candidates are comma-separated; a URL may itself contain commas only
    // inside data: (already blocked), so comma-split is safe for our allowlist.
    return s.split(',').map((c) => c.trim()).filter(Boolean).map((c) => c.split(/\s+/)[0]);
  };
  const isSafeSrcset = (v) => {
    const urls = srcsetUrls(v);
    if (!urls.length) return false;
    return urls.every((u) => isSafeUrl(u));
  };

  // ── I8: same-origin URL policy (opt-in) ────────────────────────
  // In 'same-origin' mode a URL value is allowed only if it resolves to the base
  // origin or an explicitly allow-listed origin — refusing protocol-relative
  // ("//host") and cross-origin absolute URLs, which are off-origin beacon /
  // navigation-exfil vectors. 'any' mode (the default) is unchanged, so this is
  // a no-op for existing deployments. mailto:/tel: carry no origin and are not
  // silent loads, so they pass (the scheme allowlist still gates them). With no
  // resolvable base (SSR/test without one) we FAIL CLOSED — refuse.
  const originAllowed = (value, policy) => {
    if (!policy || policy.mode !== 'same-origin') return true;
    const base = policy.base || (typeof location !== 'undefined' && location.href) || null;
    if (!base) return false;
    let u, baseOrigin;
    try { u = new URL(String(value), base); baseOrigin = new URL(base).origin; }
    catch { return false; }
    if (u.protocol === 'mailto:' || u.protocol === 'tel:') return true;
    if (u.origin === baseOrigin) return true;
    const allow = policy.allowedOrigins;
    return allow instanceof Set ? allow.has(u.origin)
         : Array.isArray(allow) ? allow.includes(u.origin) : false;
  };
  // Apply the policy to one attribute (name+value). Non-URL attrs are always
  // allowed; srcset-style attrs require EVERY candidate to pass.
  const attrOriginAllowed = (name, value, policy) => {
    if (!policy || policy.mode !== 'same-origin') return true;
    const k = String(name).toLowerCase();
    if (SRCSET_ATTRS.has(k)) return srcsetUrls(value).every((u) => originAllowed(u, policy));
    if (URL_ATTRS.has(k)) return originAllowed(value, policy);
    return true;
  };
  // Predicate: does this attribute name carry a URL (single or srcset list)?
  const isUrlBearingAttr = (name) => {
    const k = String(name).toLowerCase();
    return URL_ATTRS.has(k) || SRCSET_ATTRS.has(k);
  };

  // ── Trusted-HTML marker ────────────────────────────────────────
  // The ONLY way raw HTML reaches a raw sink. Callers wrap output of
  // self-escaping generators (syntaxHighlight, renderMarkdown) so every
  // raw-HTML write is auditable by grepping /trust\(/ .
  class TrustedHTML {
    constructor(html) { this.html = String(html); }
  }
  const trust = (html) => new TrustedHTML(html);
  const isTrusted = (x) => x instanceof TrustedHTML;

  // ── Trusted Types bridge (J7) ──────────────────────────────────
  // Under `require-trusted-types-for 'script'`, a bare `el.innerHTML = s`
  // THROWS. 0html therefore registers its OWN namespaced policy ('0html')
  // — NOT the 'default' policy, so it coexists with a host page that has
  // its own default policy (e.g. 0pdf-editor). The policy's createHTML is
  // a passthrough: values reaching it are ALREADY escaped by the upstream
  // generator the author vouched for via trust()/{$trust,from}. We never
  // register createScript/createScriptURL — 0html emits zero dynamic
  // script, so those sinks stay closed (a host default policy that throws
  // on them still protects the page).
  //
  // Result: trust() works identically with TT enforce ON or OFF, and on
  // browsers without Trusted Types (policy is null → plain assignment).
  const _ttPolicy = (() => {
    try {
      const tt = (typeof window !== 'undefined' && window.trustedTypes) ||
                 (typeof globalThis !== 'undefined' && globalThis.trustedTypes) || null;
      if (tt && tt.createPolicy) {
        return tt.createPolicy('0html', { createHTML: (s) => s });
      }
    } catch (_) { /* name taken / unsupported → null, fall back */ }
    return null;
  })();

  // Convert a trusted (already-escaped) string into whatever the current
  // environment's sinks will accept: a TrustedHTML object under TT, or the
  // raw string otherwise. Single chokepoint for every raw-HTML write.
  const _toSinkHTML = (s) => _ttPolicy ? _ttPolicy.createHTML(s) : s;


  // ── el(): safe element builder ─────────────────────────────────
  // el('div.class#id', { attrs }, ...children)
  //   - tag: 'div', 'button.primary', 'a#link.big', 'span'
  //   - attrs: plain object. Values are strings/numbers/bool.
  //       * on* keys are REFUSED (I2). Use data-on-* + delegation.
  //       * href/src/action/formaction run scheme check (I3).
  //       * class/className, style (string only), data-*, aria-*, etc OK.
  //   - children: strings (→ textNode, escaped by DOM), numbers,
  //       Nodes, TrustedHTML (raw, audited), arrays, null/undefined (skip)
  // ── I9/J13: safe SVG rendering (opt-in) ────────────────────────
  // SVG is a deep XSS surface (SMIL animation, xlink, foreignObject, in-SVG
  // <style>/<script>, external paint/filter refs). We render ONLY an allowlisted
  // element subset, in the real SVG namespace, with an ALLOWLIST of safe
  // attributes and a url() gate for paint/filter refs. The compiler marks SVG
  // elements (attrs[SVG]=true) ONLY when its `svg` option is on; with it off, SVG
  // tag names fall through to createElement and stay inert (prior behavior).
  const SVG_NS = 'http://www.w3.org/2000/svg';
  const XLINK_NS = 'http://www.w3.org/1999/xlink';
  const SVG = Symbol('0html.svg');    // marker key — symbols are invisible to Object.entries
  const SVG_TAGS = new Set([
    'svg', 'g', 'defs', 'symbol', 'use', 'path', 'circle', 'ellipse', 'rect',
    'line', 'polyline', 'polygon', 'text', 'tspan',
  ]);
  const isSvgTag = (t) => SVG_TAGS.has(String(t).toLowerCase());
  // Deliberately EXCLUDED (reopen the attack surface): foreignObject (embeds
  // HTML), animate/set/animateTransform (SMIL mXSS via attributeName→href),
  // script, style-element, image (remote raster/svg), a (SVG links).
  const SVG_ATTR_ALLOW = new Set([
    'id', 'class', 'role', 'aria-label', 'aria-labelledby', 'aria-hidden', 'aria-describedby',
    'd', 'points', 'x', 'y', 'x1', 'y1', 'x2', 'y2', 'cx', 'cy', 'r', 'rx', 'ry',
    'width', 'height', 'viewbox', 'preserveaspectratio', 'transform', 'pathlength', 'transform-origin',
    'fill', 'fill-opacity', 'fill-rule', 'stroke', 'stroke-width', 'stroke-linecap',
    'stroke-linejoin', 'stroke-miterlimit', 'stroke-dasharray', 'stroke-dashoffset',
    'stroke-opacity', 'opacity', 'color', 'visibility', 'display', 'vector-effect',
    'clip-path', 'clip-rule', 'mask', 'filter', 'marker', 'marker-start', 'marker-mid', 'marker-end', 'cursor',
    'text-anchor', 'dominant-baseline', 'alignment-baseline', 'font-size', 'font-family',
    'font-weight', 'font-style', 'letter-spacing', 'word-spacing', 'dx', 'dy', 'rotate', 'textlength', 'lengthadjust',
  ]);
  // Attributes whose value may carry url(...) → must be same-origin/fragment.
  const SVG_URLREF = new Set([
    'fill', 'stroke', 'clip-path', 'mask', 'filter', 'marker', 'marker-start', 'marker-mid', 'marker-end', 'cursor',
  ]);
  // Paint / filter / clip refs are parsed as CSS values, so they need the same
  // treatment as an inline style — not a literal-substring test. The old early
  // return (`no "url(" in the raw text → safe`) was the whole hole: an escaped
  // url-token is invisible to it, and no hard-ban check ran here at all.
  const svgPaintSafe = (v) => {
    const s = String(v);
    if (s.length > MAX_STYLE_LEN) return false;
    if (cssBanned(s)) return false;
    return cssUrlsSafe(s);
  };
  // Dedicated SVG attribute setter — allowlist-first. The HTML path is untouched.
  const applySvgAttrs = (node, tag, attrs) => {
    for (const [k, v] of Object.entries(attrs)) {
      if (v == null || v === false) continue;
      const key = k.toLowerCase();
      if (key.startsWith('on')) { console.warn(`0bind.el(svg): refused handler attr "${logSafe(k)}"`); continue; }
      if (key === 'style') {
        if (typeof v !== 'string') { console.warn('0bind.el(svg): style must be a string'); continue; }
        const s = sanitizeStyle(v);
        if (s === null) { console.warn(`0bind.el(svg): dropped unsafe style="${logSafe(v, 60)}…"`); continue; }
        node.setAttribute('style', s); continue;
      }
      if (key === 'href' || key === 'xlink:href') {
        const val = String(v);
        if (!isSafeUrl(val)) { console.warn(`0bind.el(svg): dropped unsafe URL in ${logSafe(key)}="${logSafe(val)}"`); continue; }
        if (tag === 'use' && !/^#/.test(val.trim())) { console.warn('0bind.el(svg): <use> href restricted to "#id"'); continue; }
        if (key === 'xlink:href') node.setAttributeNS(XLINK_NS, 'href', val);
        else node.setAttribute('href', val);
        continue;
      }
      if (!SVG_ATTR_ALLOW.has(key)) { console.warn(`0bind.el(svg): dropped non-allowlisted SVG attr "${logSafe(k)}"`); continue; }
      const outVal = v === true ? '' : String(v);
      if (outVal.length > MAX_ATTR_VALUE_LEN) { console.warn(`0bind.el(svg): dropped over-long value for "${logSafe(k)}"`); continue; }
      if (SVG_URLREF.has(key) && !svgPaintSafe(outVal)) { console.warn(`0bind.el(svg): dropped unsafe url() in "${logSafe(k)}"`); continue; }
      node.setAttribute(k, outVal);   // original case preserved (SVG attrs are case-sensitive)
    }
  };

  const el = (spec, attrs, ...children) => {
    // Parse "tag.cls.cls#id"
    let tag = 'div', cls = [], id = null;
    const m = String(spec).match(/^([a-zA-Z0-9]+)?((?:[.#][^.#]+)*)$/);
    if (m) {
      if (m[1]) tag = m[1];
      const rest = m[2] || '';
      rest.replace(/([.#])([^.#]+)/g, (_, k, v) => {
        if (k === '.') cls.push(v); else id = v;
        return '';
      });
    } else {
      tag = String(spec).replace(/[^a-zA-Z0-9]/g, '') || 'div';
    }
    // Namespace: HTML by default. SVG tags are built in the SVG namespace ONLY
    // when the compiler marks them (attrs[SVG]) — which it does only under the
    // opt-in `svg` option, together with the SVG attribute allowlist below
    // (applySvgAttrs). Unmarked SVG names stay inert HTMLUnknownElements.
    // I9/J13: SVG elements are marked by the compiler (attrs[SVG]) and built in
    // the real SVG namespace via a dedicated, allowlisted attribute path. Marker
    // absent (svg option off) → SVG tag names fall through to createElement and
    // stay inert, exactly as before.
    const svgMode = !!(attrs && typeof attrs === 'object' && attrs[SVG] === true);
    const node = (svgMode && SVG_TAGS.has(tag))
      ? document.createElementNS(SVG_NS, tag)
      : document.createElement(tag);
    if (svgMode) {
      if (id) node.setAttribute('id', id);            // SVGElement.className is read-only
      if (cls.length) node.setAttribute('class', cls.join(' '));
    } else {
      if (id) node.id = id;
      if (cls.length) node.className = cls.join(' ');
    }

    // Track whether we need to harden target=_blank (set after the loop).
    let needsRelHardening = false;

    if (svgMode) {
      applySvgAttrs(node, tag, attrs);
    } else if (attrs && typeof attrs === 'object') {
      for (const [k, v] of Object.entries(attrs)) {
        if (v == null || v === false) continue;
        const key = k.toLowerCase();
        // I2: never accept inline event-handler attributes.
        if (key.startsWith('on')) {
          console.warn(`0bind.el: refused inline handler "${logSafe(k)}" — use data-on-${logSafe(key.slice(2))} + delegation`);
          continue;
        }
        // className alias — I6: the cap applies here too. This branch used to
        // return before the length check, so `className` was the one attribute
        // that could carry an unbounded value through el().
        if (k === 'className') {
          const cv = String(v);
          if (cv.length > MAX_ATTR_VALUE_LEN) {
            console.warn(`0bind.el: dropped over-long value for "className" (${cv.length} chars)`);
            continue;
          }
          node.className = cv; continue;
        }
        // I3: single-URL attributes get scheme-checked.
        if (URL_ATTRS.has(key)) {
          // I3d: <use href>/<use xlink:href> can pull a REMOTE svg document
          // (data-exfil / historic XSS). Restrict to same-document fragments
          // only — the safe, common case (icon sprites via "#id").
          if (tag === 'use' && (key === 'href' || key === 'xlink:href')) {
            if (!/^#/.test(String(v).trim())) {
              console.warn(`0bind.el: <use> ${logSafe(k)} restricted to same-doc "#id" refs`);
              continue;
            }
          }
          if (!isSafeUrl(v)) {
            console.warn(`0bind.el: dropped unsafe URL in ${logSafe(k)}="${logSafe(v)}"`);
            continue;
          }
        }
        // I3b: srcset-style attributes carry MULTIPLE comma-separated URLs,
        // each "url [descriptor]". Every candidate URL must pass the scheme
        // check, or the whole attribute is dropped. (Bypass class: an
        // unchecked srcset slips javascript:/data: past the href/src gate.)
        if (SRCSET_ATTRS.has(key)) {
          if (!isSafeSrcset(v)) {
            console.warn(`0bind.el: dropped unsafe URL in srcset-style ${logSafe(k)}`);
            continue;
          }
        }
        // I3c: target=_blank opens a window that gets window.opener back —
        // reverse-tabnabbing. Remember to force rel=noopener noreferrer.
        if (key === 'target' && /_blank/i.test(String(v))) needsRelHardening = true;

        // style: string only (no object → avoids CSS-injection foot-guns
        // via untyped values; write explicit strings).
        if (key === 'style') {
          if (typeof v !== 'string') {
            console.warn('0bind.el: style must be a string');
            continue;
          }
          // I5: sanitize inline CSS (blocks url()-exfil, expression(), @import, …)
          const safeStyle = sanitizeStyle(v);
          if (safeStyle === null) {
            console.warn(`0bind.el: dropped unsafe inline style="${logSafe(v, 60)}…"`);
            continue;
          }
          node.setAttribute('style', safeStyle);
          continue;
        }
        // I6: refuse an absurdly long single attribute value (memory abuse).
        const outVal = v === true ? '' : String(v);
        if (outVal.length > MAX_ATTR_VALUE_LEN) {
          console.warn(`0bind.el: dropped over-long value for "${logSafe(k)}" (${outVal.length} chars)`);
          continue;
        }
        node.setAttribute(k, outVal);
      }
    }

    // I3c cont.: ensure rel contains noopener + noreferrer when _blank.
    // Merges with any author-supplied rel rather than clobbering it.
    if (needsRelHardening) {
      const existing = (attrs && (attrs.rel || attrs.Rel)) ? String(attrs.rel || attrs.Rel) : '';
      const parts = new Set(existing.split(/\s+/).filter(Boolean));
      parts.add('noopener'); parts.add('noreferrer');
      node.setAttribute('rel', [...parts].join(' '));
    }

    appendChildren(node, children);
    return node;
  };

  // ── appendChildren(): the safe child coercion rules ────────────
  const appendChildren = (node, children) => {
    for (const c of children) {
      if (c == null || c === false) continue;
      if (Array.isArray(c)) { appendChildren(node, c); continue; }
      if (c instanceof Node) { node.appendChild(c); continue; }
      if (isTrusted(c)) {
        // Raw HTML sink — audited. Parse in a <template> so scripts don't
        // execute, and route the assignment through the TT policy so this
        // works under `require-trusted-types-for 'script'` (J7).
        const t = document.createElement('template');
        t.innerHTML = _toSinkHTML(c.html);  // trusted, self-escaped upstream
        node.appendChild(t.content);
        continue;
      }
      // Everything else → text node. Cannot inject markup (I1).
      node.appendChild(document.createTextNode(String(c)));
    }
  };

  // ── frag(): DocumentFragment of many children (single reflow) ──
  const frag = (...children) => {
    const f = document.createDocumentFragment();
    appendChildren(f, children);
    return f;
  };

  // ── setSafe(): the innerHTML replacement ──────────────────────
  // Clears target, then appends children with the same safe rules.
  //   setSafe(node, 'plain text')            → text, escaped
  //   setSafe(node, el('b', null, 'hi'))     → element
  //   setSafe(node, trust(renderMarkdown(x))) → audited raw HTML
  //   setSafe(node, [a, b, c])               → mixed
  // Returns node for chaining.
  const setSafe = (node, ...children) => {
    if (!node) return node;
    node.textContent = '';                  // fast, safe clear
    appendChildren(node, children);
    return node;
  };

  // ── clear(): explicit empty (replaces innerHTML = '') ──────────
  const clear = (node) => { if (node) node.textContent = ''; return node; };

  // ═══════════════════════════════════════════════════════════════
  //  DELEGATED EVENT LAYER  (the "htmx feeling")
  // ═══════════════════════════════════════════════════════════════
  //
  // Markup:  <button data-on-click="save">   (no inline JS, CSP-clean)
  //          <input  data-on-input="filter" data-arg="rows">
  //          <form   data-on-submit="send">  (submit auto-preventDefault)
  //
  // JS:      bind.on('save', (e, el, ctx) => { ... });
  //          ctx = { arg: el.dataset.arg, target, type, root }
  //
  // ONE listener per event type on a single root handles the whole app.
  // No per-element addEventListener. No inline handlers. Actions are
  // looked up by name in a registry, so nothing from the DOM is eval'd.

  const registry = new Map();               // "name" -> handler fn
  const boundTypes = new Set();             // event types already delegated
  let ROOT = null;                          // delegation root (set in init)

  // Auto-preventDefault for these to stop full-page nav/reload.
  const PREVENT_DEFAULT = new Set(['submit']);

  const on = (name, handler) => {
    if (typeof handler !== 'function') {
      console.warn(`0bind.on: handler for "${logSafe(name)}" is not a function`);
      return;
    }
    registry.set(name, handler);
  };
  const off = (name) => registry.delete(name);

  // ── I10: clobber-safe DOM reads for the dispatch walk ──────────
  // dispatch() walks UNTRUSTED DOM. HTMLFormElement is [LegacyOverrideBuiltIns],
  // so a named child SHADOWS built-ins on the whole prototype chain:
  //   <form><input name="hasAttribute">  → form.hasAttribute IS the <input>
  // Calling it threw a TypeError *outside* the handler try/catch, so on a
  // submit event preventDefault() never ran and the browser performed the real
  // form submission. name="parentNode" cycled the walk forever; name="nodeType"
  // silently killed the binding. `name` is deliberately never prefixed by
  // idPolicy (it is server-visible data), so the compiler cannot fix this —
  // the walk has to stop trusting the node and read from the prototype.
  const _protoDesc = (obj, key) => {
    for (let p = Object.getPrototypeOf(obj); p; p = Object.getPrototypeOf(p)) {
      const d = Object.getOwnPropertyDescriptor(p, key);
      if (d) return d;
    }
    return null;                          // plain object / test shim
  };
  const _read = (node, key) => {
    const d = _protoDesc(node, key);
    if (!d) return node[key];             // no prototype accessor → nothing to shadow
    return d.get ? d.get.call(node) : d.value;
  };
  const _callProto = (node, key, arg) => {
    const d = _protoDesc(node, key);
    const fn = d && d.value;
    if (typeof fn === 'function') return fn.call(node, arg);
    const own = node[key];                // shim fallback
    return typeof own === 'function' ? own.call(node, arg) : undefined;
  };
  const _hasAttr = (node, a) => _callProto(node, 'hasAttribute', a) === true;
  const _getAttr = (node, a) => { const v = _callProto(node, 'getAttribute', a); return v == null ? null : v; };
  // Bound the walk too: a clobbered parentNode can make the chain cyclic.
  const MAX_WALK = 512;

  const dispatch = (type, e) => {
    const attr = `data-on-${type}`;
    // Walk from the event target up to root, honoring the nearest binding.
    let node = e.target, hops = 0;
    while (node && node !== ROOT && _read(node, 'nodeType') === 1) {
      if (++hops > MAX_WALK) {
        console.warn(`0bind: dispatch walk exceeded ${MAX_WALK} hops — aborting (cyclic or clobbered parentNode)`);
        return;
      }
      if (_hasAttr(node, attr)) {
        const name = _getAttr(node, attr);
        const fn = registry.get(name);
        if (fn) {
          if (PREVENT_DEFAULT.has(type)) e.preventDefault();
          const argv = _getAttr(node, 'data-arg');
          try {
            fn(e, node, {
              arg: argv === null ? undefined : argv,
              name, type, target: node, root: ROOT,
            });
          } catch (ex) {
            console.error(`0bind: handler "${logSafe(name)}" threw:`, ex);
          }
        } else {
          console.warn(`0bind: no handler registered for "${logSafe(name)}" (${logSafe(attr)})`);
        }
        return;                             // nearest binding wins
      }
      node = _read(node, 'parentNode');
    }
  };

  // Register a delegated listener for an event type (idempotent).
  const delegate = (...types) => {
    for (const type of types) {
      if (boundTypes.has(type)) continue;
      boundTypes.add(type);
      // Non-bubbling events (focus/blur) need capture; use it broadly —
      // capture-phase delegation is correct for all these types.
      const useCapture = (type === 'focus' || type === 'blur' ||
                          type === 'focusin' || type === 'focusout');
      (ROOT || document).addEventListener(type, (e) => dispatch(type, e),
                                          useCapture);
    }
  };

  // ── init(): wire the delegation root + default event set ───────
  const init = (root, types) => {
    ROOT = root || document.body || document;
    delegate(...(types || ['click', 'input', 'change', 'submit', 'keydown']));
    return api;
  };

  const api = Object.freeze({
    // safe DOM
    el, frag, setSafe, clear, trust,
    isSafeUrl,
    // URL / CSS guards (I5 — exported for reuse + tests)
    isCssUrlSafe, sanitizeStyle,
    // same-origin URL policy (I8 — used by 0html compiler + tests)
    originAllowed, attrOriginAllowed, isUrlBearingAttr,
    // safe SVG rendering (I9/J13 — compiler marks elements with SVG_MARK)
    SVG_MARK: SVG, isSvgTag, svgPaintSafe,
    // log-injection guard (I7 — exported for 0html + tests)
    logSafe,
    // events
    on, off, delegate, init,
    // Trusted Types (J7)
    ttActive: _ttPolicy !== null,   // true when running under a TT policy
    // introspection (tests/debug) — J8b: these used to be the LIVE Map/Set.
    // Object.freeze on the api object is shallow, so `bind._registry.set('save',
    // evil)` let co-bundled gadget code swap any delegated handler: the same
    // actor and the same class of hole J8 closed for ALLOWED_TAGS, on a
    // higher-value target. Now a FRESH COPY per read (same pattern as the
    // ALLOWED_TAGS snapshot) — a write lands on the throwaway. Note freezing a
    // Map would NOT help: Object.freeze does not disable .set()/.delete(), so
    // the copy IS the control. Real mutation goes through on()/off() only.
    get _registry() { return new Map(registry); },
    get _boundTypes() { return new Set(boundTypes); },
    get _root() { return ROOT; },
    version: '1.9.3',
  });
  return api;
})();

// Expose under the project's flat module scope + window for the page.
// `bind` is the in-app handle used by 00-core..08-init after concat.
var bind = OUI_BIND;
if (typeof window !== 'undefined') { window.OUI_BIND = OUI_BIND; window.bind = OUI_BIND; }

// ── Module interop ─────────────────────────────────────────────
// This repo is "type":"module". In the browser, 0bind.js is concatenated
// by combine.sh into the single <script type="module"> with 00-core..08-init,
// sharing scope — `bind` and `OUI_BIND` are directly usable there.
// For Node: ESM importers use window/global; CommonJS (.cjs) tests copy
// this file to a .cjs temp and read module.exports (see 0bind-test.cjs).
if (typeof module !== 'undefined' && module.exports) {
  module.exports = OUI_BIND;
}
