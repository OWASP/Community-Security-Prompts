#!/usr/bin/env node
/*
  0mutate.cjs — does the suite actually detect a broken guard?

  ctrl.ad.009 in the risk taxonomy says every security control ships with a test
  that FAILS when the control is removed. This is that control, mechanised for
  this library: neuter each guard in turn, run the full suite, and record whether
  anything noticed.

  664 assertions had never been shown to detect anything. Static inspection could
  not answer it — a pattern scan flagged 56 of 348 conditions as "an empty set
  could satisfy this", and almost all were legitimate negative assertions like
  !el.hasAttribute('onclick'), which is the POINT of the test. Mutation answers
  it directly: break the thing, see if the alarm sounds.

  The harness has one rule it will not break: a mutation that did not apply is
  reported as NOT-APPLIED, never as SURVIVED. Three hand-run mutations silently
  failed to match and all three "passed" — one step from concluding the safety
  net was blind. A survivor is only a survivor if the mutant reached the code.

  Run:  node 0mutate.cjs [--list] [--only <name>]
*/
'use strict';
const fs = require('fs'), path = require('path'), { execFileSync } = require('child_process');
const ROOT = __dirname;

/* Each mutation neuters one guard at its declaration. `find` must match exactly
   once; `body` is injected as the first statement of the function. */
const MUTATIONS = [
  { name: 'isSafeUrl',      file: '0bind.js', find: 'const isSafeUrl = (',      body: 'return true;',
    breaks: 'every URL is permitted — javascript:, data:, off-origin' },
  { name: 'isCssUrlSafe',   file: '0bind.js', find: 'const isCssUrlSafe = (',   body: 'return true;',
    breaks: 'CSS url() gate opens — finding #17, the escape bypass' },
  { name: 'isSafeSrcset',   file: '0bind.js', find: 'const isSafeSrcset = (',   body: 'return true;',
    breaks: 'srcset candidates unchecked' },
  { name: 'isSvgTag',       file: '0bind.js', find: 'const isSvgTag = (',       body: 'return true;',
    breaks: 'any tag treated as allowed SVG' },
  { name: 'svgPaintSafe',   file: '0bind.js', find: 'const svgPaintSafe = (',   body: 'return true;',
    breaks: 'SVG paint values unchecked' },
  { name: 'originAllowed',  file: '0bind.js', find: 'const originAllowed = (',  body: 'return true;',
    breaks: 'urlPolicy allowlist ignored' },
  { name: 'logSafe',        file: '0bind.js', find: 'const logSafe = (',        body: 'return String(v);',
    breaks: 'log-injection guard removed (I7)' },

  /* The tooling guards. Findings #23-29 all lived here, and each fix has a suite
     written for it — 0cspval, 0tt, 0sri, 0l5l8, 0handlers. Mutating them asks
     whether those fixes are actually PROTECTED, or merely present. A survivor
     here means a defect that was found once could return unnoticed. */
  { name: 'directiveSatisfies', file: '0html-layers.cjs', find: 'function directiveSatisfies(', body: 'return true;',
    breaks: 'CSP directive VALUES unchecked — finding #23, form-action * certified clean' },
  { name: 'hasWildcardSource',  file: '0html-layers.cjs', find: 'function hasWildcardSource(',  body: 'return false;',
    breaks: 'connect-src https: called scoped — finding #26' },
  { name: 'ttRequired',         file: '0html-layers.cjs', find: 'function ttRequired(',         body: 'return true;',
    breaks: 'valueless require-trusted-types-for accepted — finding #28' },
  { name: 'ttShimPresent',      file: '0html-layers.cjs', find: 'function ttShimPresent(',      body: 'return true;',
    breaks: 'a TT marker in an HTML COMMENT certifies enforce — finding #28' },
  { name: 'parseIntegrity',     file: '0html-layers.cjs', find: 'function parseIntegrity(',     body: 'return { ok: true, algs: [] };',
    breaks: 'SRI hashes accepted unparsed — finding #25' },
  { name: 'externalSubresources', file: '0html-layers.cjs', find: 'function externalSubresources(', body: 'return [];',
    breaks: 'remote code invisible to audit-sri — finding #25' },
  { name: 'maskNonMarkup',      file: '0scan-html.cjs',   find: 'function maskNonMarkup(',      body: 'return src;',
    breaks: 'script/style/comment bodies scanned as markup — the #24 class' },

  /* The compiler's own gates, and the finer-grained scanner predicates. These
     are where a survivor is most plausible: small helpers whose behaviour is
     asserted indirectly through a larger output, if at all. */
  { name: 'validate',        file: '0html.js',       find: 'const validate =',        body: 'return { ok: true, errors: [] };',
    breaks: 'spec validation accepts anything' },
  { name: 'isAllowedTag',    file: '0html.js',       find: 'const isAllowedTag =',    body: 'return true;',
    breaks: 'tag allowlist opens — script, iframe, object' },
  { name: 'applyIdPolicy',   file: '0html.js',       find: 'const applyIdPolicy =',   body: 'return;',
    breaks: 'DOM-clobbering ids pass unchecked (I6/J8)' },
  { name: 'isHandlerAttr',   file: '0scan-html.cjs', find: 'const isHandlerAttr =',   body: 'return false;',
    breaks: 'no attribute recognised as an event handler — #24/#29' },
  { name: 'isUnknownOnAttr', file: '0scan-html.cjs', find: 'const isUnknownOnAttr =', body: 'return false;',
    breaks: 'once="true" treated as a handler again — finding #29' },
  { name: 'scriptEmbeddedHandlers', file: '0scan-html.cjs', find: 'function scriptEmbeddedHandlers(', body: 'return [];',
    breaks: 'handlers inside JS string literals invisible — finding #24' },
  { name: 'inlineStyleAttrs', file: '0html-layers.cjs', find: 'function inlineStyleAttrs(', body: 'return [];',
    breaks: 'quoted inline styles missed before L8 drops unsafe-inline — #27' },
];

const only = (() => { const i = process.argv.indexOf('--only'); return i > -1 ? process.argv[i + 1] : null; })();
if (process.argv.includes('--list')) {
  MUTATIONS.forEach((m) => console.log(`  ${m.name.padEnd(16)} ${m.file.padEnd(12)} ${m.breaks}`));
  process.exit(0);
}

function injectFirstStatement(src, find, body) {
  const i = src.indexOf(find);
  if (i === -1) return null;                       // caller reports NOT-APPLIED
  if (src.indexOf(find, i + 1) !== -1) return null; // ambiguous — refuse rather than guess
  const brace = src.indexOf('{', i);
  if (brace === -1) return null;
  return src.slice(0, brace + 1) + ` /*MUTANT*/ ${body} ` + src.slice(brace + 1);
}

function suiteFails() {
  try { execFileSync('./build.sh', ['--test'], { cwd: ROOT, stdio: 'pipe' }); return false; }
  catch (_) { return true; }                       // non-zero exit = something noticed
}

console.log('\n  0mutate — neuter each guard, see whether the suite notices\n');
let caught = 0, survived = 0, notApplied = 0;
const results = [];

for (const m of MUTATIONS) {
  if (only && m.name !== only) continue;
  const file = path.join(ROOT, m.file);
  const orig = fs.readFileSync(file, 'utf8');
  const mutated = injectFirstStatement(orig, m.find, m.body);

  if (mutated === null) {
    notApplied++; results.push([m.name, 'NOT-APPLIED', 'pattern missing or ambiguous — NOT a survivor']);
    continue;
  }
  fs.writeFileSync(file, mutated);
  // the mutant must be present before any verdict is drawn from its absence
  const present = fs.readFileSync(file, 'utf8').includes('/*MUTANT*/');
  let verdict;
  if (!present) { notApplied++; verdict = ['NOT-APPLIED', 'write did not land']; }
  else if (suiteFails()) { caught++; verdict = ['caught', m.breaks]; }
  else { survived++; verdict = ['SURVIVED', m.breaks + '  \u2190 no test covers this']; }
  fs.writeFileSync(file, orig);                    // always restore
  results.push([m.name, verdict[0], verdict[1]]);
  console.log(`  ${verdict[0] === 'caught' ? '\u2713' : '\u2717'} ${m.name.padEnd(16)} ${verdict[0].padEnd(12)} ${verdict[1]}`);
}

// restoration is part of the contract, not an afterthought
const dirty = [...new Set(MUTATIONS.map((m) => m.file))]
  .filter((f) => fs.readFileSync(path.join(ROOT, f), 'utf8').includes('/*MUTANT*/'));
console.log('\n  ' + '\u2500'.repeat(56));
console.log(`  ${caught} caught, ${survived} survived, ${notApplied} not applied`);
if (dirty.length) console.log(`  \u2717 SOURCE LEFT MUTATED: ${dirty.join(', ')} — restore before committing`);
else console.log('  sources restored clean');
if (survived) console.log('  A survivor is a guard no test protects: a regression there ships silently.');
if (notApplied) console.log('  NOT-APPLIED is not a pass — the pattern needs fixing before the result means anything.');
console.log('  ' + '\u2500'.repeat(56) + '\n');
process.exit(survived || dirty.length ? 1 : 0);
