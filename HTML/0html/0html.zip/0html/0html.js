// ╔═══════════════════════════════════════════════════════════════╗
// ║  0html.js — JSON-first declarative UI for single-file tools    ║
// ║  Zero-dependency. Compiles a JSON spec → safe DOM.             ║
// ║  Runtime: 0bind (el/frag/setSafe/trust/on).                    ║
// ║  v1.8.0 — advise() detection + presets; opt-in policies J11–13 ║
// ║           URL (J11); all opt-in; SBOM tooling; DoS caps        ║
// ║           input-size cap (J9), per-node attr cap (J10),        ║
// ║           immutable allowlist + frozen API (J8)               ║
// ╚═══════════════════════════════════════════════════════════════╝
//
// WHY JSON IS FIRST-CLASS
// -----------------------
// Single-file tools ship UI, load UI from disk/URL, and increasingly
// take UI shapes from LLM output. A JSON authoring format means the UI
// is *data*: serializable, diffable, storable, transmittable — and,
// critically, PARSEABLE FROM UNTRUSTED SOURCES under a hard security
// contract. `el()` is the runtime; 0html node objects are the source.
//
// THE 0HTML NODE (the spec, in one paragraph)
// -------------------------------------------
//   A node is either a string (→ text) or an object:
//     { "tag": "div", "class": "x y", "id": "z",
//       "attrs": { "title": "hi", "href": "/p" },
//       "on":    { "click": "save", "input": "filter" },
//       "arg":   "rows",
//       "text":  "leaf text",           // mutually exclusive with children
//       "children": [ <node>, <node> ], // array of nodes
//       "html":  { "$trust": "<b>x</b>", "from": "markdown" } // GATED raw
//     }
//   Everything unknown is ignored. Nothing is eval'd. See SECURITY.
//
// SECURITY CONTRACT (extends 0bind I1–I4 with JSON-surface rules)
//   J1  PROTOTYPE SAFETY: keys __proto__, prototype, constructor are
//       dropped everywhere. No spec can pollute Object.prototype.
//   J2  DEPTH + BREADTH BOUNDS: maxDepth (default 64) and maxNodes
//       (default 10000) are enforced; a hostile deeply-nested or huge
//       spec is refused, not stack-overflowed. Tunable per compile().
//   J3  TAG ALLOWLIST: only known-safe HTML tags render. script, style,
//       iframe, object, embed, link, meta, base, form-action sinks and
//       any unknown tag are refused (→ inert <span> placeholder + warn).
//   J4  HANDLER NAMES ARE OPAQUE STRINGS: `on` values are looked up in
//       the 0bind registry by exact string. A name with no registered
//       handler renders inert. NOTHING from JSON is turned into code.
//   J5  RAW HTML IS DOUBLE-GATED: `html` only renders if (a) shaped as
//       { "$trust": "...", "from": "<generator>" } AND (b) that generator
//       name is in the compile-time `trustedGenerators` allowlist AND
//       (c) the caller passed { allowTrustedHTML: true }. Default: OFF.
//       This makes "raw HTML from a JSON file" impossible unless the
//       tool author explicitly opts in per compile.
//   J6  ATTR NAMESPACE GUARD: attribute names are validated against a
//       conservative charset; on*, style-object, and event-ish attrs are
//       refused here too (defense in depth over 0bind.el).
//   J8  IMMUTABLE ALLOWLIST: the tag allowlist and the API surface are frozen.
//       Callers see read-only snapshots, never the live Set, so no co-bundled
//       or gadget code can widen the allowlist (e.g. add 'script') or swap a
//       method at runtime. Extends "not spec-configurable" to "not runtime-
//       configurable via the public API" either.
//   J9  INPUT-SIZE CAP: fromJSON() bounds the raw byte length before JSON.parse
//       (default 5 MB), so an oversized/deeply-nested untrusted blob can't
//       exhaust memory/stack before the post-parse bounds get a chance to run.
//   J10 PER-NODE ATTR CAP: the attribute + handler count on a single node is
//       bounded (default 256), closing the one memory/reflow amplification that
//       the maxNodes tree-size bound does not cover.
//   J11 SAME-ORIGIN URL ENFORCEMENT (opt-in): with urlPolicy.mode==='same-origin'
//       the compiler drops off-origin href/src/srcset (via _bind.attrOriginAllowed)
//       before el() sees them. Default 'any' leaves behavior unchanged.
//   J12 ID/NAME NAMESPACING (opt-in): with idPolicy.mode 'namespace'/'strict' the
//       compiler prefixes id + every id-reference (for/aria-*/headers/#frag/use)
//       uniformly, so spec ids can't clobber host-page globals. 'strict' also
//       refuses dangerous raw id/name values. Default 'off' = unchanged.
//   J13 SAFE SVG (opt-in): with svg:true the compiler allows + marks the SVG tag
//       subset so 0bind renders it in the SVG namespace through an allowlist of
//       safe elements/attributes (foreignObject/animate/script/image/a/style
//       excluded; paint url() same-origin only). Default false = SVG stays inert.

'use strict';

const OUI_HTML = (() => {

  // 0bind runtime handle (module scope after concat, or window).
  const _bind = (typeof OUI_BIND !== 'undefined') ? OUI_BIND
              : (typeof window !== 'undefined' && window.OUI_BIND) ? window.OUI_BIND
              : null;

  // ── J1: forbidden object keys (prototype-pollution vectors) ────
  const FORBIDDEN_KEYS = new Set(['__proto__', 'prototype', 'constructor']);

  // ── J3: tag allowlist. Conservative, structural + text + form
  //         controls. NO script/style/iframe/object/embed/link/meta/base.
  const ALLOWED_TAGS = new Set([
    // structure
    'div','span','section','article','header','footer','main','aside','nav',
    'ul','ol','li','dl','dt','dd','figure','figcaption','details','summary',
    // text
    'p','h1','h2','h3','h4','h5','h6','blockquote','pre','code','em','strong',
    'b','i','u','s','small','sub','sup','mark','abbr','time','kbd','samp','var',
    'br','hr','a','q','cite',
    // tables
    'table','thead','tbody','tfoot','tr','td','th','caption','colgroup','col',
    // media (src scheme-checked by 0bind.el)
    'img','picture','source','video','audio','track','svg','path','g','circle',
    'rect','line','polyline','polygon','text','use',
    // form controls (NOTE: 'form' allowed but its action is scheme-checked;
    // submit is auto-preventDefault'd by 0bind delegation)
    'form','label','input','textarea','select','option','optgroup','button',
    'fieldset','legend','datalist','output','progress','meter',
  ]);

  // ── J6: attribute name charset. Letters, digits, dash, colon (svg),
  //         underscore. Rejects anything weird. on* handled separately.
  const ATTR_NAME_RE = /^[a-zA-Z_][a-zA-Z0-9_:-]*$/;
  const isEventishAttr = (k) => /^on/i.test(k);

  // ── helpers ────────────────────────────────────────────────────
  const isPlainObject = (x) =>
    x != null && typeof x === 'object' && !Array.isArray(x);

  // Strip forbidden keys, return a shallow safe copy (own enumerable only).
  const safeEntries = (obj) => {
    const out = [];
    for (const k of Object.keys(obj)) {
      if (FORBIDDEN_KEYS.has(k)) continue;
      out.push([k, obj[k]]);
    }
    return out;
  };

  // ── J12: id/name namespacing (DOM-clobbering mitigation, opt-in) ─
  // An attacker-controlled id/name can shadow host-page globals (window.X,
  // document.X), defeat getElementById assumptions, or clobber named form
  // access. A deterministic prefix transform (x → <prefix>x) applied UNIFORMLY
  // to both id-defining and id-REFERENCING attributes keeps intra-spec wiring
  // intact (label↔input, aria, "#frag" links, <use> sprites) while making any
  // host global not under <prefix> unclobberable. `name` is deliberately NOT
  // prefixed (it is server-visible submitted data; prefixing would silently
  // break forms) — but in 'strict' mode a dangerous raw id/name value is refused.
  const ID_DEFINE = new Set(['id']);                 // prefixed (NOT 'name' — see above)
  const ID_REF_SINGLE = new Set(['for', 'list', 'form']);
  const ID_REF_LIST = new Set([                      // space-separated idref lists
    'headers', 'aria-labelledby', 'aria-describedby', 'aria-controls',
    'aria-owns', 'aria-flowto', 'aria-details', 'aria-activedescendant',
  ]);
  const FRAG_ATTRS = new Set(['href', 'xlink:href']);
  // High-value clobbering targets refused outright in 'strict' mode.
  const ID_DENY = new Set([
    'length', 'name', 'constructor', 'prototype', '__proto__', 'location',
    'forms', 'cookie', 'document', 'window', 'history', 'navigator', 'top',
    'self', 'parent', 'frames', 'origin', 'domain', 'id',
    // I10 (defense in depth): DOM accessors a named form child can shadow.
    // 0bind's dispatch walk no longer trusts the node, but a host app that
    // walks the rendered tree itself is still exposed, so refuse these too.
    'hasattribute', 'getattribute', 'setattribute', 'removeattribute',
    'parentnode', 'parentelement', 'childnodes', 'children', 'firstchild',
    'nodetype', 'nodename', 'tagname', 'attributes', 'dataset', 'classlist',
    'innerhtml', 'outerhtml', 'textcontent', 'elements', 'submit', 'action',
    'method', 'closest', 'matches', 'queryselector', 'queryselectorall',
    'append', 'remove', 'contains', 'body', 'head', 'title', 'ownerdocument',
  ]);
  const isDangerousId = (v) =>
    v === '' || v.length === 1 || /^\d+$/.test(v) || ID_DENY.has(v.toLowerCase());

  const applyIdPolicy = (attrs, cfg) => {
    const mode = cfg.idPolicy.mode;
    if (mode === 'off') return;
    const px = cfg.idPolicy.prefix;
    const strict = mode === 'strict';
    const pre = (id) => px + id;
    for (const k of Object.keys(attrs)) {
      const lk = k.toLowerCase();
      const v = attrs[k];
      if (typeof v !== 'string') continue;
      if (ID_DEFINE.has(lk) || (strict && lk === 'name')) {
        if (strict && isDangerousId(v)) {
          cfg.warn(`0html: idPolicy strict — refused ${lk}="${_bind.logSafe(v)}" (clobbering risk)`);
          delete attrs[k];
          continue;
        }
        if (ID_DEFINE.has(lk)) attrs[k] = pre(v);      // prefix id (never 'name')
      } else if (ID_REF_SINGLE.has(lk)) {
        if (v !== '') attrs[k] = pre(v);
      } else if (ID_REF_LIST.has(lk)) {
        attrs[k] = v.split(/\s+/).filter(Boolean).map(pre).join(' ');
      } else if (FRAG_ATTRS.has(lk) && v.length > 1 && v[0] === '#') {
        attrs[k] = '#' + pre(v.slice(1));
      }
    }
  };

  // ── policy presets (opt-in convenience) ────────────────────────
  // A preset supplies DEFAULTS; any explicit opts field overrides it. Lets a
  // project (or an advise() recommendation) lock things down in one switch.
  const PRESETS = {
    strict:    { urlPolicy: { mode: 'same-origin' }, idPolicy: { mode: 'strict' }, svg: false },
    namespace: { idPolicy: { mode: 'namespace' } },
  };
  // Merge is ONE LEVEL DEEP for the policy objects. A plain Object.assign
  // replaces a whole policy object, so the documented follow-up to advise() —
  //   compile(spec, { preset:'strict', urlPolicy:{ allowedOrigins:[cdn] } })
  // — silently discarded mode:'same-origin' and fell back to mode:'any'. A
  // preset must never be weakened by a partial override of one of its fields.
  const POLICY_KEYS = ['urlPolicy', 'idPolicy'];
  const applyPreset = (opts) => {
    if (!opts || typeof opts.preset !== 'string') return opts || {};
    const base = PRESETS[opts.preset];
    if (!base) return opts;
    const out = Object.assign({}, base, opts);            // explicit opts win
    for (const k of POLICY_KEYS) {
      if (isPlainObject(base[k]) && isPlainObject(opts[k])) {
        out[k] = Object.assign({}, base[k], opts[k]);     // …but field-by-field
      }
    }
    return out;
  };

  // ── advise(spec, opts) → detection report (no rendering) ────────
  // Inspects a spec and reports which OPTIONAL policies would apply, so a
  // project applying 0html can DETECT and ASK the user before enabling them
  // (the policies stay opt-in). Pure analysis: never builds DOM, never throws,
  // bounded exactly like compile. Returns { findings, recommended, ... } where
  // `recommended` is an opts fragment ready to spread into compile().
  const classifyExternalUrl = (v) => {
    const s = String(v).replace(/[\u0000-\u001F\u007F-\u009F]/g, '').replace(/\\/g, '/').trim();
    if (s === '' || /^(mailto:|tel:)/i.test(s)) return null;
    try {
      const u = new URL(s, 'https://self.invalid/');
      if (u.origin === 'https://self.invalid') return null;              // relative / same-doc
      return (u.protocol === 'http:' || u.protocol === 'https:') ? u.origin : null;
    } catch { return null; }
  };
  const advise = (spec, opts = {}) => {
    opts = applyPreset(opts);
    const active = {
      urlSameOrigin: !!(opts.urlPolicy && opts.urlPolicy.mode === 'same-origin'),
      idMode: (opts.idPolicy && (opts.idPolicy.mode === 'namespace' || opts.idPolicy.mode === 'strict')) ? opts.idPolicy.mode : 'off',
      svg: opts.svg === true,
    };
    const maxNodes = opts.maxNodes ?? 10000, maxDepth = opts.maxDepth ?? 64;
    let scanned = 0, offOrigin = 0, idCount = 0;
    const externalOrigins = new Set(), svgTags = new Set(), clobber = [];
    const visit = (node, depth) => {
      if (!isPlainObject(node) || scanned >= maxNodes || depth > maxDepth) return;
      scanned++;
      const tag = typeof node.tag === 'string' ? node.tag.toLowerCase() : 'div';
      if (_bind.isSvgTag(tag)) svgTags.add(tag);
      // build() honours a TOP-LEVEL `id` shorthand (node.id), not just
      // node.attrs.id — advise() only walked node.attrs, so `{tag,id:"location"}`
      // rendered a clobbering id while the advisory reported nothing.
      if (typeof node.id === 'string') {
        idCount++;
        if (isDangerousId(node.id)) clobber.push(`id="${_bind.logSafe(node.id, 40)}"`);
      }
      if (isPlainObject(node.attrs)) {
        for (const [k, v] of safeEntries(node.attrs)) {
          const lk = k.toLowerCase();
          if (v == null || typeof v === 'boolean') continue;
          const sv = String(v);
          if (_bind.isUrlBearingAttr(lk)) {
            for (const cand of sv.split(',')) {
              const o = classifyExternalUrl(cand.trim().split(/\s+/)[0]);
              if (o) { offOrigin++; externalOrigins.add(o); }
            }
          }
          if (lk === 'id' || lk === 'name') {
            idCount++;
            if (isDangerousId(sv)) clobber.push(`${lk}="${_bind.logSafe(sv, 40)}"`);
          }
        }
      }
      if (Array.isArray(node.children)) for (const c of node.children) visit(c, depth + 1);
    };
    visit(spec, 0);

    const findings = [], recommended = {};
    if (offOrigin > 0 && !active.urlSameOrigin) {
      // Recommend the SAFE default (block all off-origin). We do NOT auto-allow
      // the origins we saw — that would defeat the purpose. They're reported in
      // `externalOrigins` for the human/ask step to selectively allow-list.
      recommended.urlPolicy = { mode: 'same-origin' };
      findings.push({ policy: 'urlPolicy', severity: 'medium',
        detail: `${offOrigin} off-origin URL(s) across ${externalOrigins.size} origin(s): ${[...externalOrigins].join(', ')}`,
        suggestion: `enable urlPolicy:{mode:'same-origin'}; review externalOrigins and add back only the ones you trust via allowedOrigins` });
    }
    if (clobber.length && active.idMode !== 'strict') {
      recommended.idPolicy = { mode: 'strict' };
      findings.push({ policy: 'idPolicy', severity: 'high',
        detail: `${clobber.length} id/name value(s) collide with global-ish names: ${clobber.slice(0, 5).join(', ')}`,
        suggestion: `enable idPolicy:{mode:'strict'}` });
    } else if (idCount > 0 && active.idMode === 'off') {
      recommended.idPolicy = { mode: 'namespace' };
      findings.push({ policy: 'idPolicy', severity: 'low',
        detail: `${idCount} element id(s)/name(s) present`,
        suggestion: `consider idPolicy:{mode:'namespace'} if this renders alongside app globals` });
    }
    if (svgTags.size > 0 && !active.svg) {
      recommended.svg = true;
      findings.push({ policy: 'svg', severity: 'info',
        detail: `${svgTags.size} SVG tag type(s) present (${[...svgTags].join(', ')}) — inert while svg:false`,
        suggestion: `enable svg:true to render them through the SVG allowlist` });
    }
    return { findings, recommended, externalOrigins: [...externalOrigins], svgTags: [...svgTags], scanned };
  };

  // ── compile(spec, opts) → Node ─────────────────────────────────
  //   opts:
  //     maxDepth            (default 64)
  //     maxNodes            (default 10000)
  //     maxAttrs            (default 256)     — per-node attribute ceiling
  //     urlPolicy           (default {mode:'any'}) — I8; {mode:'same-origin',
  //                          base, allowedOrigins:[]} refuses off-origin URLs
  //     idPolicy            (default {mode:'off'}) — J12; {mode:'namespace'|
  //                          'strict', prefix:'0h-'} namespaces id + id-refs
  //     svg                 (default false)   — J13; render allowlisted SVG in
  //                          the SVG namespace (else SVG tags stay inert)
  //     preset              'strict' | 'namespace' — supplies policy DEFAULTS
  //                          (explicit opts override); see advise() to detect
  //                          which policies a given spec would benefit from
  //     allowTrustedHTML    (default false)   — J5 master switch
  //     trustedGenerators   (default [])      — J5 name allowlist
  //     onWarn              (default console.warn)
  //   Returns a DOM Node (element or text). Never throws on bad specs;
  //   refuses unsafe pieces and warns. Throws only on bound violations
  //   (depth/nodes) — those are attacks, not typos.
  const compile = (spec, opts = {}) => {
    if (!_bind) throw new Error('0html: 0bind runtime (OUI_BIND) not found');
    opts = applyPreset(opts);   // expand opts.preset → policy defaults (explicit opts win)
    const cfg = {
      maxDepth: opts.maxDepth ?? 64,
      maxNodes: opts.maxNodes ?? 10000,
      maxAttrs: opts.maxAttrs ?? 256,
      // I8: same-origin URL policy (opt-in). Default 'any' = unchanged behavior.
      urlPolicy: {
        mode: (opts.urlPolicy && opts.urlPolicy.mode === 'same-origin') ? 'same-origin' : 'any',
        base: opts.urlPolicy && opts.urlPolicy.base,
        allowedOrigins: (opts.urlPolicy && opts.urlPolicy.allowedOrigins) || [],
      },
      // J12: id/name namespacing (opt-in). Default 'off' = unchanged behavior.
      idPolicy: {
        mode: (opts.idPolicy && (opts.idPolicy.mode === 'namespace' || opts.idPolicy.mode === 'strict'))
          ? opts.idPolicy.mode : 'off',
        prefix: (opts.idPolicy && typeof opts.idPolicy.prefix === 'string') ? opts.idPolicy.prefix : '0h-',
      },
      // J13: safe SVG rendering (opt-in). Off = SVG tags stay inert (unchanged).
      svg: opts.svg === true,
      allowTrustedHTML: opts.allowTrustedHTML === true,
      trustedGenerators: new Set(opts.trustedGenerators || []),
      warn: opts.onWarn || ((m) => console.warn(m)),
    };
    const counter = { n: 0 };
    return build(spec, cfg, counter, 0);
  };

  const build = (node, cfg, counter, depth) => {
    // J2: bounds are hard failures (hostile input).
    if (depth > cfg.maxDepth) {
      throw new RangeError(`0html: maxDepth ${cfg.maxDepth} exceeded`);
    }
    if (++counter.n > cfg.maxNodes) {
      throw new RangeError(`0html: maxNodes ${cfg.maxNodes} exceeded`);
    }

    // string → text node (escaped by DOM; cannot inject markup)
    if (typeof node === 'string') return document.createTextNode(node);
    if (typeof node === 'number' || typeof node === 'boolean') {
      return document.createTextNode(String(node));
    }
    if (node == null) return document.createTextNode('');

    if (!isPlainObject(node)) {
      cfg.warn('0html: node is not string/object — coerced to empty text');
      return document.createTextNode('');
    }

    // ── tag resolution + J3 allowlist ─────────────────────────────
    let tag = typeof node.tag === 'string' ? node.tag.toLowerCase() : 'div';
    // J13: SVG tags are allowed only when the `svg` option is on (the pre-existing
    // svg subset is already in ALLOWED_TAGS and stays allowed-but-inert when off).
    const tagAllowed = ALLOWED_TAGS.has(tag) || (cfg.svg && _bind.isSvgTag(tag));
    if (!tagAllowed) {
      cfg.warn(`0html: tag "${_bind.logSafe(tag)}" not allowed — rendered inert`);
      // inert placeholder; keeps layout position, drops the dangerous tag
      const ph = _bind.el('span', { 'data-0html-refused': tag });
      // still render safe children so structure survives
      appendChildrenTo(ph, node, cfg, counter, depth);
      return ph;
    }

    // ── assemble attrs object for 0bind.el ───────────────────────
    const attrs = {};

    // class / className
    if (typeof node.class === 'string') attrs.class = node.class;
    else if (typeof node.className === 'string') attrs.class = node.className;
    // id
    if (typeof node.id === 'string') attrs.id = node.id;

    // J10: per-node attribute ceiling. maxNodes bounds the tree's node COUNT
    // but not the attribute count on a single node — a lone node with 10^6
    // attributes drives 10^6 setAttribute calls + reflows. Track and stop.
    let attrCount = Object.keys(attrs).length;

    // explicit attrs map (J6 charset + eventish guard + 0bind URL check)
    if (isPlainObject(node.attrs)) {
      for (const [k, v] of safeEntries(node.attrs)) {
        if (attrCount >= cfg.maxAttrs) {
          cfg.warn(`0html: maxAttrs ${cfg.maxAttrs} exceeded on <${_bind.logSafe(tag)}> — extra attributes dropped`);
          break;
        }
        if (!ATTR_NAME_RE.test(k)) {
          cfg.warn(`0html: attr name "${_bind.logSafe(k)}" rejected (charset)`);
          continue;
        }
        if (isEventishAttr(k)) {
          cfg.warn(`0html: eventish attr "${_bind.logSafe(k)}" refused — use "on":{...}`);
          continue;
        }
        if (v == null || v === false) continue;
        // I8: same-origin URL policy (opt-in). Drop off-origin href/src/srcset
        // BEFORE el() (which then still scheme-checks what remains).
        if (!_bind.attrOriginAllowed(k, v, cfg.urlPolicy)) {
          cfg.warn(`0html: dropped off-origin URL in "${_bind.logSafe(k)}"="${_bind.logSafe(v)}" (urlPolicy: same-origin)`);
          continue;
        }
        // 0bind.el will scheme-check href/src/etc and refuse on*.
        attrs[k] = v;
        attrCount++;
      }
    }

    // ── J4: event bindings — opaque handler-name strings ─────────
    if (isPlainObject(node.on)) {
      for (const [evt, name] of safeEntries(node.on)) {
        if (attrCount >= cfg.maxAttrs) {
          cfg.warn(`0html: maxAttrs ${cfg.maxAttrs} exceeded on <${_bind.logSafe(tag)}> — extra handlers dropped`);
          break;
        }
        if (!/^[a-zA-Z][a-zA-Z0-9_-]*$/.test(evt)) {
          cfg.warn(`0html: event name "${_bind.logSafe(evt)}" rejected`);
          continue;
        }
        if (typeof name !== 'string') {
          cfg.warn(`0html: handler for "${_bind.logSafe(evt)}" must be a string name`);
          continue;
        }
        // Rendered as data-on-<evt>="name". 0bind delegation looks the
        // name up in its registry. If absent → inert (warns at dispatch).
        attrs[`data-on-${evt.toLowerCase()}`] = name;
        attrCount++;
      }
    }
    // arg passthrough for handler ctx.arg
    if (node.arg != null && !FORBIDDEN_KEYS.has('arg')) {
      attrs['data-arg'] = String(node.arg);
    }

    // J12: id/name namespacing pass (no-op unless idPolicy is on). Runs last so
    // it sees the final id + all id-reference attributes in one place.
    applyIdPolicy(attrs, cfg);

    // J13: mark SVG elements so el() builds them in the SVG namespace via the
    // allowlisted SVG attribute path. Only under the opt-in; symbol key is
    // invisible to el()'s Object.entries attribute loop.
    if (cfg.svg && _bind.isSvgTag(tag)) attrs[_bind.SVG_MARK] = true;

    // ── build element via 0bind (inherits I1–I4) ─────────────────
    const elm = _bind.el(tag, attrs);

    // ── children / text / html (mutually ordered) ────────────────
    // Priority: explicit children > text > html. Never mix silently.
    if (Array.isArray(node.children)) {
      appendChildrenTo(elm, node, cfg, counter, depth);
    } else if (typeof node.text === 'string') {
      elm.appendChild(document.createTextNode(node.text));
    } else if (node.html !== undefined) {
      renderGatedHTML(elm, node.html, cfg);
    }

    return elm;
  };

  const appendChildrenTo = (elm, node, cfg, counter, depth) => {
    const kids = Array.isArray(node.children) ? node.children : [];
    for (const child of kids) {
      elm.appendChild(build(child, cfg, counter, depth + 1));
    }
  };

  // ── J5: double-gated raw HTML ──────────────────────────────────
  //   Shape required:  { "$trust": "<...>", "from": "<generatorName>" }
  //   Renders ONLY if allowTrustedHTML AND generator is allowlisted.
  const renderGatedHTML = (elm, html, cfg) => {
    if (!isPlainObject(html) || typeof html.$trust !== 'string') {
      cfg.warn('0html: "html" must be { "$trust": "...", "from": "gen" } — refused');
      return;
    }
    const gen = typeof html.from === 'string' ? html.from : '';
    if (!cfg.allowTrustedHTML) {
      cfg.warn('0html: raw html refused (allowTrustedHTML not set)');
      return;
    }
    if (!cfg.trustedGenerators.has(gen)) {
      cfg.warn(`0html: raw html refused (generator "${_bind.logSafe(gen)}" not allowlisted)`);
      return;
    }
    // Passed all gates. Route through 0bind.trust → template parse (no
    // script execution). The tool author has explicitly vouched for this
    // generator producing self-escaped output.
    _bind.setSafe(elm, _bind.trust(html.$trust));
  };

  // ── render(spec, target, opts) — compile + mount ───────────────
  //   Clears target, compiles spec, appends. Returns target.
  const render = (spec, target, opts) => {
    if (!target) throw new Error('0html.render: no target element');
    const node = compile(spec, opts);
    _bind.setSafe(target);        // safe clear
    target.appendChild(node);
    return target;
  };

  // ── fromJSON(text, opts) — parse string then compile ───────────
  //   Convenience: JSON.parse with prototype-pollution-safe reviver,
  //   then compile. Use for loading UI from disk/URL/LLM output.
  const MAX_INPUT_BYTES = 5 * 1024 * 1024;   // 5 MB default ceiling on raw JSON
  const fromJSON = (text, opts = {}) => {
    // J9: bound the RAW input BEFORE parse. maxDepth/maxNodes and the value
    // caps all act AFTER JSON.parse has already materialized the string, so a
    // multi-megabyte or deeply-nested blob can exhaust memory/stack first.
    // fromJSON is documented for untrusted sources (disk/URL/LLM output), so
    // cap up front. Measured in BYTES (not chars) so multi-byte payloads can't
    // undercount the true size.
    const limit = opts.maxInputBytes ?? MAX_INPUT_BYTES;
    const bytes = typeof text === 'string'
      ? (typeof Buffer !== 'undefined'
          ? Buffer.byteLength(text, 'utf8')
          : new TextEncoder().encode(text).length)
      : 0;
    if (bytes > limit) {
      throw new RangeError(`0html.fromJSON: input ${bytes} B exceeds maxInputBytes ${limit}`);
    }
    const data = JSON.parse(text, (key, value) => {
      // Drop dangerous keys during parse (belt AND suspenders vs J1).
      if (FORBIDDEN_KEYS.has(key)) return undefined;
      return value;
    });
    return compile(data, opts);
  };

  // ── validate(spec, opts) — dry run, collect warnings ───────────
  //   Compiles into a detached tree, returns { ok, warnings, node }.
  //   Handy for tooling / linting a spec without mounting.
  const validate = (spec, opts = {}) => {
    const warnings = [];
    let node = null, ok = true;
    try {
      node = compile(spec, { ...opts, onWarn: (m) => warnings.push(m) });
    } catch (e) {
      ok = false;
      warnings.push(`FATAL: ${e.message}`);
    }
    return { ok, warnings, node };
  };

  // ── J8: immutable allowlist surface ────────────────────────────
  //   The README promises "the allowlist is not spec-configurable, so no
  //   loaded JSON can widen it." That held for JSON — but the old export
  //   handed out the LIVE Set, so any co-bundled/gadget code could run
  //   html0.ALLOWED_TAGS.add('script') and quietly re-open the sink. We now
  //   expose FROZEN COPIES (a fresh snapshot per read) and freeze the API
  //   object itself, so neither the allowlist nor the methods can be mutated
  //   or swapped at runtime. The internal ALLOWED_TAGS the compiler checks
  //   stays private and unreachable.
  const isAllowedTag = (t) => ALLOWED_TAGS.has(String(t).toLowerCase());
  const api = Object.freeze({
    compile, render, fromJSON, validate, advise,
    // introspection (read-only: frozen snapshots, not the live Sets)
    isAllowedTag,
    get ALLOWED_TAGS() { return Object.freeze([...ALLOWED_TAGS]); },
    get FORBIDDEN_KEYS() { return Object.freeze([...FORBIDDEN_KEYS]); },
    version: '1.9.3',
    spec: '0html/1.1',        // the STANDARD version this impl conforms to
    runtime: _bind ? _bind.version : null,
  });
  return api;
})();

// Flat module scope + window handles for single-file tools.
var html0 = OUI_HTML;
if (typeof window !== 'undefined') {
  window.OUI_HTML = OUI_HTML;
  window.html0 = OUI_HTML;
}
if (typeof module !== 'undefined' && module.exports) {
  module.exports = OUI_HTML;
}
