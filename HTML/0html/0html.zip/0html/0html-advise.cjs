#!/usr/bin/env node
// 0html-advise.cjs — detect which optional 0html policies a spec would benefit
// from, so a PROJECT can detect-and-ask (or gate CI). Pure analysis, no DOM.
//
//   node 0html-advise.cjs <spec.json>       # analyze a file
//   cat spec.json | node 0html-advise.cjs   # or stdin
//   node 0html-advise.cjs <spec.json> --json    # machine-readable output
//   node 0html-advise.cjs <spec.json> --fail-on high|medium|low   # CI gate (default: high)
//
// Exit 0 = clean or below threshold; 2 = findings at/above the fail threshold.
'use strict';
const fs = require('fs');
const path = require('path');

const html0 = require(path.join(__dirname, 'dist', '0html.bundle.js'));

const args = process.argv.slice(2);
const jsonOut = args.includes('--json');
const failIdx = args.indexOf('--fail-on');
const failOn = failIdx >= 0 ? (args[failIdx + 1] || 'high') : 'high';
const file = args.find((a) => !a.startsWith('--') && a !== failOn);

const RANK = { info: 0, low: 1, medium: 2, high: 3 };

function readInput() {
  if (file) return fs.readFileSync(file, 'utf8');
  if (!process.stdin.isTTY) return fs.readFileSync(0, 'utf8');
  console.error('usage: 0html-advise.cjs <spec.json> [--json] [--fail-on high|medium|low]');
  process.exit(1);
}

let spec;
try { spec = JSON.parse(readInput()); }
catch (e) { console.error(`0html-advise: could not parse JSON — ${e.message}`); process.exit(1); }

const report = html0.advise(spec);

if (jsonOut) {
  console.log(JSON.stringify(report, null, 2));
} else {
  const src = file ? path.basename(file) : 'stdin';
  if (!report.findings.length) {
    console.log(`✓ ${src}: no optional policies suggested (${report.scanned} nodes scanned).`);
  } else {
    console.log(`0html advisory for ${src} — ${report.scanned} nodes scanned:\n`);
    const icon = { info: 'ℹ', low: '·', medium: '▲', high: '⚠' };
    for (const f of report.findings) {
      console.log(`  ${icon[f.severity] || '-'} [${f.severity}] ${f.policy}`);
      console.log(`      ${f.detail}`);
      console.log(`      → ${f.suggestion}\n`);
    }
    if (report.externalOrigins.length) {
      console.log(`  external origins seen: ${report.externalOrigins.join(', ')}`);
    }
    // ready-to-apply opts fragment (safe defaults)
    console.log(`\n  suggested compile opts (safe defaults — review before applying):`);
    console.log(`    ${JSON.stringify(report.recommended)}`);
  }
}

const worst = report.findings.reduce((m, f) => Math.max(m, RANK[f.severity] ?? 0), -1);
if (worst >= (RANK[failOn] ?? 3)) {
  if (!jsonOut) console.error(`\n✗ findings at or above "${failOn}" — exiting non-zero (CI gate).`);
  process.exit(2);
}
