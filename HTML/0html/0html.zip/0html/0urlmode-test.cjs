// 0urlmode-test.cjs — same-origin URL policy (I8 / J11, opt-in).
// Zero-dep, in-file DOM shim. Run: node 0urlmode-test.cjs
'use strict';

// ── minimal DOM shim ───────────────────────────────────────────
class Node { constructor(){ this.childNodes=[]; this.nodeType=1; }
  appendChild(c){ if(c instanceof DocumentFragment){for(const k of c.childNodes.slice())this.appendChild(k);return c;} c.parentNode=this; this.childNodes.push(c); return c; }
  get textContent(){ return this.childNodes.map(c=>c.textContent??'').join(''); }
  set textContent(v){ this.childNodes=[]; if(v!=='')this.appendChild(new TextNode(String(v))); } }
class TextNode{ constructor(d){ this.data=String(d); this.nodeType=3; } get textContent(){ return this.data; } }
class Element extends Node { constructor(tag){ super(); this.tagName=String(tag).toLowerCase(); this._attrs={}; this.dataset={}; }
  setAttribute(k,v){ this._attrs[k]=String(v); if(k.startsWith('data-')){const c=k.slice(5).replace(/-([a-z])/g,(_,x)=>x.toUpperCase());this.dataset[c]=String(v);} }
  getAttribute(k){ return this._attrs[k]; } hasAttribute(k){ return Object.prototype.hasOwnProperty.call(this._attrs,k); }
  set id(v){ this._attrs.id=v; } get id(){ return this._attrs.id; }
  set className(v){ this._attrs.class=v; } get className(){ return this._attrs.class||''; } addEventListener(){} }
class Template extends Element { constructor(){ super('template'); this.content=new DocumentFragment(); } set innerHTML(h){ const s=new Element('span'); s.appendChild(new TextNode('[[RAW]]')); this.content.appendChild(s); } }
class DocumentFragment extends Node { constructor(){ super(); this.nodeType=11; } }
const document={ createElement:(t)=>t==='template'?new Template():new Element(t), createTextNode:(d)=>new TextNode(d), createDocumentFragment:()=>new DocumentFragment(), body:new Element('body'), addEventListener:()=>{} };
global.document=document; global.Node=Node; global.window={ addEventListener:()=>{} };

const fs=require('fs'), os=require('os'), pathm=require('path');
const toCjs=(n)=>{const p=pathm.join(os.tmpdir(),`um-${n}-${process.pid}.cjs`); fs.writeFileSync(p, fs.readFileSync(pathm.join(__dirname,`${n}.js`),'utf8')); return p;};
global.OUI_BIND=require(toCjs('0bind'));
const html0=require(toCjs('0html'));
const bind=global.OUI_BIND;

let pass=0, fail=0;
const ok=(n,c)=>{const g=!!c; console.log(`${g?'✓':'✗ FAIL'} ${n}`); g?pass++:fail++;};

const BASE='https://app.example.com/tools/x';
const SO=(extra={})=>({ urlPolicy:{ mode:'same-origin', base:BASE, allowedOrigins:['https://cdn.example.com'], ...extra } });
const hrefOf=(url,opts)=> html0.compile({ tag:'a', attrs:{ href:url } }, opts)._attrs.href;

// ═══════════════════════════════════════════════════════════════
console.log('\n── default mode "any" is unchanged ──');
ok('cross-origin href kept in default mode', hrefOf('https://evil.example/x') === 'https://evil.example/x');
ok('protocol-relative kept in default mode', hrefOf('//evil.example/x') === '//evil.example/x');

console.log('\n── same-origin mode: allow ──');
ok('relative path allowed', hrefOf('/docs/page', SO()) === '/docs/page');
ok('bare relative allowed', hrefOf('img.png', SO()) === 'img.png');
ok('fragment allowed', hrefOf('#sec', SO()) === '#sec');
ok('same-origin absolute allowed', hrefOf('https://app.example.com/y', SO()) === 'https://app.example.com/y');
ok('allow-listed CDN origin allowed', hrefOf('https://cdn.example.com/lib.js', SO()) === 'https://cdn.example.com/lib.js');
ok('mailto allowed (no origin, not a load)', hrefOf('mailto:a@b.com', SO()) === 'mailto:a@b.com');
ok('tel allowed', hrefOf('tel:+15551234', SO()) === 'tel:+15551234');
ok('userinfo resolves to real host → same-origin allowed', hrefOf('https://evil@app.example.com/y', SO()) === 'https://evil@app.example.com/y');

console.log('\n── same-origin mode: refuse ──');
ok('protocol-relative refused', hrefOf('//evil.example/track', SO()) === undefined);
ok('cross-origin absolute refused', hrefOf('https://evil.example/x', SO()) === undefined);
ok('non-allow-listed CDN refused', hrefOf('https://other-cdn.net/x', SO()) === undefined);
ok('different port = different origin → refused', hrefOf('https://app.example.com:8443/y', SO()) === undefined);
ok('punycode homograph refused (exact origin compare)', hrefOf('https://xn--pple-43d.com/y', SO()) === undefined);
ok('backslash-obfuscated protocol-relative refused', hrefOf('/\\evil.example/x', SO()) === undefined);
ok('javascript: refused (opaque origin) in same-origin mode', hrefOf('javascript:alert(1)', SO()) === undefined);

console.log('\n── srcset: every candidate origin-checked ──');
const srcsetOf=(v,opts)=>html0.compile({tag:'img',attrs:{srcset:v}},opts)._attrs.srcset;
ok('all-same-origin srcset kept', srcsetOf('/a.png 1x, /b.png 2x', SO()) === '/a.png 1x, /b.png 2x');
ok('srcset with one off-origin candidate → whole attr dropped',
   srcsetOf('/a.png 1x, https://evil.example/b.png 2x', SO()) === undefined);

console.log('\n── src on other tags gated too ──');
ok('img src cross-origin refused', html0.compile({tag:'img',attrs:{src:'https://evil.example/i.png'}}, SO())._attrs.src === undefined);
ok('img src same-origin allowed', html0.compile({tag:'img',attrs:{src:'/i.png'}}, SO())._attrs.src === '/i.png');
ok('form action cross-origin refused', html0.compile({tag:'form',attrs:{action:'https://evil.example/p'}}, SO())._attrs.action === undefined);

console.log('\n── non-URL attrs are untouched by the policy ──');
{
  const n=html0.compile({tag:'a',attrs:{href:'/ok', title:'hello', 'data-x':'1'}}, SO());
  ok('title kept under same-origin mode', n._attrs.title === 'hello');
  ok('data-* kept under same-origin mode', n._attrs['data-x'] === '1');
  ok('same-origin href kept alongside', n._attrs.href === '/ok');
}

console.log('\n── fail-closed: same-origin mode with no resolvable base ──');
ok('no base + no location → URL refused (fail closed)',
   html0.compile({tag:'a',attrs:{href:'/x'}}, { urlPolicy:{ mode:'same-origin' } })._attrs.href === undefined);

console.log('\n── browser location fallback (no explicit base) ──');
{
  global.location = { href: 'https://loc.example/app/y' };
  const withLoc = (url)=> html0.compile({tag:'a',attrs:{href:url}}, { urlPolicy:{ mode:'same-origin' } })._attrs.href;
  ok('resolves against location.href when base omitted (same-origin allowed)', withLoc('/p') === '/p');
  ok('resolves against location.href (cross-origin refused)', withLoc('https://evil.example/p') === undefined);
  delete global.location;
}

console.log('\n── unit: originAllowed / attrOriginAllowed exports ──');
const P={ mode:'same-origin', base:BASE, allowedOrigins:['https://cdn.example.com'] };
ok('originAllowed relative → true', bind.originAllowed('/x', P) === true);
ok('originAllowed cross-origin → false', bind.originAllowed('https://evil.example/x', P) === false);
ok('originAllowed any-mode always true', bind.originAllowed('https://evil.example/x', {mode:'any'}) === true);
ok('attrOriginAllowed ignores non-URL attr', bind.attrOriginAllowed('title', '//evil.example', P) === true);
ok('attrOriginAllowed checks href', bind.attrOriginAllowed('href', '//evil.example', P) === false);

console.log(`\n────────────────────────────────────────`);
console.log(`  ${pass} passed, ${fail} failed  (same-origin URL mode, I8/J11)`);
console.log(`────────────────────────────────────────`);
process.exit(fail ? 1 : 0);
