# 0html

**JSON-first declarative UI for single-file, zero-dependency tools.**

Write your UI as JSON. Compile it to real DOM through a hardened, allowlist-
based compiler. No template strings, no `innerHTML` of untrusted data, no code
in the document. A spec loaded from a file, a URL, or an LLM renders under a
hard security contract — the compiler is the trust boundary, not the author.

```json
{ "tag": "div", "class": "card", "children": [
  { "tag": "h3", "text": "Hello from JSON" },
  { "tag": "button", "text": "Save", "on": { "click": "saveHandler" }, "arg": "rows" }
]}
```

```js
html0.render(spec, document.getElementById('app'), opts);
bind.on('saveHandler', (e, el, ctx) => save(ctx.arg));
```

> **New in 1.1** — 0html now runs under **Trusted Types enforce mode** (J7).
> The runtime registers its own namespaced TT policy, so `trust()` works on
> pages with `require-trusted-types-for 'script'` instead of throwing. A
> hardened `0html-starter.html` ships TT + CSP + frame-bust pre-wired, matching
> the platform-defense tier of 0pdf-editor.

---

## Self-install (drop-in for LLM agents)

Drop this package into a project and point an AI coding agent at
`0HTML-AGENT.md`. It runs a 6-phase, approval-gated adoption — survey → plan →
(⛔ approve) → apply per-file (⛔ approve) → verify → report — and never touches
a file before you approve the specific change. Entry point: `INSTALL.md`.
Machine-parseable workflow: `AGENT-WORKFLOW.json`.

## Reuse it as a standard

0html is versioned as **`0html/1.1`** — a portable contract, not just code. Adopt
it in any single-file tool with one command:

```bash
node 0html-cli.cjs add my-tool.html     # inline the pinned bundle + set CSP hash
node 0html-cli.cjs verify my-tool.html  # tamper-evident: fails on drift or stale CSP
```

Three pillars make it a standard:

- **Adoption** — `0html add/update` inlines the bundle and computes the CSP hash
  automatically. No copy-paste, no hand-hashing (the mistake that silently breaks
  enforce-mode CSPs).
- **Integrity** — `0html.lock` pins the exact bundle SHA-256 + versions. `0html
  verify` is tamper-evident and CI-ready: one changed byte, non-zero exit. This
  is wired into `build.sh` so the standard self-checks on every build.
- **Guarantees** — `THREAT-MODEL.md` gives a STRIDE analysis with explicit
  guarantees (G1–G9) and non-guarantees (N1–N6). `CONFORMANCE.md` is the
  checklist any implementation must satisfy to claim `0html/1.1`.

Conformance run: `./build.sh --test && node 0html-cli.cjs verify`.

## What's in this release

```
0bind.js               Runtime: safe el()/setSafe()/trust() + delegated events
0html.js               JSON spec compiler (built on 0bind)
0bind-test.cjs         43 runtime security/behavior tests
0html-test.cjs         63 compiler security/behavior tests (J1–J6)
0bind-tt-test.cjs      9 Trusted Types enforce-mode tests (J7)
0scan-test.cjs         8 integration tests (hostile PDF scan data stays inert)
0html-SPEC.md          The formal specification (grammar, security, conformance)
0bind-MIGRATION.md     Migrating an existing innerHTML-heavy app to the runtime
0html-playground.template.html   Live editor source (pre-build)
0html-starter.template.html      Hardened starter source (TT+CSP+frame-bust)
0scan.template.html              Worked example: PDF threat-scan console (source)
0html-cli.cjs                    Adoption CLI: add / verify / update / pin
0html.lock                       Integrity lock (pinned bundle hash + versions)
SPEC.md                          The format specification (0html/1.1)
CONFORMANCE.md                   Conformance checklist to claim 0html/1.1
THREAT-MODEL.md                  STRIDE analysis, guarantees, non-guarantees
build.sh               Assembles dist/ (zero deps)
dist/
  0bind.js             copy (importable as-is)
  0html.js             copy (importable as-is)
  0html.bundle.js      0bind + 0html combined, one file
  0html-playground.html   single-file live editor (open in a browser)
  0html-starter.html      hardened starter tool (TT enforce + CSP + frame-bust)
  0scan.html              PDF threat-scan console — real tool, hostile input inert
```

---

## Quick start

**Use the bundle** (one file, both layers):

```html
<script type="module" src="dist/0html.bundle.js"></script>
<div id="app"></div>
<script type="module">
  bind.init(document.body);
  bind.on('greet', () => alert('hi'));
  html0.render(
    { tag:'button', text:'Greet', on:{ click:'greet' } },
    document.getElementById('app')
  );
</script>
```

**Or fold the two source files into your own `combine.sh`** (0-suite style):
add `0bind.js` then `0html.js` before your app modules; they share scope.

**See it live:** open `dist/0html-playground.html` — type JSON on the left,
watch safe DOM render on the right. The **attack demo** button loads a hostile
spec (script tag, onclick, `javascript:` link, raw-HTML payload) and shows each
piece refused inline.

### Worked example: 0scan (your domain)

`dist/0scan.html` is a **PDF threat-scan console** — a real security tool, not a
toy. It renders findings (embedded JavaScript, `/OpenAction` auto-run, `/Launch`
targets, zip bombs) from JSON specs. The point: **the scan input is
attacker-controlled** — a malicious PDF's object names and JS bodies are hostile
strings. Load **`xss-payload.pdf`** to see object names like
`<script>alert("obj-xss")</script>` render as inert text instead of popping the
analyst's own console. Every hostile field is a 0html `text` node or passes
through the `trust()` gate `esc()`'d at source, and under TT enforce the raw sink
routes through 0html's policy instead of throwing. 8 integration tests
(`0scan-test.cjs`) prove containment against the exact bundle it ships with.

---

## Why this exists

Single-file tools ship UI, load UI, and increasingly take UI shapes from model
output. String-template UI (`innerHTML = \`...\``) is only as safe as the
author's discipline — one forgotten escape is an XSS. 0html makes UI **data**:

- **serializable** — store layouts, ship themes, diff/undo
- **transmittable** — send a view without sending code
- **inspectable** — `validate()` lints a spec before mount
- **untrusted-safe** — the format assumes the author is hostile

---

## Security at a glance

Eleven invariants, all tested (123 assertions):

| | Guards against |
|---|---|
| I1 | any string reaching innerHTML/outerHTML/js: sinks |
| I2 | inline `on*` handlers |
| I3 | `javascript:` / `data:` URLs (incl. control-char obfuscation) |
| I4 | raw HTML except through the one audited `trust()` door |
| J1 | prototype pollution (`__proto__`/`constructor`/`prototype`) |
| J2 | DoS via deep-nest / breadth bombs (bounded) |
| J3 | `script`/`style`/`iframe`/`object`/`embed`/unknown tags |
| J4 | handler-name → code execution (registry lookup, never eval) |
| J5 | raw HTML from loaded files (double-gated, off by default) |
| J6 | weird attribute names + eventish attrs (defense in depth) |
| J7 | runs under Trusted Types enforce mode (no sink bypass) |

Full threat model and normative requirements: `0html-SPEC.md` §3.

---

## Design choices (and their costs)

Deliberate tradeoffs, made for the single-file-tool target:

- **Allowlist, not sanitizer.** Unknown tags are refused, not cleaned. Smaller
  attack surface and no sanitizer-bypass arms race — at the cost of needing to
  extend `ALLOWED_TAGS` (a compile-time fork) for exotic tags. This is
  intentional: the allowlist is *not* spec-configurable, so no loaded JSON can
  widen it.
- **Handlers by name only.** A spec can wire `"click": "save"` but cannot
  define `save`. Costs a line of registration code per handler; buys a hard
  guarantee that JSON never introduces behavior.
- **Raw HTML off by default.** Rendering generator output (markdown, syntax
  highlighting) requires the *tool author* to opt in per compile and name the
  generators they vouch for. Costs one options object; buys "raw HTML from a
  file is impossible unless I explicitly allowed it."
- **Refusals are visible, not silent.** Bad pieces render as inert
  `[data-0html-refused]` placeholders + console warnings, so problems surface
  in development instead of hiding. Costs a little output noise; buys
  debuggability.

---

## Running tests

```bash
node 0bind-test.cjs     # 43 pass (runtime)
node 0html-test.cjs     # 63 pass (compiler, J1–J6)
node 0bind-tt-test.cjs  # 9 pass  (Trusted Types enforce, J7)
node 0scan-test.cjs     # 8 pass  (0scan hostile-input containment)
./build.sh --test       # both, then build dist/
```

Tests use an in-file DOM shim — no jsdom, no network, matching the zero-dep
philosophy. (Files load as `.cjs` because the repo is `type:module`; the shim
copies each source to a temp `.cjs` so `require` returns `module.exports`.)

---

## Versioning

`major.minor.patch`. Changing a security invariant or tightening the tag
allowlist is **major**. New optional node keys/options that default to prior
behavior are **minor**. Bug fixes are **patch**.

Current: **0html 1.1.0** / runtime **0bind 1.1.0**.
