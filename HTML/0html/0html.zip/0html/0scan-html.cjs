/* ╔════════════════════════════════════════════════════════════╗
   ║  0scan-html.cjs — the one HTML scanner the tooling shares            ║
   ╚════════════════════════════════════════════════════════════╝

   Every command that reads markup goes through here: convert-handlers,
   restore-handlers, the L2 and L8 interlocks, styleBlocks, audit-sri, the L4
   shim check, and the value report. It exists because the alternative — each
   command growing its own regex — produced seven separate findings in this
   project (SECURITY-IMPROVEMENTS.md #23–#29), every one of them failing toward
   silent approval:

     • /<tag([^>]*)>/          cannot cross a '>' inside a quoted attribute
     • /<script[^>]*>/         same, so masking swallowed the rest of the tag
     • quoted-value-only       missed  src=x  and  onclick='x()'
     • /^on[a-z]{2,}$/         treated once="true" as an event handler

   Two rules matter and both are checked against an independent tokenizer
   (python3 html.parser) by 0scanner-diff.cjs:

     1. a '>' inside a quoted attribute value does NOT close the tag
     2. <script>/<style> switch to CDATA — markup in the body is not markup

   Guarded by 0scanner-fuzz.cjs (properties P1–P9) and 0scanner-diff.cjs
   (agreement on every well-formed document). Integrity-pinned in 0html.lock
   and listed in the CycloneDX SBOM, like the rest of the toolchain.
*/
'use strict';

function decodeEntities(str) {
  return str.replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCharCode(parseInt(n, 16)))
            .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(+n))
            .replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'")
            .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
}

// Index-preserving mask of everything that is NOT markup: comments and the
// bodies of <script>/<style>. Contents become spaces, so every offset in the
// masked string still addresses the same byte of the original and the
// slice-based rewrite below stays valid.
//
// Without this, the tag scan ran over script bodies too. A legacy template
// string — `var tpl = '<button onclick="save()">'` — is exactly the population
// this tool exists to migrate, and it was rewritten IN THE STRING to
// '<button data-0h="2">'. The wiring script then queried for that attribute at
// DOMContentLoaded, before the template was ever injected, so the handler was
// permanently dead — and the tool reported "✓ converted".
function maskNonMarkup(html) {
  const blank = (t) => ' '.repeat(t.length);
  let out = html.replace(/<!--[\s\S]*?-->/g, blank);
  // Locate the <script>/<style> OPEN TAGS with the quote-aware scanner below,
  // not with /<script\b[^>]*>/. `<script data-n="a > b" src="https://cdn/x.js">`
  // has a '>' inside an attribute, so a [^>]* opener ends the tag early and the
  // blanking then swallows the rest of the real tag — which is how the SRI audit
  // came to miss that script (and everything up to the next </script>) entirely.
  let guard = 0;
  for (const t of scanTags(out)) {
    const name = t.tag.toLowerCase();
    if (name !== 'script' && name !== 'style') continue;
    if (t.index < guard) continue;                 // already inside a blanked body
    const close = out.toLowerCase().indexOf('</' + name, t.end);
    if (close === -1) continue;
    out = out.slice(0, t.end) + blank(out.slice(t.end, close)) + out.slice(close);
    guard = close;
  }
  return out;
}

// A real tag scanner. A '>' inside a quoted attribute value does NOT close the
// tag, but the old /<([a-z][\w-]*)\b([^>]*)>/ assumed it did — so
// `<p title="a > b" onclick="x()">` was invisible to the converter AND to the
// L2 interlock that counts inline handlers. convert-handlers reported "nothing
// to convert (L2 can proceed)", L2 then dropped 'unsafe-inline', and a live
// inline handler stayed in the document. Also handles single-quoted and
// unquoted attribute values, which the old regex ignored entirely.
function scanTags(masked) {
  const tags = []; const re = /<([a-zA-Z][\w-]*)/g; let m;
  while ((m = re.exec(masked))) {
    let i = m.index + m[0].length; const attrs = []; let closed = false;
    for (;;) {
      while (i < masked.length && /\s/.test(masked[i])) i++;
      if (i >= masked.length) break;
      if (masked[i] === '>') { i++; closed = true; break; }
      if (masked[i] === '/' && masked[i + 1] === '>') { i += 2; closed = true; break; }
      const nameStart = i;
      while (i < masked.length && !/[\s=/>]/.test(masked[i])) i++;
      const name = masked.slice(nameStart, i);
      if (!name) { i++; continue; }
      let valStart = -1, valEnd = -1, quote = '', j = i;
      while (j < masked.length && /\s/.test(masked[j])) j++;
      if (masked[j] === '=') {
        j++;
        while (j < masked.length && /\s/.test(masked[j])) j++;
        if (masked[j] === '"' || masked[j] === "'") {
          quote = masked[j]; valStart = j + 1;
          const close = masked.indexOf(quote, valStart);
          // Unterminated quote: the value runs to EOF (which is also what the
          // browser does). Clamp — stepping past the closing quote when there
          // isn't one pushed tag.end to length+1, so a span could address
          // beyond the document. Found by 0scanner-fuzz P3.
          valEnd = close === -1 ? masked.length : close;
          i = Math.min(valEnd + 1, masked.length);
        } else {
          valStart = j;
          while (j < masked.length && !/[\s>]/.test(masked[j])) j++;
          valEnd = j; i = j;
        }
      }
      attrs.push({ name, quote, valStart, valEnd, start: nameStart, end: i });
    }
    // `closed` records whether a '>' was actually reached. A tag that runs off
    // the end — an unterminated attribute quote, a truncated file — is a parse
    // error; browsers discard it. We still report it so callers can refuse.
    tags.push({ index: m.index, end: Math.min(i, masked.length), tag: m[1], attrs, unterminated: !closed });
    re.lastIndex = i;
  }
  return tags;
}
// Event handler CONTENT ATTRIBUTES. A browser fires a handler only for names it
// recognises; an unknown on-prefixed attribute (a framework's `once="true"`,
// say) is an ordinary attribute that does nothing. /^on[a-z]{2,}$/ matched those
// too, so convert-handlers DELETED once="true" from the element and registered a
// listener for a nonexistent 'ce' event — destroying an attribute the app relies
// on. The list is a superset of what browsers recognise (spec + common vendor
// events), so nothing that really fires can be classified inert.
const EVENT_HANDLER_ATTRS = new Set(('abort auxclick beforeinput beforematch beforetoggle blur cancel canplay ' +
  'canplaythrough change click close contextlost contextmenu contextrestored copy cuechange cut dblclick drag ' +
  'dragend dragenter dragleave dragover dragstart drop durationchange emptied ended error focus focusin focusout ' +
  'formdata input invalid keydown keypress keyup load loadeddata loadedmetadata loadstart mousedown mouseenter ' +
  'mouseleave mousemove mouseout mouseover mouseup paste pause play playing progress ratechange reset resize ' +
  'scroll scrollend securitypolicyviolation seeked seeking select selectstart selectionchange slotchange stalled ' +
  'submit suspend timeupdate toggle volumechange waiting wheel ' +
  'afterprint beforeprint beforeunload hashchange languagechange message messageerror offline online pagehide ' +
  'pageshow popstate rejectionhandled storage unhandledrejection unload ' +
  'touchstart touchend touchmove touchcancel ' +
  'animationstart animationend animationiteration animationcancel ' +
  'transitionstart transitionrun transitionend transitioncancel ' +
  'pointerdown pointerup pointermove pointerover pointerout pointerenter pointerleave pointercancel ' +
  'gotpointercapture lostpointercapture ' +
  'fullscreenchange fullscreenerror ' +
  'webkitanimationstart webkitanimationend webkitanimationiteration webkittransitionend').split(/\s+/).map((e) => 'on' + e));
const isHandlerAttr = (n) => EVENT_HANDLER_ATTRS.has(String(n).toLowerCase());
// on-prefixed attributes that are NOT handlers: inert in the browser, so they
// neither need converting nor block L2 — but the operator should be told they
// were left alone rather than silently skipped.
const isUnknownOnAttr = (n) => /^on[a-z0-9_-]{2,}$/i.test(n) && !isHandlerAttr(n);
function findHandlers(html) {
  const masked = maskNonMarkup(html); const out = [];
  for (const t of scanTags(masked)) {
    const hs = t.attrs.filter(a => isHandlerAttr(a.name) && a.valStart >= 0);
    if (!hs.length) continue;
    out.push({
      index: t.index, end: t.end, tag: t.tag,
      handlers: hs.map(a => ({
        ev: a.name.slice(2).toLowerCase(),
        raw: html.slice(a.valStart, a.valEnd),
        body: decodeEntities(html.slice(a.valStart, a.valEnd)),
      })),
      // spans to delete, extended back over the separating whitespace
      spans: hs.map(a => { let s = a.start; while (s > 0 && /[ \t]/.test(html[s - 1])) s--; return { start: s, end: a.end }; }),
    });
  }
  return out;
}
// Inline handlers living inside markup-in-JS (`var t = '<b onclick=\"x()\">'`)
// are deliberately NOT converted — rewriting a string literal is what broke
// them before. But they are still inline handlers once that markup is injected,
// and L2 will block them, so the operator has to be told rather than left to
// discover it under enforce CSP.
function scriptEmbeddedHandlers(html) {
  let n = 0;
  const re = /<script\b[^>]*>([\s\S]*?)<\/script/gi; let m;
  while ((m = re.exec(html))) n += (m[1].match(/\son[a-z]{2,}\s*=/gi) || []).length;
  return n;
}
// Detection and conversion now share one implementation, so the L2 interlock
// can no longer disagree with what convert-handlers actually removed.
function inlineHandlers(html) { return findHandlers(html).reduce((n, f) => n + f.handlers.length, 0); }

module.exports = {
  decodeEntities, maskNonMarkup, scanTags,
  EVENT_HANDLER_ATTRS, isHandlerAttr, isUnknownOnAttr,
  findHandlers, scriptEmbeddedHandlers, inlineHandlers,
};
